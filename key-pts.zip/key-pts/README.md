# KEY PTS — Broiler Kümes Takip (yerel, tek cihaz)

Expo / React Native / TypeScript. **Sunucu yok**: tüm veriler telefonda (iOS/Android: Expo SQLite, web önizleme: AsyncStorage) tutulur.
Supabase, çoklu kullanıcı, gerçek zamanlı eşitleme, bulut yedek ve abonelik **bu sürümde yoktur**. Eski sunucu şeması yalnızca ileride kullanılmak üzere `future-backend/` altında arşivlidir ve uygulamaya bağlı değildir.

## Çalıştırma
```bash
cd mobile && npm install
npx expo start            # Expo Go / geliştirme derlemesi
npx tsc --noEmit && npx jest
```

## Klasörler
- `mobile/app` — ekranlar (Expo Router). `mobile/src/navigation/nav.ts` — tüm geçişler (çift dokunma koruması, güvenli geri).
- `mobile/src/services/local` — yerel veri katmanı: `localClient.ts` (iş kuralları, atomik günlük kayıt, yerel hesap), `storage(.native).ts`, `views.ts`, `sampleData.ts`.
- `mobile/src/lib/data.ts` — **tek giriş noktası**. İleride sunucu eklenirse yalnızca bu dosyadaki istemci değişir.
- `mobile/src/stores/drafts.ts` — kullanıcı/çiftlik/kümes/dönem/tarih anahtarlı form taslakları.
- `assets/branding` — logo (SVG kaynak + PNG). `e2e/` — tarayıcı uçtan uca ve duyarlı tasarım testleri.

Ayrıntı: `docs/ARCHITECTURE.md`, `docs/TESTING.md` (platform matrisi ve kalite kapısı).
