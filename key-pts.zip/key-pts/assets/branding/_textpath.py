# Metni Inter glif yollarına çevirir (SVG <path>), harf aralığı destekli
import sys
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

def text_path(font_path, text, size, x, y, tracking=0.0):
    f = TTFont(font_path)
    gs = f.getGlyphSet(); cmap = f.getBestCmap(); upm = f['head'].unitsPerEm
    hmtx = f['hmtx']; s = size / upm
    pen = SVGPathPen(gs)
    cx = x
    for ch in text:
        gname = cmap.get(ord(ch))
        if gname is None: continue
        tp = TransformPen(pen, (s, 0, 0, -s, cx, y))
        gs[gname].draw(tp)
        cx += hmtx[gname][0] * s + tracking * size
    return pen.getCommands(), cx - tracking * size - x
