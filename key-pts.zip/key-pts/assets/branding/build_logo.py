"""KEY PTS logo üreticisi — horoz başı + klasik kasa anahtarı.
Anahtarın halkası (kulp) horoz başını çevreler; gaga anahtarın gövdesine bağlanır; gövde ucunda kasa anahtarı dişleri.
Kullanım: python3 build_logo.py   (Inter OTF gerekir; yazılar vektör yola çevrilir)"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from _textpath import text_path

NAVY, ORANGE, ORANGE_D, GOLD, RED, GRAY = '#10243A', '#F07D1E', '#E2680B', '#F6A21C', '#E4471B', '#4A5563'
FONT = '/usr/share/fonts/opentype/inter/'

def defs(u):
    return f'''<defs>
    <linearGradient id="sh{u}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="{GOLD}"/><stop offset="0.35" stop-color="{ORANGE}"/><stop offset="1" stop-color="{ORANGE_D}"/></linearGradient>
    <linearGradient id="cb{u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F26A2E"/><stop offset="1" stop-color="{RED}"/></linearGradient>
    <linearGradient id="fe{u}" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="{ORANGE_D}"/><stop offset="1" stop-color="{GOLD}"/></linearGradient>
  </defs>'''

def symbol(u='a', ring=NAVY, face='#FFFFFF', eye=NAVY, end=228):
    """Sembol: 0..240 × 0..128. end: anahtar gövdesinin bittiği x (kompakt sürüm için kısa)."""
    b0 = end - 34
    return f'''{defs(u)}
  <!-- anahtar gövdesi -->
  <path d="M104 58 H {end - 6} a 6 6 0 0 1 0 12 H 104 Z" fill="url(#sh{u})"/>
  <!-- kasa anahtarı dişleri (iki çentikli blok) -->
  <path d="M{b0} 70 H {end} V 98 a 4 4 0 0 1 -4 4 H {b0 + 24} V 90 H {b0 + 16} V 102 H {b0 + 8} V 94 H {b0} Z" fill="{ORANGE_D}"/>
  <!-- anahtar kulpu (halka) -->
  <circle cx="62" cy="66" r="47" fill="none" stroke="{ring}" stroke-width="11"/>
  <!-- boyun tüyü: halkanın sol-alt iç yayını izleyen turuncu hilal -->
  <path d="M27 92 C 18 76, 19 56, 29 40 C 27 58, 31 78, 47 96 C 40 99, 32 98, 27 92 Z" fill="url(#fe{u})"/>
  <!-- ibik -->
  <path d="M44 32 C 38 20, 47 9, 56 16 C 58 5, 72 3, 74 14 C 81 7, 93 13, 88 25 C 95 27, 95 36, 86 38 L 47 40 Z" fill="url(#cb{u})"/>
  <!-- baş -->
  <path d="M42 48 C 47 34, 79 31, 88 49 C 93 59, 93 73, 87 83 C 80 95, 63 100, 52 95 C 41 88, 37 64, 42 48 Z" fill="{face}"/>
  <!-- gaga: anahtar gövdesine bağlanır -->
  <path d="M88 54 L 110 64 L 88 74 Z" fill="{GOLD}"/>
  <!-- sakal -->
  <path d="M77 80 C 87 82, 89 94, 81 101 C 73 98, 71 87, 77 80 Z" fill="{RED}"/>
  <!-- göz -->
  <circle cx="71" cy="58" r="5" fill="{eye}"/>
  <circle cx="72.6" cy="56.4" r="1.6" fill="#FFFFFF"/>'''

def svg(w, h, body, vb=None, title='KEY PTS'):
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb or f"0 0 {w} {h}"}" width="{w}" height="{h}">\n  <title>{title}</title>\n  {body}\n</svg>\n'

def wordmark(size, key_fill, sub_fill, sub=True):
    k, kw = text_path(FONT + 'Inter-ExtraBoldItalic.otf', 'KEY', size, 0, 0, tracking=-0.02)
    p, pw = text_path(FONT + 'Inter-ExtraBoldItalic.otf', 'PTS', size, 0, 0, tracking=-0.01)
    gap = size * 0.14
    parts = [(k, 0, key_fill), (p, kw + gap, ORANGE)]
    w = kw + gap + pw
    s = None
    if sub:
        s, sw = text_path(FONT + 'Inter-Medium.otf', 'Poultry Tracking System', size * 0.33, 0, 0, tracking=0.012)
        s = (s, sw, sub_fill)
    return parts, w, s

def lockup_full(name, dark):
    ring, key_fill, sub_fill = ('#FFFFFF', '#FFFFFF', '#C9D3DE') if dark else (NAVY, NAVY, GRAY)
    parts, tw, sub = wordmark(80, key_fill, sub_fill)
    W = max(tw, 240) + 40
    sx = (W - 240) / 2
    body = f'<g transform="translate({sx:.1f} 6)">{symbol(name, ring)}</g>'
    x0 = (W - tw) / 2
    for d, off, fill in parts:
        body += f'\n  <path transform="translate({x0 + off:.1f} 214)" d="{d}" fill="{fill}"/>'
    s, sw, sf = sub
    body += f'\n  <path transform="translate({(W - sw) / 2:.1f} 252)" d="{s}" fill="{sf}"/>'
    body += f'\n  <path d="M{x0 + tw*0.12:.1f} 278 C {x0 + tw*0.4:.1f} 264, {x0 + tw*0.72:.1f} 262, {x0 + tw*0.9:.1f} 266 C {x0 + tw*0.7:.1f} 269, {x0 + tw*0.42:.1f} 271, {x0 + tw*0.12:.1f} 278 Z" fill="url(#sh{name})"/>'
    open(f'{name}.svg', 'w').write(svg(int(W), 290, body, title='KEY PTS — Poultry Tracking System'))

def lockup_horizontal(name, dark):
    ring, key_fill, sub_fill = ('#FFFFFF', '#FFFFFF', '#C9D3DE') if dark else (NAVY, NAVY, GRAY)
    parts, tw, sub = wordmark(56, key_fill, sub_fill)
    body = f'<g transform="translate(0 2) scale(0.7)">{symbol(name, ring)}</g>'
    x = 178
    for d, off, fill in parts:
        body += f'\n  <path transform="translate({x + off:.1f} 58)" d="{d}" fill="{fill}"/>'
    s, sw, sf = sub
    body += f'\n  <path transform="translate({x + 2:.1f} 84)" d="{s}" fill="{sf}"/>'
    open(f'{name}.svg', 'w').write(svg(int(x + max(tw, sw) + 8), 96, body, title='KEY PTS — Poultry Tracking System'))

def build():
    for f in os.listdir('.'):
        if f.endswith('.svg'): os.remove(f)
    lockup_full('keypts-logo-full-light', False); lockup_full('keypts-logo-full-dark', True)
    lockup_horizontal('keypts-logo-horizontal-light', False); lockup_horizontal('keypts-logo-horizontal-dark', True)
    open('keypts-symbol-light.svg', 'w').write(svg(240, 128, symbol('sl', NAVY), vb='0 -6 240 134'))
    open('keypts-symbol-dark.svg', 'w').write(svg(240, 128, symbol('sd', '#FFFFFF'), vb='0 -6 240 134'))
    # Uygulama ikonu: lacivert kare, sembol ortada (iOS köşeleri kendisi maskeler)
    open('keypts-symbol-compact.svg', 'w').write(svg(184, 128, symbol('sc', NAVY, end=180), vb='0 -6 184 134'))
    open('keypts-app-icon.svg', 'w').write(svg(1024, 1024, f'<rect width="1024" height="1024" fill="{NAVY}"/>\n  <g transform="translate(130 222) scale(4.1)">{symbol("ic", "#FFFFFF", end=180)}</g>'))
    # Android adaptive ön plan: güvenli alan (%66) içinde
    open('keypts-adaptive-foreground.svg', 'w').write(svg(1024, 1024, f'<g transform="translate(277 352) scale(2.55)">{symbol("ad", "#FFFFFF", end=180)}</g>'))
    # Tek renk bildirim ikonu
    mono = symbol('mo', '#FFFFFF', end=180)
    for c in ['url(#shmo)', 'url(#cbmo)', 'url(#femo)', GOLD, RED, ORANGE_D]: mono = mono.replace(f'fill="{c}"', 'fill="#FFFFFF"')
    mono = mono.replace(f'fill="{NAVY}"', 'fill="#000000" fill-opacity="0"').replace('fill="#FFFFFF"/>\n  <!-- boyun', 'fill="none" stroke="#FFFFFF" stroke-width="6"/>\n  <!-- boyun', 1)
    open('keypts-mono.svg', 'w').write(svg(184, 128, mono, vb='0 -6 184 134'))
    full = open('keypts-logo-full-dark.svg').read(); inner = full[full.index('</title>') + 8:full.rindex('</svg>')]
    open('keypts-splash.svg', 'w').write(svg(1284, 2778, f'<rect width="1284" height="2778" fill="{NAVY}"/>\n  <g transform="translate(277 1070) scale(2.4)">{inner}</g>'))

if __name__ == '__main__':
    build()
