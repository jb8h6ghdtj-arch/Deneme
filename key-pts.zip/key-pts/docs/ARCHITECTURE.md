> **Güncel durum (06.11.2026):** Uygulama yerel, tek cihazlıdır. Bu belgedeki Supabase/sunucu bölümleri yalnızca ileride sunucuya geçiş için arşivdir; şu anki sürümde kullanılmaz. Güncel yapı için README.md ve docs/TESTING.md'ye bakın.

# KEY PTS — Mimari

> Kümesinizin nabzı, avucunuzda.

## 1. Genel bakış

```
┌──────────────────────────── Mobil (iOS / Android) ────────────────────────────┐
│ Expo Router ekranları ─► TanStack Query (okuma) ─► Supabase JS (RLS altında)  │
│        │                                                                      │
│        └─► Kayıt formları ─► Offline kuyruk (AsyncStorage, client_id) ─┐      │
│                                 NetInfo / AppState / 30 sn ile flush   │      │
└────────────────────────────────────────────────────────────────────────┼──────┘
                                                                         ▼
┌──────────────────────────────── Supabase ─────────────────────────────────────┐
│ Auth (e-posta/şifre) │ PostgreSQL 15+ │ RLS │ Realtime │ Storage (özel)       │
│                                                                               │
│ Tetikleyiciler: bağlam türetme · tarih/sayı doğrulama · birim dönüşümü ·     │
│ denetim kaydı · eşik uyarıları · bekleme süresi çakışması                     │
│ Görünümler: v_flock_overview · v_flock_daily · v_activity                     │
│ RPC: kurulum · davet · dönem kapatma · kapanış özeti                          │
│ Edge Function alerts-cron (pg_cron) ─► run_scheduled_alerts ─► Expo Push      │
└───────────────────────────────────────────────────────────────────────────────┘
```

### Temel kararlar ve gerekçeleri

| Karar | Gerekçe |
|---|---|
| **İş kuralları veritabanında** (tetikleyiciler, kısıtlar, görünümler) | Mobil, ileride web paneli ve entegrasyonlar aynı kuralları paylaşır; istemci atlatılsa bile veri tutarlı kalır. |
| **RLS + SECURITY DEFINER yardımcıları** (`can_access_house`, `can_manage_house`) | Yetki tek noktada tanımlı; arayüzde buton gizlemek güvenlik sayılmaz. |
| **`org_id/farm_id/house_id` dönemden türetilir** | İstemci başka çiftliğin kimliğini gönderse bile tetikleyici ezer; RLS ikinci savunma hattıdır. |
| **Her operasyon kaydında `client_id UNIQUE`** | Offline tekrar gönderimlerde mükerrer kayıt fiziksel olarak imkânsız (`ON CONFLICT DO NOTHING`). |
| **`version` sütunu + koşullu güncelleme** | Eşzamanlı düzenlemede sessiz üzerine yazma yok; 0 satır etkilenirse istemci "çakışma" gösterir. |
| **Soft delete (`deleted_at`)**, `DELETE` izni yok | Kayıt geçmişi kaybolmaz; denetim izi korunur. |
| **`entry_date` ↔ `created_at` ayrı** | İş günü (Türkiye saati) ile sunucuya gönderim anı karışmaz; offline girilen dünkü kayıt doğru güne düşer. |
| **"Kayıt yok" = NULL, "0 ölüm" = 0** | Görünümler eksik günleri açıkça işaretler; KPI'lar eksik veriyi sıfır saymaz. |
| **Hafif SVG grafikler** (harici grafik kütüphanesi yok) | Daha küçük paket, tam tema kontrolü, ölçümsüz günlerde boşluk bırakma garantisi. |
| **Hedef sıcaklık / ölüm eşikleri varsayılanı yönetici belirler** | Uygulama teşhis veya tedavi önermez; durum renkleri yalnızca tanımlı eşik karşılaştırmasıdır. |

## 2. Klasör yapısı

```
key-pts/
├── README.md
├── assets/branding/            # Logo üreticisi (build_logo.py), SVG logo seti + PNG ikonlar
├── tools/                      # Ekran görüntüsü ve referans karşılaştırma araçları
├── docs/                       # Mimari, dağıtım, test raporu
├── supabase/
│   ├── config.toml
│   ├── migrations/
│   │   ├── 20261105000001_core_schema.sql         # tablolar, kısıtlar, indeksler
│   │   ├── 20261105000002_security_and_rules.sql  # RLS, tetikleyiciler, denetim
│   │   └── 20261105000003_views_rpcs_alerts.sql   # görünümler, RPC, uyarılar
│   ├── functions/alerts-cron/index.ts             # zamanlanmış uyarı + push
│   └── tests/                  # PostgreSQL üzerinde kabul testleri
└── mobile/
    ├── app/                    # Expo Router ekranları (dosya = rota)
    │   ├── (auth)/             # giriş, kayıt
    │   ├── (tabs)/             # Ana Sayfa, Kümesler, Kayıt Ekle, Raporlar, Profil
    │   ├── onboarding/         # kurulum sihirbazı, davetle katılım
    │   ├── house/[id].tsx      # kümes detayı (8 sekme)
    │   ├── entry/[kind].tsx    # günlük veri girişi (6 tür)
    │   ├── flock/              # dönem başlatma / kapatma
    │   ├── team/ settings/     # ekip, eşikler, ilaç kataloğu, bildirimler
    │   └── activity, notifications, sync
    ├── assets/images/          # uygulama ikonları, splash
    └── src/
        ├── api/                # TanStack Query hook'ları, mutasyonlar
        ├── components/         # UI kit, grafikler, takvim, logo, ikon seti
        ├── domain/             # tipler + saf hesaplamalar (test edilir)
        ├── features/           # rapor üreticileri, düzeltme paneli
        ├── i18n/               # tr (ana), en (kısmi), ar için RTL hazır
        ├── lib/                # supabase, tarih/saat dilimi, biçim, dışa aktarma, push
        ├── offline/            # kalıcı kuyruk + senkron motoru
        ├── stores/             # oturum (Zustand)
        └── theme/              # tasarım token'ları, açık/koyu tema
```

## 3. Veri modeli

```mermaid
erDiagram
  organizations ||--o{ organization_members : has
  organizations ||--o{ farms : owns
  farms ||--o{ houses : contains
  houses ||--o{ house_assignments : grants
  houses ||--o{ flocks : "üretim dönemleri"
  flocks ||--o{ mortality_entries : ""
  flocks ||--o{ coal_entries : ""
  flocks ||--o{ medication_applications : ""
  medication_products ||--o{ medication_applications : ""
  flocks ||--o{ weight_measurements : ""
  flocks ||--o{ temperature_measurements : ""
  flocks ||--o{ daily_notes : ""
  flocks ||--o{ flock_movements : "ek giriş / transfer / ayıklama"
  flocks ||--o{ dispatch_records : "kesim / sevk"
  farms ||--|| alert_settings : ""
  farms ||--o{ temperature_targets : ""
  organizations ||--o{ invitations : ""
  organizations ||--o{ notifications : ""
  organizations ||--o{ audit_logs : ""
```

**Kritik kısıtlar**

- `flocks_one_active_per_house`: kümeste aynı anda tek aktif dönem.
- `(house_id, cycle_no) UNIQUE`: dönem numarası otomatik ve benzersiz.
- Tamamlanmış döneme yazma tetikleyicide reddedilir (`FLOCK_CLOSED`) → dönemler arası veri sızıntısı yok.
- Ölüm/çıkış/sevk sayısı mevcut hayvan sayısını aşamaz (`EXCEEDS_ALIVE`, satır kilidiyle yarış koşulu önlenir).
- Tarih: giriş tarihinden önce ve ileri tarihli kayıt yok (çiftlik saat dilimine göre).
- Tartım: istemcinin değeri yok sayılır; sunucu birimi gram'a çevirir, 10–8.000 g dışını reddeder.
- Kömür `total_kg` üretilmiş sütun → torba/kg asla karışmaz.

**Hesap tanımları** (görünüm `v_flock_daily`)

| Metrik | Tanım |
|---|---|
| Mevcut hayvan | başlangıç + ek giriş + transfer giriş − ölüm − ayıklama − transfer çıkış − diğer çıkış − sevk |
| Günlük ölüm % | günlük ölüm ÷ **gün başı** mevcut × 100 |
| Kümülatif ölüm % | toplam ölüm ÷ (başlangıç + ek girişler) × 100 |
| Yaş | giriş günü = 1. gün; ilk *N* gün (varsayılan 15, ayarlanabilir) civciv |

**Gelecek modüller için hazırlık**: FCR için `weight_measurements` + `dispatch_records.total_live_weight_kg` mevcut; yem tüketimi `coal_entries` ile aynı sözleşmeyle (`client_id`, `flock_id`, `entry_date`, `version`) eklenecek. Sıcaklıkta `source` sütunu (`manual`/`sensor`) IoT için ayrılmış. Çoklu çiftlik ve web paneli için `organizations → farms` hiyerarşisi kurulu.

## 4. Rol ve yetki matrisi (veritabanında uygulanır)

| İşlem | Sahip | Sorumlu | Bakıcı |
|---|---|---|---|
| Kümesleri görmek | tümü | atandıkları | atandıkları |
| Günlük kayıt girmek | ✓ | atandıkları | atandıkları |
| Kendi kaydını düzeltmek | ✓ | ✓ | ✓ (aktif dönemde) |
| Başkasının kaydını düzeltmek / silmek | ✓ | yönettiği kümeler | ✗ |
| Sürü hareketi (ayıklama/transfer) | ✓ | yönettiği kümeler | ✗ |
| Dönem başlatma / kapatma | ✓ | yönettiği kümeler | ✗ |
| İlaç kataloğu | ✓ | ✓ | ✗ |
| Davet | sorumlu + bakıcı | yalnız bakıcı, kendi kümelerine | ✗ |
| Eşik ve hedef ayarları | ✓ | ✗ | ✗ |
| Denetim geçmişi | tümü | yönettiği kümeler | ✗ |

## 5. Offline ve senkronizasyon

1. Form kaydedilince işlem önce cihazdaki **expo-sqlite `sync_operations` tablosuna** yazılır (uygulama kapansa da kaybolmaz; web önizlemede AsyncStorage).
2. Hemen gönderim denenir; başarılıysa "Kaydedildi", değilse "Cihaza kaydedildi" mesajı.
3. Ağ geri geldiğinde (NetInfo), uygulama öne geldiğinde ve 30 sn'de bir **FIFO** gönderim.
4. Ağ/5xx hatası → kuyruk durur, sıra korunur. Doğrulama/yetki hatası → "başarısız", kullanıcı görür, veri silinmez.
5. Düzenlemeler `version` ile gönderilir; başkası değiştirdiyse **çakışma** olarak işaretlenir.
6. Çift dokunma: aynı içerik 5 sn içinde ikinci kez kuyruğa alınmaz.
7. Senkron durumu her ekranda (`SyncBanner`) ve "Bekleyen kayıtlar" ekranında görünür; bekleyen kayıt varken çıkış yapılamaz.

8. Sunucu verisinin son hâli (TanStack Query önbelleği) cihazda saklanır; internet yokken Dashboard son veriyi ve “önbellekteki veri (saat)” etiketini gösterir. Çıkışta önbellek silinir.
9. Günlük Kayıt formu tek kaydette birden fazla modüle yazar; her modül kendi tablosuna kendi işlem kimliğiyle gider ve her biri için “Gönderildi / Cihazda bekliyor / Gönderilemedi” ayrı gösterilir.

Sınır: fotoğraf yükleme internet gerektirir (çevrimdışıyken buton pasif).

## 5b. Demo ortamı

`EXPO_PUBLIC_APP_ENV=demo` ile uygulama sunucuya bağlanmadan çalışır (`src/services/demo`). Veri, gerçek tablo şemasıyla üretilir; görünümler SQL ile aynı formüllerle hesaplanır (`demo.test.ts` doğrular). Her başlıkta **DEMO** etiketi görünür. Üretim derlemesinde demo verisi hiç üretilmez (istemci yalnız demo modunda seçilir).

## 6. Ekran haritası

```
Giriş / Kayıt
  └─ Onboarding ─┬─ Kurulum sihirbazı (çiftlik → kümesler → ısıtma → iletişim → özet)
                 └─ Davet koduyla katıl
Sekmeler
  ├─ Ana Sayfa      Sahip/Sorumlu: 8 KPI + kümes kartları · Bakıcı: işlem merkezi
  ├─ Kümesler       kart listesi, dönem başlatma
  ├─ Kayıt Ekle     kümes seç → Ölüm / Kömür / İlaç / Tartım / Sıcaklık / Not
  ├─ Raporlar       günlük çiftlik özeti · karşılaştırma (aralık + kümes filtresi) · arşiv
  └─ Profil         ekip · eşikler · ilaç kataloğu · bildirimler · tema · dil
Kümes detayı: Genel Bakış · Ölüm Takvimi · Kömür · İlaç · Tartım · Isı ve Ortam · Notlar · Raporlar
  ├─ Dönem seçici (aktif + arşiv)   └─ Dönemi tamamla (özet → sevk → tutarsızlık → arşiv)
Bildirimler · İşlem geçmişi (kayıtlar + düzeltmeler) · Bekleyen kayıtlar
```

## 7. Tasarım sistemi

Referans görselden örneklenmiştir; ayrıntılar ve sadakat raporu: [DESIGN_REFERENCE.md](DESIGN_REFERENCE.md).

- **Token dosyaları**: `src/theme/colors.ts`, `typography.ts`, `spacing.ts`, `radius.ts`, `shadows.ts`
- **Renk**: lacivert `#10243A` (marka/başlık), turuncu `#EB7615`→`#E2680B` (birincil eylem), yeşil başarı, kırmızı kritik, amber uyarı, mavi bilgi
- **Tipografi**: Inter (SIL OFL 1.1) — 21 sayfa başlığı, 18 bölüm, 23 KPI, 15 gövde, 13,5 etiket
- **İkon**: Lucide (ISC), tek tek içe aktarılır; modül renkleri `colors.module`
- **Bileşenler**: `components/ui` (Text, Card, Button, TextField, FramedField, InputRow, SelectSheet, DatePickerSheet, PillTabs, UnderlineTabs, Checkbox, Pill, Notice, Toast…), `components/cards` (KpiTile, TintedKpi, StatBox, ListRow, MortalityCalendar), `components/charts/TrendChart`, `components/layout/Screen`, `components/brand`
