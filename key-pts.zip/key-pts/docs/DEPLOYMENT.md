> **Güncel durum (06.11.2026):** Uygulama yerel, tek cihazlıdır. Bu belgedeki Supabase/sunucu bölümleri yalnızca ileride sunucuya geçiş için arşivdir; şu anki sürümde kullanılmaz. Güncel yapı için README.md ve docs/TESTING.md'ye bakın.

# KEY PTS — Kurulum ve Dağıtım

## Gerekli dış hesaplar

| Hesap | Neden | Ne gerekli |
|---|---|---|
| **Supabase** (supabase.com) | Veritabanı, kimlik doğrulama, depolama, edge function | Proje URL'si, `anon` anahtarı (istemci), `service_role` anahtarı (yalnızca sunucu) |
| **Expo / EAS** (expo.dev) | Derleme, push bildirim | EAS proje kimliği (`app.json → extra.eas.projectId`) |
| **Apple Developer** (yıllık ücretli) | iOS dağıtımı, APNs push | Takım kimliği; EAS sertifikaları kendisi yönetebilir |
| **Google Play Console** (tek seferlik ücret) | Android dağıtımı | Paket adı `com.key.pts`; FCM için Firebase projesi (`google-services.json`) |

> Gizli anahtarlar (service_role, CRON_SECRET, EXPO_ACCESS_TOKEN) **asla** mobil uygulamaya veya git'e girmez.

## 1. Supabase

```bash
npm i -g supabase
supabase login
supabase link --project-ref <PROJE_REF>
supabase db push                       # migrations/ klasörünü uygular
supabase functions deploy alerts-cron --no-verify-jwt
supabase secrets set CRON_SECRET=$(openssl rand -hex 32)
```

Panelde:
- **Authentication → URL Configuration**: Site URL `keypts://`
- **Authentication → Email**: doğrulama açık (önerilir). Kurumsal kullanımda özel SMTP tanımlayın.
- **Database → Replication**: migration `supabase_realtime` yayınına tabloları ekler; kontrol edin.
- **Storage**: `entry-photos` kovası migration ile özel (private) oluşturulur.

### Zamanlanmış uyarılar (pg_cron)

SQL Editor'de (değerleri kendi projenizle değiştirin):

```sql
create extension if not exists pg_cron;
create extension if not exists pg_net;

select cron.schedule('keypts-alerts', '*/15 * * * *', $$
  select net.http_post(
    url     := 'https://<PROJE_REF>.supabase.co/functions/v1/alerts-cron',
    headers := jsonb_build_object('x-cron-secret', '<CRON_SECRET>', 'content-type', 'application/json'),
    body    := '{}'::jsonb
  );
$$);
```

Anlık uyarılar (ölüm eşiği, sıcaklık, bekleme süresi çakışması) kayıt anında tetikleyiciyle üretilir; cron yalnızca zaman bazlı uyarıları üretir ve push iletimini yapar.

## 2. Mobil uygulama

```bash
cd mobile
cp .env.example .env          # Supabase URL ve anon anahtarını girin
npm install
npx expo start                # Expo Go veya geliştirme derlemesi ile açın
```

> Push bildirimleri Expo Go'da sınırlıdır; gerçek cihazda **development build** kullanın:
> `npx expo install expo-dev-client && eas build --profile development --platform android`

### EAS derleme

```bash
npm i -g eas-cli
eas login
eas init                       # projectId'yi app.json'a yazar
eas build:configure
eas secret:create --name EXPO_PUBLIC_SUPABASE_URL --value https://...
eas secret:create --name EXPO_PUBLIC_SUPABASE_ANON_KEY --value ...
eas build --platform android --profile production
eas build --platform ios --profile production
eas submit --platform ios      # / android
```

Android push için Firebase projesi oluşturup `google-services.json` dosyasını `mobile/` altına koyun ve `app.json → android.googleServicesFile` ekleyin; FCM V1 anahtarını `eas credentials` ile yükleyin.

## 3. Yayın öncesi kontrol listesi

- [ ] `supabase/tests/run.sh` gerçek projenin bir kopyasına karşı yeşil
- [ ] İki farklı çiftlik hesabıyla çapraz erişim denendi (Senaryo 10)
- [ ] Uçak modunda 10+ kayıt girildi, bağlantı açılınca hepsi tek seferde ve mükerrersiz geldi (Senaryo 7)
- [ ] Push bildirimi gerçek iOS ve Android cihazda alındı
- [ ] KVKK aydınlatma metni ve gizlilik politikası hazırlandı (mağazalar zorunlu tutar)
- [ ] Supabase yedekleme (PITR) planı açık

## 4. Demo ortamı

Satış sunumu veya eğitim için sunucusuz demo: `EXPO_PUBLIC_APP_ENV=demo` ile derleyin (`eas build --profile preview` + EAS secret). Demo verisi cihazda üretilir, her ekranda **DEMO** etiketi görünür, gerçek hesaplara erişmez. Üretim derlemelerinde bu değişkeni **tanımlamayın**.

## 5. Lisanslar (üçüncü taraf varlıklar)

| Varlık | Lisans | Ticari kullanım |
|---|---|---|
| Inter yazı tipi (`@expo-google-fonts/inter`) | SIL Open Font License 1.1 | Serbest |
| Lucide ikonları (`lucide-react-native`) | ISC | Serbest |
| KEY PTS logosu ve kümes sahnesi | Bu projede vektör olarak çizildi | Proje sahibine aittir; tescil öncesi marka tasarımcısı kontrolü önerilir |
| Giriş ekranı fotoğrafı | Kullanılmadı | Lisanslı fotoğraf `assets/images/login-hero.jpg` olarak eklenebilir |
