# KEY PTS — Referans Görsel Analizi ve Görsel Sadakat Raporu

Kaynak: kullanıcının yüklediği KEY PTS sunum kolajı (1536×1024 piksel, 9 telefon ekranı + marka paneli).
Renkler kolajdaki bölgelerin medyan pikseli alınarak örneklendi. Sonuç token'ları `mobile/src/theme/` altında.

## 1. Görsel analiz

| Alan | Referansta gözlenen | Uygulamadaki karşılığı |
|---|---|---|
| **Renk sistemi** | Koyu lacivert başlıklar, turuncu birincil eylem, beyaz ve açık gri yüzeyler; durumlar yeşil, kırmızı, mor, mavi ikonlarla | `colors.ts`: navy `#10243A` (örnek `#10233B`), turuncu `#EB7615` → `#E2680B` dikey gradyan (örnek `#EB7615` / `#E36A0C`), sayfa zemini `#F5F7FA` (örnek `#F6F7F8`) |
| **Başlık alanları** | Lacivert şerit, solda geri oku, ortalanmış beyaz kalın başlık; içerik yüzeyi başlığın üstüne yuvarlak köşeyle biner | `layout/Screen.tsx`: `NavyHeader` + 18 px yuvarlatılmış, −18 px bindirmeli yüzey |
| **Dashboard başlığı** | Sol üstte küçük beyaz logo, sağda zil; “Merhaba, / Çiftlik Genel Durumu”; beyaz sürü seçici kart başlık sınırına biner | `overlap` özelliği ile sınıra binen `SelectCard` |
| **Kart düzeni** | 2 sütun KPI kartları; ikon solda, küçük etiket, büyük kalın değer, alt açıklama | `KpiTile` (2 sütun, kart radius 14) |
| **Butonlar** | Tam genişlik, turuncu gradyan, beyaz metin ve önde ikon (✓, +). Giriş ekranında hap şeklinde. İkincil: açık mavi zemin, ince çerçeve (“+ Kümes Ekle”) | `Button` primary / secondary / `pill` |
| **Tipografi** | Geometrik sans-serif; başlıklar kalın, değerler büyük ve kalın; Türkçe karakterler | Inter 400–800 (SIL OFL), logo yazısı Inter ExtraBold Italic |
| **Boşluk** | Kenar boşluğu ~16 px, kartlar arası ~12 px | 4 px tabanlı ölçek; ekran yatay boşluğu 16 |
| **İkonlar** | İnce çizgisel; modül ikonları açık tonlu kare zeminde (kalp kırmızı, alev turuncu, ilaç mavi, tartı mor, termometre kırmızı) | Lucide (ISC) + `IconBadge`; `colors.module` ile aynı işlev her ekranda aynı renk |
| **Liste bileşenleri** | İkon + etiket + sağda değer + ok; ince ayraçlar | `ListRow`, `ListCard` |
| **Form bileşenleri** | Üstte küçük etiketli çerçeveli seçim kutuları (Kümes, Tarih); satır başına ikon + etiket + sağda küçük sayı kutusu | `FramedField`, `InputRow`, takvimli `DatePickerSheet` |
| **Grafik dili** | Kırmızı ince çizgi, yumuşak kırmızı alan dolgusu, % ekseni, dokununca kırmızı balon “%0,53 (23. gün)” | `TrendChart` (alan dolgusu + dokunmatik balon) |
| **Zaman çizelgesi** | Solda renkli daire ikonlar ve bağlantı çizgisi; aktif gün açık turuncu zeminli | `flock/timeline.tsx` |
| **Alt navigasyon** | Beyaz zemin, çizgisel ikonlar, etkin sekme turuncu | Expo Router `Tabs` (5 sekme: Ana Sayfa, Kümesler, Kayıt Ekle, Raporlar, Profil) |
| **Logo** | Turuncu kavisli boyun çizgisi, kırmızı ibik ve sakal, beyaz yüz, sarı gaga; “KEY” lacivert, “PTS” turuncu eğik kalın; altında “Poultry Tracking System” ve turuncu kavis | `assets/branding/build_logo.py` (vektör yeniden çizim) |

## 2. Ekran bileşen haritası

| Referans ekranı | Rota | Yeniden kullanılan bileşenler |
|---|---|---|
| Giriş | `(auth)/sign-in` | LogoFull, DarkField, Button(pill), PoultryHouseScene |
| Dashboard | `(tabs)/index` | Screen(overlap), LogoHeader, SelectCard, KpiTile, StatusPill, SectionHeader, SyncStatusLine |
| Kümes 1 | `house/[id]` | StatBox ×3, UnderlineTabs, ListRow + IconBadge, StickyFooter, TrendChart, BarChart |
| Günlük Kayıt Ekle | `(tabs)/record` | FramedField, DatePickerSheet, InputRow, TextField, StickyFooter |
| İlaç Ekle / Seç | `record/medications` | SearchField, Checkbox, bilgi paneli, StickyFooter |
| Raporlar | `(tabs)/reports` | PillTabs, SelectCard, TintedKpi ×4, TrendChart |
| Sürü Takvimi | `flock/timeline` | SelectCard, zaman çizelgesi öğesi, DatePickerSheet |
| Kümesler | `(tabs)/houses` | Card, Pill(Aktif/Pasif), Button(secondary) |
| Ayarlar | `(tabs)/profile` | ListCard, ListRow |

Referansta bulunmayıp spesifikasyonun istediği ekranlar da aynı sistemle kuruldu: Splash, Şifremi Unuttum, İlk Kurulum, Çiftlik Oluştur, Kümes Ekle, Ölüm Takvimi, Kömür, İlaç geçmişi, Tartım, Sıcaklık, Notlar, Çalışan Yönetimi, Bildirimler, Geçmiş dönemler, Dönem kapatma, Veri Yedekleme, Güvenlik, Bekleyen Kayıtlar.

## 3. Görsel sadakat kontrol listesi (ekran görüntüleriyle)

Yöntem: Uygulama demo modunda web için derlendi, Chrome'da 390×844 @2x boyutunda ekran görüntüsü alındı (`tools/screenshots.py`). Her ekran, kolajdaki karşılığıyla yan yana konuldu (`tools/compare.py`). Sonuçlar: `screenshots/karsilastirma-*.png` ve `screenshots/00-referans-karsilastirma.png`.

| Ölçüt | İlk tur bulgusu | Yapılan düzeltme | Sonuç |
|---|---|---|---|
| Renk benzerliği | Uygun | — | ✓ |
| Başlık oranları | Dashboard'da sürü seçici başlık metninin üstüne biniyordu | Başlık alt boşluğu artırıldı (`extraBottom` 46) | ✓ |
| Logo oranları | Giriş ekranında logo küçüktü | %22 büyütüldü, üst boşluk artırıldı | ✓ |
| Form alanları | Giriş alanları köşeliydi; referansta hap şeklinde | Giriş ekranı alanları ve butonu hap şekline getirildi | ✓ |
| Tipografi boyutları | Referans metinleri ~%15 daha büyüktü | Gövde 15, etiket 13,5, kart başlığı 16, sayfa başlığı 21 | ✓ |
| Kart oranları | KPI kartları referanstan uzundu | Etiket ve alt satır tek satıra indirildi, iç boşluk azaltıldı | ✓ (uzun Türkçe etiketlerde 2 satıra izin var) |
| İkon hizalaması | Zaman çizelgesi daireleri küçüktü | 48 px daire, 24 px ikon | ✓ |
| Grafik oranları | Eksen değerleri düzensizdi (%0,03 / %0,05) | Çeyrek adımlı “yuvarlak” eksen | ✓ |
| Günlük Kayıt satırları | “Kömür Kullanımı (torba)” etiketi kesiliyordu | Torba ağırlığı ve birim seçimi satırın altına taşındı | ✓ |
| Alt navigasyon | Etiketler kırpılıyordu | Yükseklik 66 px | ✓ |
| Tartım grafiği | Ölçümler arası boşluk nedeniyle çizgi görünmüyordu | Yalnız gerçek ölçüm noktaları birleştirildi (`connectGaps`) | ✓ |
| Yüzey/gölge | Uygun (ince kenarlık + düşük opaklıklı gölge) | — | ✓ |

## 4. Referanstan bilinçli sapmalar (gerekçeli)

1. **“Sağlıklı” etiketi → “Normal / Dikkat / Kritik / Kayıt yok”.** Spesifikasyon renklerin teşhis değil, eşik karşılaştırması olmasını istiyor. Bu yüzden etiket bir sağlık iddiası taşımıyor ve durumun metin gerekçesi de gösteriliyor.
2. **Kümes Özeti'nde “40.000 baş” (başlangıç) yerine mevcut hayvan sayısı.** Spesifikasyonun 11.3 maddesi “Mevcut” göstermeyi istiyor; kapasite ile mevcut sayı karıştırılmaz.
3. **KPI kartları.** Referansta “Toplam Civciv / Toplam Ölüm” var; spesifikasyonun 11.2 maddesi “Toplam Mevcut Hayvan / Bugünkü Ölüm / Ort. Canlı Ağırlık / Bugünkü Kömür” istiyor. Spesifikasyon izlendi; toplam ölüm ve oranı alt satırda.
4. **Alt menü.** Referansta “Daha Fazla” var; spesifikasyondaki 5 sekme kullanıldı (Kümesler + Profil).
5. **Giriş ekranındaki fotoğraf.** Referanstaki kümes fotoğrafı AI üretimi bir kolaja ait ve lisansı belirsiz. Yerine kodla çizilmiş vektör bir kümes içi sahnesi kondu. Lisanslı gerçek bir fotoğraf `PoultryHouseScene photo={require(...)}` ile tek satırda takılabilir.
6. **“Kullanıcı Adı” → “E-posta”.** Kimlik doğrulama Supabase e-posta ve şifresiyle çalışıyor.
7. **Durum çubuğu (09:41).** Web ekran görüntülerinde işletim sistemi durum çubuğu yok; cihazda güvenli alan (safe area) ile çalışır.
8. **Referanstaki tutarsız örnek rakamlar** (ör. “1,246 torba”, 3 × 40.000 kümes ile “120.000 baş” arasındaki ilişki) iş kuralına taşınmadı. Demo verisi tek bir modelden üretildiği için bütün ekranlarda matematiksel olarak tutarlı.

## 5. Logo

Referanstaki logo küçük ve rasterdı; ayrıntıları (ibik dilimleri, göz şekli) birebir okunamıyor. Bu nedenle marka karakteri korunarak **temiz bir vektör yorumu** çizildi. Bu, referanstaki logonun birebir kopyası değildir. Dosyalar `assets/branding/`:
`keypts-logo-full-light/dark.svg` (tam kurumsal), `keypts-logo-horizontal-light/dark.svg` (yatay), `keypts-symbol*.svg` (sembol), `keypts-app-icon.svg` + `png/app-icon-*.png` (uygulama ikonu), `keypts-adaptive-foreground.svg` (Android), `keypts-splash.svg` (splash), `keypts-mono.svg` (tek renk bildirim ikonu).
Yazılar Inter fontundan vektör yola çevrilmiştir; font kurulu olmayan ortamlarda da doğru görünür. Ticari tescil öncesinde bir marka tasarımcısının son dokunuşu önerilir.
