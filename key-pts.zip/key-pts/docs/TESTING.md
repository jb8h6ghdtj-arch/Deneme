# Test Raporu ve Kalite Kapısı (yerel sürüm)

Tarih: 06.11.2026. Ortam: Linux bulut çalışma alanı. **Gerçek iPhone/Android cihaz, simülatör veya emülatör kullanılamadı.**

## Otomatik testler (çalıştırıldı)
| Test | Komut | Sonuç |
|---|---|---|
| TypeScript (strict) | `npx tsc --noEmit` | 0 hata |
| Birim + entegrasyon (Jest) | `npx jest` | 42/42 geçti |
| Web E2E gezinme (Playwright + Chrome, 390×844) | `python3 e2e/flow.py` | 20/20 geçti |
| Duyarlı tasarım (7 boyut × 7 ekran = 49 görüntü, taşma/kırpma denetimi) | `python3 e2e/responsive.py` | 0 sorun |
| iOS + Android JS paketleme (Metro) | `npx expo export --platform ios --platform android` | başarılı (derleme hatası yok) |

Jest kapsamı: yerel veri diske yazılır ve soğuk açılışta geri yüklenir; atomik kayıt (bir parça hatalıysa hiçbiri yazılmaz); aynı işlem kimliğiyle çift gönderim tek kayıt; tek formda iki döneme kayıt reddi; gelecek tarih / girişten önce / mevcuttan fazla ölüm reddi; kümes başına tek aktif dönem; yanlış şifre reddi; çıkışta verinin korunması; tümünü sıfırla; taslak ayrışması (Kümes 1 taslağı Kümes 2'ye taşınmaz), ilaç seçiminin diğer değerleri koruması; hesaplamalar, biçimlendirme, raporlar, örnek veri tutarlılığı.

## E2E senaryoları (şartname A–I)
| | Senaryo | Durum |
|---|---|---|
| A | Ana Sayfa → Kümes 1 → Günlük Kayıt → İlaç Seç → Onayla → aynı forma dönüş, girilen değer korunur | ✅ web'de doğrulandı |
| B | Kaydedilmemiş değişiklikle geri: uyarı; Düzenlemeye Devam Et / Taslağı Sakla; taslak geri yüklenir | ✅ web'de doğrulandı |
| C | Kaydet → kümes detayına dönüş; yanlış kümeye yazma reddi | ✅ web + Jest |
| D | Kümes değişince önceki kümenin değerleri taşınmaz | ✅ web + Jest |
| E | Çalışan yetkisi | ➖ Uygulanamaz: yerel sürümde tek kullanıcı (çiftlik sahibi) var |
| F | Uygulama kapatılıp açılınca veri/oturum/taslak korunur | ⚠️ Yalnızca simülasyon: web'de sayfa yenileme + Jest soğuk açılış. Gerçek cihazda uygulamayı öldürüp açma test edilmedi |
| G | Var olmayan kümes / kayıt / rota → güvenli "bulunamadı" ekranı | ✅ web'de doğrulandı |
| H | Çift dokunma aynı ekranı iki kez açmaz | ✅ web'de doğrulandı |
| I | Çıkış → giriş ekranı; geri tuşu korumalı ekranı açmaz | ✅ web'de doğrulandı (tarayıcı geri tuşu) |

## Platform matrisi
| Platform | Durum |
|---|---|
| Web (Chrome, mobil boyutlar) | ✅ E2E + görsel test edildi |
| iOS | ⚠️ Yalnızca JS paketi derlendi. Cihaz/simülatörde **test edilmedi** (kaydırarak geri, klavye, çentik/güvenli alan, SQLite) |
| Android | ⚠️ Yalnızca JS paketi derlendi. Cihaz/emülatörde **test edilmedi** (donanım geri tuşu, SQLite, ikon/splash) |
| Büyük sistem yazı boyutu | ⚠️ Kod tarafında dar/büyük yazıda tek sütun kuralı var; gerçek erişilebilirlik ayarıyla **test edilmedi** |

## Kalite kapısı
- [x] Sunucu bağımlılığı yok (Supabase, bildirim, ağ paketleri kaldırıldı); veri katmanı tek dosyadan değiştirilebilir
- [x] Günlük kayıt atomik, çift dokunmaya karşı korumalı, yanlış kümeye yazamaz
- [x] Taslaklar anahtarlı, uygulama yeniden açılınca korunur (web/Jest)
- [x] Kaydedilmemiş değişiklik uyarısı üç seçenekle
- [x] Bulunamadı ekranları (kümes, kayıt formu, ilaç seçimi, tekil kayıt, bilinmeyen rota)
- [x] 320–430 px genişlikte yatay taşma ve "…" ile kırpılmış önemli değer yok (web)
- [x] Hatalar cihaz içi günlüğe yazılıyor (Ayarlar → Veri Yönetimi → Hata günlüğü)
- [ ] iOS/Android gerçek cihaz testi — **yapılmadı**
- [ ] Büyük sistem yazısıyla gerçek test — **yapılmadı**
- [ ] Android donanım geri tuşu / iOS kenardan kaydırma — **cihazda doğrulanmadı** (kod: usePreventRemove ile aynı uyarıya bağlı)
