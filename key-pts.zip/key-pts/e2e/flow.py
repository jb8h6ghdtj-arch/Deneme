# KEY PTS web derlemesi üzerinde uçtan uca gezinme testleri (Playwright + Chrome).
import sys, json, time
from playwright.sync_api import sync_playwright, expect
URL = 'http://localhost:8090'
res = []
def check(name, cond, note=''):
    res.append((name, bool(cond), note)); print(('PASS ' if cond else 'FAIL ') + name, note, flush=True)

def T(p, s, **kw): return p.get_by_text(s, exact=kw.get('exact', False)).filter(visible=True).first
def I(p): return p.locator('input').filter(visible=True)

with sync_playwright() as pw:
    b = pw.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
    ctx = b.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2, locale='tr-TR')
    p = ctx.new_page(); errs = []
    p.on('pageerror', lambda e: errs.append(str(e)))
    p.goto(URL); p.wait_for_timeout(2500)
    shot = lambda n: p.screenshot(path=f'/tmp/e2e-{n}.png')
    # Kurulum: hesap + örnek veri
    T(p, 'Kuruluma Başla').click(); p.wait_for_timeout(600)
    ins = I(p)
    for i, v in enumerate(['Ahmet Yılmaz', 'ahmet', 'gizli1234', 'gizli1234']): ins.nth(i).fill(v)
    T(p, 'Devam', exact=True).click(); p.wait_for_timeout(1500)
    T(p, 'Örnek verilerle incele').click(); p.wait_for_timeout(3000); shot('home')
    check('Kurulum → Ana Sayfa', T(p, 'Kümes 1').is_visible())

    # A: Ana Sayfa → Kümes 1 → Günlük Kayıt → İlaç Seç → Onayla → değerler korunur
    T(p, 'Kümes 1').click(); p.wait_for_timeout(1200)
    check('A1 Kümes detayı açıldı', p.url.find('/house/') > 0, p.url)
    T(p, 'Günlük Kayıt Ekle').click(); p.wait_for_timeout(1200)
    check('A2 Günlük kayıt formu (doğru kümes)', '/record/' in p.url and T(p, 'Kümes 1').is_visible(), p.url)
    rec_url = p.url
    fields = I(p); fields.nth(0).fill('17'); p.wait_for_timeout(200)
    T(p, 'Kullanılan İlaçlar').click(); p.wait_for_timeout(1200); shot('meds')
    check('A3 İlaç seç ekranı', '/record/medications' in p.url, p.url)
    p.get_by_role('checkbox').first.click(); p.wait_for_timeout(400)
    I(p).nth(1).fill('1'); p.wait_for_timeout(200)
    T(p, 'Onayla', exact=True).click(); p.wait_for_timeout(1200); shot('after-meds')
    check('A4 Onayla → aynı forma dönüş', p.url == rec_url, p.url)
    check('A5 Ölüm değeri korundu (17)', I(p).nth(0).input_value() == '17')
    # Kaydedilmemiş değişiklikle geri → onay penceresi
    p.go_back(); p.wait_for_timeout(1000); shot('leave')
    check('B1 Kaydedilmemiş değişiklik uyarısı', T(p, 'Düzenlemeye Devam Et').is_visible())
    T(p, 'Düzenlemeye Devam Et').click(); p.wait_for_timeout(500)
    check('B2 Devam → formda kalındı, değer duruyor', I(p).nth(0).input_value() == '17')
    p.go_back(); p.wait_for_timeout(800); T(p, 'Taslağı Sakla').click(); p.wait_for_timeout(1200)
    check('B3 Taslağı Sakla → kümes detayına dönüş', '/house/' in p.url, p.url)
    T(p, 'Günlük Kayıt Ekle').click(); p.wait_for_timeout(1200)
    check('B4 Taslak geri yüklendi', I(p).nth(0).input_value() == '17')
    # C: Kaydet → doğru kümeye yazılır, geri dönüş
    T(p, 'Kaydet', exact=True).click(); p.wait_for_timeout(2500); shot('saved')
    check('C1 Kaydet → kümes detayına dönüş', '/house/' in p.url and '/record/' not in p.url, p.url)
    # D: Kümes 2 formu Kümes 1 taslağını taşımaz
    p.goto(URL + '/houses'); p.wait_for_timeout(1500)
    T(p, 'Kümes 2').click(); p.wait_for_timeout(1000); T(p, 'Günlük Kayıt Ekle').click(); p.wait_for_timeout(1200)
    check('D1 Kümes 2 formu boş (taslak karışmadı)', I(p).nth(0).input_value() == '')
    # G: Geçersiz adres / silinmiş kayıt
    p.goto(URL + '/house/yok-boyle-kumes'); p.wait_for_timeout(1500); shot('notfound-house')
    check('G1 Var olmayan kümes → güvenli "bulunamadı"', T(p, 'bulunamadı').is_visible())
    p.goto(URL + '/record/yok'); p.wait_for_timeout(1500)
    check('G2 Var olmayan kümese kayıt formu açılmaz', T(p, 'bulunamadı').is_visible())
    p.goto(URL + '/olmayan/sayfa'); p.wait_for_timeout(1500)
    check('G3 Bilinmeyen rota → Kayıt Bulunamadı', T(p, 'Kayıt Bulunamadı').is_visible())
    # H: Çift dokunma aynı ekranı iki kez açmaz
    p.goto(URL + '/houses'); p.wait_for_timeout(1500)
    T(p, 'Kümes 3').dblclick(); p.wait_for_timeout(1200)
    p.go_back(); p.wait_for_timeout(1000)
    check('H1 Çift dokunma → tek ekran (bir geri ile listeye dönüldü)', p.url.endswith('/houses'), p.url)
    # I: Çıkış → geçmiş temizlenir, geri ile uygulamaya dönülmez
    p.goto(URL + '/profile'); p.wait_for_timeout(1500)
    T(p, 'Çıkış').click(); p.wait_for_timeout(1500)
    check('I1 Çıkış → giriş ekranı', T(p, 'Giriş Yap').is_visible(), p.url)
    p.go_back(); p.wait_for_timeout(1500)
    check('I2 Geri tuşu korumalı ekranı açmaz', T(p, 'Giriş Yap').is_visible(), p.url)
    # F (yeniden açma simülasyonu): giriş → sayfayı yenile → veri ve oturum kalıcı
    ins = I(p); ins.nth(0).fill('ahmet'); ins.nth(1).fill('gizli1234'); T(p, 'Giriş Yap').click(); p.wait_for_timeout(2500)
    p.reload(); p.wait_for_timeout(2500)
    check('F1 Yeniden açılışta oturum ve veri korunur', T(p, 'Kümes 1').is_visible())
    check('Konsolda sayfa hatası yok', not errs, '; '.join(errs)[:300])
    b.close()
json.dump(res, open('/tmp/e2e.json', 'w'), ensure_ascii=False)
print(f"{sum(r[1] for r in res)}/{len(res)} geçti")
