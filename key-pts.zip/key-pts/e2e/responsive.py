# 7 ekran boyutunda ana ekranların görüntüsü + yatay taşma ve kırpılmış metin denetimi (web derlemesi).
import json
from playwright.sync_api import sync_playwright
URL='http://localhost:8090'; OUT='/tmp/resp'
SIZES=[(320,568),(360,740),(375,812),(390,844),(393,852),(412,915),(430,932)]
PAGES=[('ana-sayfa','/'),('kumesler','/houses'),('kumes-detay','/house/h1-demo'),('gunluk-kayit','/record/h1-demo'),('raporlar','/reports'),('ayarlar','/profile'),('bildirimler','/notifications')]
CHECK="""() => { const W = innerWidth; const over = [];
  for (const el of document.querySelectorAll('div,span')) { const r = el.getBoundingClientRect(); if (r.width && (r.right > W + 1 || r.left < -1) && getComputedStyle(el).position !== 'fixed') { const t = (el.innerText||'').trim(); if (t) over.push(t.slice(0,40)); } }
  const clipped = [...document.querySelectorAll('div[dir],span')].filter(e => { const s = getComputedStyle(e); return s.textOverflow === 'ellipsis' && e.scrollWidth > e.clientWidth + 1; }).map(e => e.innerText.slice(0,40));
  return { docOverflow: document.documentElement.scrollWidth > W + 1, over: [...new Set(over)].slice(0,5), clipped: clipped.slice(0,5) }; }"""
import os; os.makedirs(OUT, exist_ok=True); report=[]
with sync_playwright() as pw:
    b=pw.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    ctx=b.new_context(viewport={'width':390,'height':844},device_scale_factor=2,locale='tr-TR'); p=ctx.new_page()
    p.goto(URL); p.wait_for_timeout(2500); p.get_by_text('Kuruluma Başla').first.click(); p.wait_for_timeout(600)
    ins=p.locator('input').filter(visible=True)
    for i,v in enumerate(['Ahmet Yılmaz','ahmet','gizli1234','gizli1234']): ins.nth(i).fill(v)
    p.get_by_text('Devam',exact=True).first.click(); p.wait_for_timeout(1500); p.get_by_text('Örnek verilerle incele').first.click(); p.wait_for_timeout(3000)
    for w,h in SIZES:
        p.set_viewport_size({'width':w,'height':h})
        for name,path in PAGES:
            p.goto(URL+path); p.wait_for_timeout(1600)
            r=p.evaluate(CHECK); r.update(size=f'{w}x{h}',page=name); report.append(r)
            p.screenshot(path=f'{OUT}/{w}x{h}-{name}.png')
    b.close()
json.dump(report,open(f'{OUT}/report.json','w'),ensure_ascii=False,indent=1)
bad=[r for r in report if r['docOverflow'] or r['over'] or r['clipped']]
print(len(report),'görüntü;',len(bad),'sorunlu'); [print(r['size'],r['page'],r['over'],r['clipped']) for r in bad[:25]]
