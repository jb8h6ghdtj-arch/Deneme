// KEY PTS — Zamanlanmış uyarılar + push gönderimi (Supabase Edge Function, Deno)
//
// 1) run_scheduled_alerts(): eksik günlük rapor, yaklaşan kesim uyarılarını üretir
// 2) Gönderilmemiş bildirimleri (pushed_at IS NULL) Expo Push API ile cihazlara iletir
//
// Tetikleyici: pg_cron (her 15 dk) → bu fonksiyon. Bkz. docs/DEPLOYMENT.md
// Gerekli gizli değişkenler (Supabase → Edge Functions → Secrets):
//   CRON_SECRET                 — çağrıyı doğrulamak için rastgele uzun bir değer
//   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY — Supabase tarafından otomatik sağlanır
//   EXPO_ACCESS_TOKEN (opsiyonel) — Expo push güvenlik ayarı açıksa
import { createClient } from 'npm:@supabase/supabase-js@2';

const EXPO_URL = 'https://exp.host/--/api/v2/push/send';

Deno.serve(async (req) => {
  const secret = Deno.env.get('CRON_SECRET');
  if (!secret || req.headers.get('x-cron-secret') !== secret) {
    return new Response('unauthorized', { status: 401 });
  }

  const db = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {
    auth: { persistSession: false },
  });

  const { data: generated, error: alertErr } = await db.rpc('run_scheduled_alerts');
  if (alertErr) return Response.json({ error: alertErr.message }, { status: 500 });

  // Son 24 saatte üretilmiş, henüz gönderilmemiş bildirimler
  const { data: pending, error } = await db
    .from('notifications')
    .select('id, user_id, org_id, title, body, severity, house_id, flock_id, houses(name)')
    .is('pushed_at', null)
    .gte('created_at', new Date(Date.now() - 24 * 3600_000).toISOString())
    .limit(500);
  if (error) return Response.json({ error: error.message }, { status: 500 });
  if (!pending?.length) return Response.json({ generated, pushed: 0 });

  const userIds = [...new Set(pending.map((n) => n.user_id))];
  const [{ data: tokens }, { data: prefs }] = await Promise.all([
    db.from('push_tokens').select('user_id, token').in('user_id', userIds),
    db.from('notification_preferences').select('user_id, org_id, push_enabled').in('user_id', userIds),
  ]);

  const messages: { to: string; title: string; body: string; sound: string; priority: string; channelId: string; data: unknown; _nid: string }[] = [];
  for (const n of pending) {
    const pref = prefs?.find((p) => p.user_id === n.user_id && p.org_id === n.org_id);
    if (pref && !pref.push_enabled) continue;
    for (const t of tokens?.filter((x) => x.user_id === n.user_id) ?? []) {
      messages.push({
        // Kilit ekranında ayrıntılı çiftlik verisi gösterilmez: yalnız kümes adı ve uyarı düzeyi.
        // Sayılar ve açıklamalar uygulama içi bildirim listesindedir.
        to: t.token,
        title: n.severity === 'critical' ? 'KEY PTS · Kritik uyarı' : 'KEY PTS · Yeni uyarı',
        body: `${(n as { houses?: { name?: string } }).houses?.name ?? 'Kümes'} için yeni bir uyarı var. Ayrıntılar uygulamada.`,
        sound: 'default',
        priority: n.severity === 'critical' ? 'high' : 'default', channelId: 'alerts',
        data: { houseId: n.house_id, flockId: n.flock_id, notificationId: n.id }, _nid: n.id,
      });
    }
  }

  const headers: Record<string, string> = { 'content-type': 'application/json', accept: 'application/json' };
  const expoToken = Deno.env.get('EXPO_ACCESS_TOKEN');
  if (expoToken) headers.authorization = `Bearer ${expoToken}`;

  const invalidTokens: string[] = [];
  for (let i = 0; i < messages.length; i += 100) {
    const chunk = messages.slice(i, i + 100);
    const res = await fetch(EXPO_URL, { method: 'POST', headers, body: JSON.stringify(chunk.map(({ _nid, ...m }) => m)) });
    if (!res.ok) continue; // bir sonraki çalıştırmada tekrar denenir
    const json = await res.json();
    (json.data ?? []).forEach((ticket: { status: string; details?: { error?: string } }, idx: number) => {
      if (ticket.status === 'error' && ticket.details?.error === 'DeviceNotRegistered') invalidTokens.push(chunk[idx].to);
    });
  }

  // İletim denendi: tüm bekleyenleri işaretle (uygulama içi listede kalmaya devam eder)
  await db.from('notifications').update({ pushed_at: new Date().toISOString() }).in('id', pending.map((n) => n.id));
  if (invalidTokens.length) await db.from('push_tokens').delete().in('token', invalidTokens);

  return Response.json({ generated, pushed: messages.length, invalidTokens: invalidTokens.length });
});
