-- =====================================================================
-- KEY PTS — Poultry Tracking System
-- Migration 001: Core schema, constraints, indexes
-- Target: Supabase (PostgreSQL 15+)
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------
create type public.app_role as enum ('owner', 'manager', 'worker');
create type public.heating_type as enum ('coal', 'gas', 'electric', 'biomass', 'other', 'none');
create type public.flock_status as enum ('active', 'completed', 'cancelled');
-- Sürü hareketleri: ölüm dışındaki tüm giriş/çıkışlar
create type public.movement_type as enum ('addition', 'transfer_in', 'transfer_out', 'cull', 'other_exit');
create type public.weight_unit as enum ('g', 'kg');
create type public.weight_input_mode as enum ('average', 'total');
create type public.notification_kind as enum (
  'new_entry', 'mortality_threshold', 'missing_report', 'temperature_out_of_range',
  'slaughter_approaching', 'withdrawal_conflict', 'system'
);

-- ---------------------------------------------------------------------
-- Utility: updated_at trigger
-- ---------------------------------------------------------------------
create or replace function public.tg_set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- ---------------------------------------------------------------------
-- Tenancy
-- ---------------------------------------------------------------------
create table public.organizations (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (length(trim(name)) between 2 and 120),
  created_by  uuid references auth.users(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text check (full_name is null or length(full_name) <= 120),
  phone       text check (phone is null or length(phone) <= 32),
  locale      text not null default 'tr' check (locale in ('tr', 'en', 'ar')),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table public.organization_members (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references public.organizations(id) on delete cascade,
  user_id     uuid not null references auth.users(id) on delete cascade,
  role        public.app_role not null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (org_id, user_id)
);
create index on public.organization_members (user_id);

create table public.farms (
  id                    uuid primary key default gen_random_uuid(),
  org_id                uuid not null references public.organizations(id) on delete cascade,
  name                  text not null check (length(trim(name)) between 2 and 120),
  location_text         text,
  latitude              double precision check (latitude is null or latitude between -90 and 90),
  longitude             double precision check (longitude is null or longitude between -180 and 180),
  contact_name          text,
  contact_phone         text,
  contact_email         text,
  default_heating       public.heating_type not null default 'coal',
  default_coal_bag_kg   numeric(6,2) not null default 25 check (default_coal_bag_kg > 0 and default_coal_bag_kg <= 100),
  -- Civciv/piliç sınıflandırma sınırı (gün). Yönetici değiştirebilir.
  chick_phase_days      int not null default 15 check (chick_phase_days between 1 and 60),
  -- Gün numaralandırma standardı: 0 → giriş günü "0. Gün", 1 → giriş günü "1. Gün".
  -- Tüm görünümler ve uyarılar bu tek değeri kullanır.
  age_base              smallint not null default 0 check (age_base in (0, 1)),
  timezone              text not null default 'Europe/Istanbul',
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);
create index on public.farms (org_id);

create table public.houses (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references public.organizations(id) on delete cascade,
  farm_id       uuid not null references public.farms(id) on delete cascade,
  name          text not null check (length(trim(name)) between 1 and 60),
  capacity      int  not null check (capacity > 0 and capacity <= 1000000),
  heating_type  public.heating_type not null default 'coal',
  -- Kömür kullanılmayan kümeslerde sekme gizlenir
  coal_tracking boolean not null default true,
  sort_order    int not null default 0,
  archived_at   timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (farm_id, name)
);
create index on public.houses (org_id);
create index on public.houses (farm_id);

create table public.house_assignments (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references public.organizations(id) on delete cascade,
  house_id    uuid not null references public.houses(id) on delete cascade,
  user_id     uuid not null references auth.users(id) on delete cascade,
  -- Kümes bazlı yetki: record = günlük kayıt; manage = dönem/ekip/düzeltme (yalnız sorumlu rolünde etkili)
  permissions text[] not null default '{record}' check (permissions <@ array['record','manage']::text[] and 'record' = any(permissions)),
  created_by  uuid references auth.users(id) on delete set null,
  created_at  timestamptz not null default now(),
  unique (house_id, user_id)
);
create index on public.house_assignments (user_id);
create index on public.house_assignments (org_id);

create table public.invitations (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references public.organizations(id) on delete cascade,
  role         public.app_role not null check (role <> 'owner'),
  house_ids    uuid[] not null default '{}',
  email        text,
  code         text not null unique,
  invited_by   uuid not null references auth.users(id) on delete cascade,
  expires_at   timestamptz not null default now() + interval '7 days',
  accepted_by  uuid references auth.users(id) on delete set null,
  accepted_at  timestamptz,
  revoked_at   timestamptz,
  created_at   timestamptz not null default now()
);
create index on public.invitations (org_id);

-- ---------------------------------------------------------------------
-- Production cycles (Flocks)
-- ---------------------------------------------------------------------
create table public.flocks (
  id                       uuid primary key default gen_random_uuid(),
  org_id                   uuid not null references public.organizations(id) on delete cascade,
  farm_id                  uuid not null references public.farms(id) on delete cascade,
  house_id                 uuid not null references public.houses(id) on delete restrict,
  cycle_no                 int  not null,
  name                     text not null,
  placement_date           date not null,
  initial_count            int  not null check (initial_count > 0 and initial_count <= 1000000),
  breed                    text,
  expected_slaughter_date  date,
  responsible_user_id      uuid references auth.users(id) on delete set null,
  description              text,
  status                   public.flock_status not null default 'active',
  completed_at             timestamptz,
  closing_notes            text,
  created_by               uuid references auth.users(id) on delete set null default auth.uid(),
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now(),
  version                  int not null default 1,
  unique (house_id, cycle_no),
  check (expected_slaughter_date is null or expected_slaughter_date >= placement_date),
  check ((status = 'active') = (completed_at is null))
);
-- Bir kümeste aynı anda yalnızca bir aktif dönem olabilir
create unique index flocks_one_active_per_house on public.flocks (house_id) where status = 'active';
create index on public.flocks (org_id);
create index on public.flocks (farm_id, status);

-- ---------------------------------------------------------------------
-- Operational entries (shared column contract)
--   org_id / farm_id / house_id are derived from flock_id by trigger;
--   clients cannot spoof them.
--   entry_date   = kaydın ait olduğu iş günü (Türkiye saati)
--   created_at   = sunucuya gönderim zamanı
--   client_id    = cihazda üretilen UUID, mükerrer kaydı engeller
-- ---------------------------------------------------------------------
create table public.mortality_entries (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid not null unique,
  org_id      uuid not null references public.organizations(id) on delete cascade,
  farm_id     uuid not null references public.farms(id) on delete cascade,
  house_id    uuid not null references public.houses(id) on delete cascade,
  flock_id    uuid not null references public.flocks(id) on delete cascade,
  entry_date  date not null,
  count       int  not null check (count >= 0 and count <= 1000000),
  cause       text check (cause is null or cause in
                ('unknown','weak_chick','respiratory','digestive','leg_problem','heat_stress','cold_stress','crushing','predator','other')),
  note        text check (note is null or length(note) <= 1000),
  photo_path  text,
  recorded_at timestamptz,               -- cihazda kaydın girildiği an (offline için)
  created_by  uuid not null references auth.users(id) default auth.uid(),
  created_at  timestamptz not null default now(),
  updated_by  uuid references auth.users(id),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz,
  version     int not null default 1
);
create index on public.mortality_entries (flock_id, entry_date) where deleted_at is null;
create index on public.mortality_entries (org_id, entry_date);

create table public.coal_entries (
  id             uuid primary key default gen_random_uuid(),
  client_id      uuid not null unique,
  org_id         uuid not null references public.organizations(id) on delete cascade,
  farm_id        uuid not null references public.farms(id) on delete cascade,
  house_id       uuid not null references public.houses(id) on delete cascade,
  flock_id       uuid not null references public.flocks(id) on delete cascade,
  entry_date     date not null,
  bag_count      numeric(8,2) not null check (bag_count >= 0 and bag_count <= 1000),
  bag_weight_kg  numeric(6,2) not null check (bag_weight_kg > 0 and bag_weight_kg <= 100),
  total_kg       numeric(10,2) generated always as (bag_count * bag_weight_kg) stored,
  coal_type      text,
  unit_price     numeric(10,2) check (unit_price is null or unit_price >= 0), -- torba başı, opsiyonel maliyet
  note           text check (note is null or length(note) <= 1000),
  recorded_at    timestamptz,
  created_by     uuid not null references auth.users(id) default auth.uid(),
  created_at     timestamptz not null default now(),
  updated_by     uuid references auth.users(id),
  updated_at     timestamptz not null default now(),
  deleted_at     timestamptz,
  version        int not null default 1
);
create index on public.coal_entries (flock_id, entry_date) where deleted_at is null;

create table public.medication_products (
  id                 uuid primary key default gen_random_uuid(),
  org_id             uuid not null references public.organizations(id) on delete cascade,
  name               text not null check (length(trim(name)) between 1 and 120),
  -- Kategori ürün adının yerine geçmez; filtreleme ve raporlama içindir.
  category           text not null default 'other' check (category in
                       ('antibiotic','vitamin','electrolyte','probiotic','coccidiostat','respiratory_support','liver_support','vaccine','disinfectant','other')),
  active_ingredient  text,
  default_unit       text not null default 'ml',
  default_method     text,
  withdrawal_days    int not null default 0 check (withdrawal_days between 0 and 365),
  notes              text,
  is_active          boolean not null default true,
  created_by         uuid references auth.users(id) default auth.uid(),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);
create unique index medication_products_org_name on public.medication_products (org_id, lower(name));

create table public.medication_applications (
  id                   uuid primary key default gen_random_uuid(),
  client_id            uuid not null unique,
  org_id               uuid not null references public.organizations(id) on delete cascade,
  farm_id              uuid not null references public.farms(id) on delete cascade,
  house_id             uuid not null references public.houses(id) on delete cascade,
  flock_id             uuid not null references public.flocks(id) on delete cascade,
  product_id           uuid not null references public.medication_products(id) on delete restrict,
  product_name         text not null default '',       -- uygulama anındaki ad (snapshot)
  entry_date           date not null,
  amount               numeric(12,3) not null check (amount > 0),
  unit                 text not null check (unit in ('ml','l','g','kg','dose','tablet','other')),
  method               text check (method is null or method in ('drinking_water','feed','spray','injection','eye_drop','other')),
  vet_instruction_ref  text,
  withdrawal_days      int not null default 0 check (withdrawal_days between 0 and 365),
  withdrawal_end_date  date generated always as (entry_date + withdrawal_days) stored,
  note                 text check (note is null or length(note) <= 1000),
  recorded_at          timestamptz,
  created_by           uuid not null references auth.users(id) default auth.uid(),
  created_at           timestamptz not null default now(),
  updated_by           uuid references auth.users(id),
  updated_at           timestamptz not null default now(),
  deleted_at           timestamptz,
  version              int not null default 1
);
create index on public.medication_applications (flock_id, entry_date) where deleted_at is null;

create table public.weight_measurements (
  id             uuid primary key default gen_random_uuid(),
  client_id      uuid not null unique,
  org_id         uuid not null references public.organizations(id) on delete cascade,
  farm_id        uuid not null references public.farms(id) on delete cascade,
  house_id       uuid not null references public.houses(id) on delete cascade,
  flock_id       uuid not null references public.flocks(id) on delete cascade,
  entry_date     date not null,
  sample_count   int not null check (sample_count between 1 and 10000),
  input_mode     public.weight_input_mode not null default 'average',
  input_value    numeric(12,3) not null check (input_value > 0),
  input_unit     public.weight_unit not null default 'g',
  -- Normalize edilmiş ortalama (gram). Trigger hesaplar, istemci değeri yok sayılır.
  avg_weight_g   numeric(10,2) not null check (avg_weight_g between 10 and 8000),
  note           text check (note is null or length(note) <= 1000),
  recorded_at    timestamptz,
  created_by     uuid not null references auth.users(id) default auth.uid(),
  created_at     timestamptz not null default now(),
  updated_by     uuid references auth.users(id),
  updated_at     timestamptz not null default now(),
  deleted_at     timestamptz,
  version        int not null default 1
);
create index on public.weight_measurements (flock_id, entry_date) where deleted_at is null;

create table public.temperature_measurements (
  id             uuid primary key default gen_random_uuid(),
  client_id      uuid not null unique,
  org_id         uuid not null references public.organizations(id) on delete cascade,
  farm_id        uuid not null references public.farms(id) on delete cascade,
  house_id       uuid not null references public.houses(id) on delete cascade,
  flock_id       uuid not null references public.flocks(id) on delete cascade,
  entry_date     date not null,
  measured_at    timestamptz not null,
  temperature_c  numeric(5,2) not null check (temperature_c between -30 and 60),
  humidity_pct   numeric(5,2) check (humidity_pct is null or humidity_pct between 0 and 100),
  source         text not null default 'manual' check (source in ('manual','sensor')),
  note           text check (note is null or length(note) <= 1000),
  recorded_at    timestamptz,
  created_by     uuid not null references auth.users(id) default auth.uid(),
  created_at     timestamptz not null default now(),
  updated_by     uuid references auth.users(id),
  updated_at     timestamptz not null default now(),
  deleted_at     timestamptz,
  version        int not null default 1
);
create index on public.temperature_measurements (flock_id, measured_at) where deleted_at is null;

create table public.daily_notes (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid not null unique,
  org_id      uuid not null references public.organizations(id) on delete cascade,
  farm_id     uuid not null references public.farms(id) on delete cascade,
  house_id    uuid not null references public.houses(id) on delete cascade,
  flock_id    uuid not null references public.flocks(id) on delete cascade,
  entry_date  date not null,
  body        text not null check (length(trim(body)) between 1 and 4000),
  photo_path  text,
  recorded_at timestamptz,
  created_by  uuid not null references auth.users(id) default auth.uid(),
  created_at  timestamptz not null default now(),
  updated_by  uuid references auth.users(id),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz,
  version     int not null default 1
);
create index on public.daily_notes (flock_id, entry_date) where deleted_at is null;

create table public.flock_movements (
  id             uuid primary key default gen_random_uuid(),
  client_id      uuid not null unique,
  org_id         uuid not null references public.organizations(id) on delete cascade,
  farm_id        uuid not null references public.farms(id) on delete cascade,
  house_id       uuid not null references public.houses(id) on delete cascade,
  flock_id       uuid not null references public.flocks(id) on delete cascade,
  entry_date     date not null,
  movement_type  public.movement_type not null,
  count          int not null check (count > 0 and count <= 1000000),
  note           text check (note is null or length(note) <= 1000),
  recorded_at    timestamptz,
  created_by     uuid not null references auth.users(id) default auth.uid(),
  created_at     timestamptz not null default now(),
  updated_by     uuid references auth.users(id),
  updated_at     timestamptz not null default now(),
  deleted_at     timestamptz,
  version        int not null default 1
);
create index on public.flock_movements (flock_id, entry_date) where deleted_at is null;

create table public.dispatch_records (
  id                    uuid primary key default gen_random_uuid(),
  client_id             uuid not null unique,
  org_id                uuid not null references public.organizations(id) on delete cascade,
  farm_id               uuid not null references public.farms(id) on delete cascade,
  house_id              uuid not null references public.houses(id) on delete cascade,
  flock_id              uuid not null references public.flocks(id) on delete cascade,
  entry_date            date not null,             -- kesim / sevk tarihi
  bird_count            int not null check (bird_count > 0 and bird_count <= 1000000),
  total_live_weight_kg  numeric(12,2) check (total_live_weight_kg is null or total_live_weight_kg > 0),
  avg_weight_kg         numeric(8,3) generated always as
                          (case when total_live_weight_kg is null then null
                                else round(total_live_weight_kg / bird_count, 3) end) stored,
  destination           text,
  note                  text check (note is null or length(note) <= 1000),
  recorded_at           timestamptz,
  created_by            uuid not null references auth.users(id) default auth.uid(),
  created_at            timestamptz not null default now(),
  updated_by            uuid references auth.users(id),
  updated_at            timestamptz not null default now(),
  deleted_at            timestamptz,
  version               int not null default 1
);
create index on public.dispatch_records (flock_id);

-- ---------------------------------------------------------------------
-- Settings: targets, thresholds, notifications
-- ---------------------------------------------------------------------
-- Yönetici tarafından tanımlanan hedef sıcaklık aralıkları (yaş günü aralığına göre).
-- Uygulama varsayılan değer DAYATMAZ; çiftlik kendi yetiştirme planını girer.
create table public.temperature_targets (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references public.organizations(id) on delete cascade,
  farm_id     uuid not null references public.farms(id) on delete cascade,
  day_from    int not null check (day_from >= 1),
  day_to      int not null,
  min_c       numeric(5,2) not null,
  max_c       numeric(5,2) not null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  check (day_to >= day_from),
  check (max_c > min_c)
);
create index on public.temperature_targets (farm_id, day_from);

-- Hedef ağırlık eğrisi (çiftliğin kendi yetiştirme planı / genetik firması tablosu). Varsayılan yok.
create table public.weight_targets (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references public.organizations(id) on delete cascade,
  farm_id     uuid not null references public.farms(id) on delete cascade,
  age_day     int not null check (age_day between 0 and 80),
  target_g    numeric(8,1) not null check (target_g between 10 and 8000),
  created_at  timestamptz not null default now(),
  unique (farm_id, age_day)
);

create table public.alert_settings (
  farm_id                       uuid primary key references public.farms(id) on delete cascade,
  org_id                        uuid not null references public.organizations(id) on delete cascade,
  daily_mortality_warn_pct      numeric(6,3) not null default 0.30 check (daily_mortality_warn_pct >= 0),
  daily_mortality_critical_pct  numeric(6,3) not null default 0.60 check (daily_mortality_critical_pct >= 0),
  cumulative_warn_pct           numeric(6,3) not null default 3.0,
  cumulative_critical_pct       numeric(6,3) not null default 5.0,
  missing_report_hour           int not null default 20 check (missing_report_hour between 0 and 23),
  slaughter_reminder_days       int not null default 3 check (slaughter_reminder_days between 0 and 30),
  updated_at                    timestamptz not null default now(),
  check (daily_mortality_critical_pct >= daily_mortality_warn_pct),
  check (cumulative_critical_pct >= cumulative_warn_pct)
);

create table public.notification_preferences (
  user_id             uuid not null references auth.users(id) on delete cascade,
  org_id              uuid not null references public.organizations(id) on delete cascade,
  push_enabled        boolean not null default true,
  on_new_entry        boolean not null default false,
  on_mortality        boolean not null default true,
  on_missing_report   boolean not null default true,
  on_temperature      boolean not null default true,
  on_slaughter        boolean not null default true,
  on_withdrawal       boolean not null default true,
  updated_at          timestamptz not null default now(),
  primary key (user_id, org_id)
);

create table public.push_tokens (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  token       text not null unique,
  platform    text check (platform in ('ios','android','web')),
  created_at  timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);
create index on public.push_tokens (user_id);

create table public.notifications (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references public.organizations(id) on delete cascade,
  user_id     uuid not null references auth.users(id) on delete cascade,
  kind        public.notification_kind not null,
  severity    text not null default 'info' check (severity in ('info','warning','critical')),
  title       text not null,
  body        text not null,
  data        jsonb not null default '{}',
  flock_id    uuid references public.flocks(id) on delete cascade,
  house_id    uuid references public.houses(id) on delete cascade,
  dedupe_key  text,
  read_at     timestamptz,
  pushed_at   timestamptz,
  created_at  timestamptz not null default now(),
  unique (user_id, dedupe_key)
);
create index on public.notifications (user_id, created_at desc);
create index on public.notifications (pushed_at) where pushed_at is null;

-- ---------------------------------------------------------------------
-- Audit log (append-only)
-- ---------------------------------------------------------------------
create table public.audit_logs (
  id          bigint generated always as identity primary key,
  org_id      uuid,
  house_id    uuid,
  flock_id    uuid,
  table_name  text not null,
  record_id   uuid,
  action      text not null check (action in ('INSERT','UPDATE','DELETE')),
  actor_id    uuid,
  old_data    jsonb,
  new_data    jsonb,
  changed_fields text[],
  created_at  timestamptz not null default now()
);
create index on public.audit_logs (org_id, created_at desc);
create index on public.audit_logs (record_id);
create index on public.audit_logs (actor_id, created_at desc);

-- updated_at triggers
do $$
declare t text;
begin
  foreach t in array array['organizations','profiles','organization_members','farms','houses','flocks',
    'medication_products','temperature_targets','alert_settings','notification_preferences']
  loop
    execute format('create trigger set_updated_at before update on public.%I
                    for each row execute function public.tg_set_updated_at()', t);
  end loop;
end $$;
