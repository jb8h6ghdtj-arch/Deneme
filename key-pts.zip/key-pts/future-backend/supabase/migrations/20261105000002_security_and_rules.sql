-- =====================================================================
-- KEY PTS — Migration 002: Access helpers, business rules, audit, RLS
-- Tüm erişim kontrolü veritabanında uygulanır; arayüzde buton gizlemek
-- güvenlik önlemi sayılmaz.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Access helper functions (SECURITY DEFINER → RLS döngüsünü önler)
-- ---------------------------------------------------------------------
create or replace function public.org_role(p_org uuid)
returns public.app_role language sql stable security definer set search_path = public as $$
  select role from public.organization_members
  where org_id = p_org and user_id = auth.uid()
$$;

create or replace function public.is_org_member(p_org uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.organization_members
                 where org_id = p_org and user_id = auth.uid())
$$;

create or replace function public.is_org_owner(p_org uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.organization_members
                 where org_id = p_org and user_id = auth.uid() and role = 'owner')
$$;

-- Kümesi görebilir mi? Sahip: organizasyondaki tüm kümeler.
-- Sorumlu ve bakıcı: yalnızca atandığı kümeler.
create or replace function public.can_access_house(p_house uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.houses h
    join public.organization_members m on m.org_id = h.org_id and m.user_id = auth.uid()
    where h.id = p_house
      and (m.role = 'owner'
           or exists (select 1 from public.house_assignments a
                      where a.house_id = h.id and a.user_id = auth.uid()))
  )
$$;

-- Kümeyi yönetebilir mi? Sahip veya o kümeye atanmış sorumlu (manager).
create or replace function public.can_manage_house(p_house uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.houses h
    join public.organization_members m on m.org_id = h.org_id and m.user_id = auth.uid()
    where h.id = p_house
      and (m.role = 'owner'
           or (m.role = 'manager' and exists (select 1 from public.house_assignments a
                      where a.house_id = h.id and a.user_id = auth.uid() and 'manage' = any(a.permissions))))
  )
$$;

-- Yetiştirme günü: tek standart (çiftliğin age_base ayarı)
create or replace function public.flock_age(p_flock uuid, p_date date)
returns int language sql stable security definer set search_path = public as $$
  select (p_date - f.placement_date) + fm.age_base
  from public.flocks f join public.farms fm on fm.id = f.farm_id where f.id = p_flock
$$;

create or replace function public.shares_org_with(p_user uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.organization_members a
    join public.organization_members b on b.org_id = a.org_id
    where a.user_id = auth.uid() and b.user_id = p_user
  )
$$;

-- ---------------------------------------------------------------------
-- Domain functions
-- ---------------------------------------------------------------------
create or replace function public.farm_today(p_farm uuid)
returns date language sql stable security definer set search_path = public as $$
  select (now() at time zone coalesce((select timezone from public.farms where id = p_farm), 'Europe/Istanbul'))::date
$$;

-- Mevcut hayvan sayısı = başlangıç + girişler − ölümler − çıkışlar − sevk
-- p_before: verilirse yalnızca bu tarihten ÖNCEKİ hareketler dikkate alınır
-- (gün başı mevcut sayısı için).
create or replace function public.flock_alive_count(p_flock uuid, p_before date default null)
returns int language sql stable security definer set search_path = public as $$
  select f.initial_count
    + coalesce((select sum(case when m.movement_type in ('addition','transfer_in') then m.count else -m.count end)
                from public.flock_movements m
                where m.flock_id = f.id and m.deleted_at is null
                  and (p_before is null or m.entry_date < p_before)), 0)
    - coalesce((select sum(d.count) from public.mortality_entries d
                where d.flock_id = f.id and d.deleted_at is null
                  and (p_before is null or d.entry_date < p_before)), 0)
    - coalesce((select sum(s.bird_count) from public.dispatch_records s
                where s.flock_id = f.id and s.deleted_at is null
                  and (p_before is null or s.entry_date < p_before)), 0)
  from public.flocks f where f.id = p_flock
$$;

-- Kümülatif ölüm oranının paydası: başlangıç + sonradan yapılan girişler
create or replace function public.flock_placed_total(p_flock uuid)
returns int language sql stable security definer set search_path = public as $$
  select f.initial_count
    + coalesce((select sum(m.count) from public.flock_movements m
                where m.flock_id = f.id and m.deleted_at is null
                  and m.movement_type in ('addition','transfer_in')), 0)
  from public.flocks f where f.id = p_flock
$$;

-- ---------------------------------------------------------------------
-- Entry context trigger (tüm operasyon tabloları)
--  * org/farm/house değerlerini dönemden türetir (istemci değeri yok sayılır)
--  * kapalı dönemlere yazmayı engeller
--  * tarih aralığını doğrular
--  * düzenlemede version artırır, updated_by yazar
-- ---------------------------------------------------------------------
create or replace function public.tg_entry_context()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  f public.flocks%rowtype;
  v_today date;
begin
  select * into f from public.flocks where id = new.flock_id for update;
  if not found then
    raise exception 'FLOCK_NOT_FOUND' using errcode = 'P0002';
  end if;

  if tg_op = 'UPDATE' then
    if new.flock_id <> old.flock_id then
      raise exception 'FLOCK_IMMUTABLE: kayıt başka döneme taşınamaz' using errcode = '22023';
    end if;
    if new.created_by <> old.created_by or new.client_id <> old.client_id then
      raise exception 'IMMUTABLE_FIELD' using errcode = '22023';
    end if;
    new.created_at := old.created_at;
    new.version    := old.version + 1;
    new.updated_by := auth.uid();
    new.updated_at := now();
  end if;

  -- Dispatch kayıtları dönem kapanışı içinde yazılır; diğer kayıtlar yalnız aktif dönemde.
  if f.status <> 'active' and not (tg_table_name = 'dispatch_records'
                                   and current_setting('keypts.closing_flock', true) = f.id::text) then
    raise exception 'FLOCK_CLOSED: tamamlanmış döneme kayıt eklenemez/değiştirilemez' using errcode = '42501';
  end if;

  new.org_id   := f.org_id;
  new.farm_id  := f.farm_id;
  new.house_id := f.house_id;

  v_today := public.farm_today(f.farm_id);
  if new.entry_date < f.placement_date then
    raise exception 'DATE_BEFORE_PLACEMENT: kayıt tarihi civciv giriş tarihinden önce olamaz' using errcode = '22008';
  end if;
  if new.entry_date > v_today then
    raise exception 'DATE_IN_FUTURE: ileri tarihli kayıt girilemez' using errcode = '22008';
  end if;

  return new;
end $$;

-- Ölüm/çıkış/sevk sayısı mevcut hayvan sayısını aşamaz
create or replace function public.tg_check_alive()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_alive int;
  v_new int;
  v_old int := 0;
  v_is_exit boolean := true;
begin
  if tg_table_name = 'mortality_entries' then
    v_new := new.count;
    if tg_op = 'UPDATE' and old.deleted_at is null then v_old := old.count; end if;
  elsif tg_table_name = 'dispatch_records' then
    v_new := new.bird_count;
    if tg_op = 'UPDATE' and old.deleted_at is null then v_old := old.bird_count; end if;
  else -- flock_movements
    v_is_exit := new.movement_type not in ('addition','transfer_in');
    v_new := new.count;
    if tg_op = 'UPDATE' and old.deleted_at is null and old.movement_type not in ('addition','transfer_in') then
      v_old := old.count;
    end if;
  end if;

  if new.deleted_at is not null or not v_is_exit then
    return new;
  end if;

  v_alive := public.flock_alive_count(new.flock_id) + v_old;
  if v_new > v_alive then
    raise exception 'EXCEEDS_ALIVE: girilen sayı (%) mevcut hayvan sayısını (%) aşıyor', v_new, v_alive
      using errcode = '23514';
  end if;
  return new;
end $$;

-- Tartım: birim dönüşümü sunucuda yapılır
create or replace function public.tg_weight_normalize()
returns trigger language plpgsql as $$
declare v_grams numeric;
begin
  v_grams := case new.input_unit when 'kg' then new.input_value * 1000 else new.input_value end;
  if new.input_mode = 'total' then
    v_grams := v_grams / new.sample_count;
  end if;
  new.avg_weight_g := round(v_grams, 2);
  return new;
end $$;

-- İlaç: ürün adını ve bekleme süresini katalogdan anlık kopyalar (istemci boş bırakırsa)
create or replace function public.tg_medication_snapshot()
returns trigger language plpgsql security definer set search_path = public as $$
declare p public.medication_products%rowtype;
begin
  select * into p from public.medication_products where id = new.product_id;
  if not found or p.org_id <> new.org_id then
    raise exception 'PRODUCT_NOT_IN_ORG' using errcode = '42501';
  end if;
  if tg_op = 'INSERT' then
    new.product_name := p.name;
    if new.withdrawal_days is null or new.withdrawal_days = 0 then
      new.withdrawal_days := p.withdrawal_days;
    end if;
  end if;
  return new;
end $$;

-- Sıcaklık: entry_date ölçüm zamanından (çiftlik saat dilimi) türetilir
create or replace function public.tg_temperature_date()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.entry_date := (new.measured_at at time zone coalesce(
      (select f.timezone from public.flocks fl join public.farms f on f.id = fl.farm_id where fl.id = new.flock_id),
      'Europe/Istanbul'))::date;
  return new;
end $$;

-- Dönem: cycle_no otomatik, org/farm kümesten türetilir
create or replace function public.tg_flock_defaults()
returns trigger language plpgsql security definer set search_path = public as $$
declare h public.houses%rowtype;
begin
  select * into h from public.houses where id = new.house_id;
  if not found then raise exception 'HOUSE_NOT_FOUND'; end if;
  if tg_op = 'INSERT' then
    new.org_id  := h.org_id;
    new.farm_id := h.farm_id;
    if h.archived_at is not null then
      raise exception 'HOUSE_ARCHIVED' using errcode = '22023';
    end if;
    select coalesce(max(cycle_no), 0) + 1 into new.cycle_no from public.flocks where house_id = new.house_id;
    if new.name is null or trim(new.name) = '' then
      new.name := h.name || ' — ' || new.cycle_no || '. Dönem';
    end if;
    if new.initial_count > h.capacity * 1.2 then
      raise exception 'INITIAL_EXCEEDS_CAPACITY: başlangıç sayısı kapasitenin %%120''sini aşamaz' using errcode = '23514';
    end if;
    new.status := 'active';
    new.completed_at := null;
  else
    if new.house_id <> old.house_id or new.org_id <> old.org_id then
      raise exception 'FLOCK_HOUSE_IMMUTABLE' using errcode = '22023';
    end if;
    -- Giriş tarihi, mevcut kayıtların tarihinden sonraya alınamaz
    if new.placement_date > old.placement_date and exists (
         select 1 from public.mortality_entries where flock_id = old.id and entry_date < new.placement_date and deleted_at is null
         union all select 1 from public.coal_entries where flock_id = old.id and entry_date < new.placement_date and deleted_at is null
         union all select 1 from public.weight_measurements where flock_id = old.id and entry_date < new.placement_date and deleted_at is null
         union all select 1 from public.medication_applications where flock_id = old.id and entry_date < new.placement_date and deleted_at is null
         union all select 1 from public.temperature_measurements where flock_id = old.id and entry_date < new.placement_date and deleted_at is null) then
      raise exception 'PLACEMENT_AFTER_ENTRIES: giriş tarihinden önce kayıtlar var' using errcode = '22008';
    end if;
    -- Tamamlanmış dönem yalnızca not alanında düzenlenebilir, yeniden açılamaz
    if old.status <> 'active' and current_setting('keypts.closing_flock', true) is distinct from old.id::text then
      if new.status <> old.status or new.initial_count <> old.initial_count
         or new.placement_date <> old.placement_date then
        raise exception 'FLOCK_CLOSED' using errcode = '42501';
      end if;
    end if;
    new.version := old.version + 1;
  end if;
  return new;
end $$;

create or replace function public.tg_house_defaults()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  select org_id into new.org_id from public.farms where id = new.farm_id;
  if new.heating_type <> 'coal' and tg_op = 'INSERT' then
    new.coal_tracking := false;
  end if;
  return new;
end $$;

create or replace function public.tg_assignment_defaults()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  select org_id into new.org_id from public.houses where id = new.house_id;
  if not exists (select 1 from public.organization_members where org_id = new.org_id and user_id = new.user_id) then
    raise exception 'USER_NOT_IN_ORG' using errcode = '23503';
  end if;
  new.created_by := auth.uid();
  return new;
end $$;

-- Son sahip silinemez / rolü düşürülemez
create or replace function public.tg_protect_last_owner()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if old.role = 'owner' and (tg_op = 'DELETE' or new.role <> 'owner') then
    if (select count(*) from public.organization_members where org_id = old.org_id and role = 'owner') <= 1 then
      raise exception 'LAST_OWNER: organizasyonun son sahibi kaldırılamaz' using errcode = '42501';
    end if;
  end if;
  return coalesce(new, old);
end $$;

-- ---------------------------------------------------------------------
-- Audit trigger: eski/yeni değer, işlemi yapan, zaman
-- ---------------------------------------------------------------------
create or replace function public.tg_audit()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_old jsonb := case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) end;
  v_new jsonb := case when tg_op in ('INSERT','UPDATE') then to_jsonb(new) end;
  v_row jsonb := coalesce(v_new, v_old);
  v_changed text[];
begin
  if tg_op = 'UPDATE' then
    select array_agg(k) into v_changed
    from jsonb_object_keys(v_new) k
    where k not in ('updated_at','version','updated_by')
      and (v_new -> k) is distinct from (v_old -> k);
    if v_changed is null then return new; end if;
  end if;

  insert into public.audit_logs (org_id, house_id, flock_id, table_name, record_id, action,
                                 actor_id, old_data, new_data, changed_fields)
  values (
    nullif(v_row ->> 'org_id','')::uuid,
    case when tg_table_name = 'houses' then (v_row ->> 'id')::uuid else nullif(v_row ->> 'house_id','')::uuid end,
    case when tg_table_name = 'flocks' then (v_row ->> 'id')::uuid else nullif(v_row ->> 'flock_id','')::uuid end,
    tg_table_name,
    nullif(v_row ->> 'id','')::uuid,
    tg_op, auth.uid(), v_old, v_new, v_changed
  );
  return coalesce(new, old);
end $$;

-- ---------------------------------------------------------------------
-- Attach triggers
-- ---------------------------------------------------------------------
create trigger flock_defaults before insert or update on public.flocks
  for each row execute function public.tg_flock_defaults();
create trigger house_defaults before insert or update of farm_id on public.houses
  for each row execute function public.tg_house_defaults();
create trigger assignment_defaults before insert on public.house_assignments
  for each row execute function public.tg_assignment_defaults();
create trigger protect_last_owner before update or delete on public.organization_members
  for each row execute function public.tg_protect_last_owner();

do $$
declare t text;
begin
  foreach t in array array['mortality_entries','coal_entries','medication_applications','weight_measurements',
                           'temperature_measurements','daily_notes','flock_movements','dispatch_records']
  loop
    execute format('create trigger a_entry_context before insert or update on public.%I
                    for each row execute function public.tg_entry_context()', t);
  end loop;

  foreach t in array array['mortality_entries','flock_movements','dispatch_records']
  loop
    execute format('create trigger b_check_alive before insert or update on public.%I
                    for each row execute function public.tg_check_alive()', t);
  end loop;

  foreach t in array array['organizations','organization_members','farms','houses','house_assignments','flocks',
                           'mortality_entries','coal_entries','medication_products','medication_applications',
                           'weight_measurements','temperature_measurements','daily_notes','flock_movements',
                           'dispatch_records','temperature_targets','alert_settings']
  loop
    execute format('create trigger z_audit after insert or update or delete on public.%I
                    for each row execute function public.tg_audit()', t);
  end loop;
end $$;

-- temperature date must be set before context check (trigger names sort alphabetically)
create trigger _temperature_date before insert or update of measured_at on public.temperature_measurements
  for each row execute function public.tg_temperature_date();
create trigger b_weight_normalize before insert or update on public.weight_measurements
  for each row execute function public.tg_weight_normalize();
create trigger b_medication_snapshot before insert or update of product_id on public.medication_applications
  for each row execute function public.tg_medication_snapshot();

-- Yeni kullanıcı → profil
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, phone)
  values (new.id, new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'phone')
  on conflict (id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- Row Level Security
-- ---------------------------------------------------------------------
alter table public.organizations            enable row level security;
alter table public.profiles                 enable row level security;
alter table public.organization_members     enable row level security;
alter table public.farms                    enable row level security;
alter table public.houses                   enable row level security;
alter table public.house_assignments        enable row level security;
alter table public.invitations              enable row level security;
alter table public.flocks                   enable row level security;
alter table public.mortality_entries        enable row level security;
alter table public.coal_entries             enable row level security;
alter table public.medication_products      enable row level security;
alter table public.medication_applications  enable row level security;
alter table public.weight_measurements      enable row level security;
alter table public.temperature_measurements enable row level security;
alter table public.daily_notes              enable row level security;
alter table public.flock_movements          enable row level security;
alter table public.dispatch_records         enable row level security;
alter table public.temperature_targets      enable row level security;
alter table public.alert_settings           enable row level security;
alter table public.weight_targets           enable row level security;
alter table public.notification_preferences enable row level security;
alter table public.push_tokens              enable row level security;
alter table public.notifications            enable row level security;
alter table public.audit_logs               enable row level security;

-- organizations
create policy org_select on public.organizations for select to authenticated
  using (public.is_org_member(id));
create policy org_update on public.organizations for update to authenticated
  using (public.is_org_owner(id)) with check (public.is_org_owner(id));

-- profiles
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.shares_org_with(id));
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- organization_members
create policy members_select on public.organization_members for select to authenticated
  using (public.is_org_member(org_id));
create policy members_update on public.organization_members for update to authenticated
  using (public.is_org_owner(org_id)) with check (public.is_org_owner(org_id));
create policy members_delete on public.organization_members for delete to authenticated
  using (public.is_org_owner(org_id) or user_id = auth.uid());

-- farms
create policy farms_select on public.farms for select to authenticated
  using (public.is_org_member(org_id));
create policy farms_insert on public.farms for insert to authenticated
  with check (public.is_org_owner(org_id));
create policy farms_update on public.farms for update to authenticated
  using (public.is_org_owner(org_id)) with check (public.is_org_owner(org_id));

-- houses
create policy houses_select on public.houses for select to authenticated
  using (public.can_access_house(id));
create policy houses_insert on public.houses for insert to authenticated
  with check (public.is_org_owner((select org_id from public.farms where id = farm_id)));
create policy houses_update on public.houses for update to authenticated
  using (public.is_org_owner(org_id)) with check (public.is_org_owner(org_id));

-- house_assignments: sahip tümünü; sorumlu yalnızca yönettiği kümelerde bakıcı atayabilir
create policy assign_select on public.house_assignments for select to authenticated
  using (user_id = auth.uid() or public.is_org_owner(org_id) or public.can_manage_house(house_id));
create policy assign_insert on public.house_assignments for insert to authenticated
  with check (
    public.is_org_owner((select org_id from public.houses where id = house_id))
    or (public.can_manage_house(house_id)
        and exists (select 1 from public.organization_members m
                    join public.houses h on h.org_id = m.org_id
                    where h.id = house_id and m.user_id = house_assignments.user_id and m.role = 'worker'))
  );
create policy assign_update on public.house_assignments for update to authenticated
  using (public.is_org_owner(org_id)) with check (public.is_org_owner(org_id));
create policy assign_delete on public.house_assignments for delete to authenticated
  using (public.is_org_owner(org_id)
         or (public.can_manage_house(house_id)
             and exists (select 1 from public.organization_members m
                         where m.org_id = house_assignments.org_id and m.user_id = house_assignments.user_id
                           and m.role = 'worker')));

-- invitations (oluşturma RPC ile)
create policy inv_select on public.invitations for select to authenticated
  using (public.is_org_owner(org_id) or invited_by = auth.uid());
create policy inv_update on public.invitations for update to authenticated
  using (public.is_org_owner(org_id) or invited_by = auth.uid())
  with check (public.is_org_owner(org_id) or invited_by = auth.uid());

-- flocks
create policy flocks_select on public.flocks for select to authenticated
  using (public.can_access_house(house_id));
create policy flocks_insert on public.flocks for insert to authenticated
  with check (public.can_manage_house(house_id));
create policy flocks_update on public.flocks for update to authenticated
  using (public.can_manage_house(house_id)) with check (public.can_manage_house(house_id));

-- operational entries: generic policies
do $$
declare t text;
begin
  foreach t in array array['mortality_entries','coal_entries','medication_applications','weight_measurements',
                           'temperature_measurements','daily_notes','flock_movements']
  loop
    execute format($f$
      create policy %1$s_select on public.%1$I for select to authenticated
        using (public.can_access_house(house_id));
      create policy %1$s_insert on public.%1$I for insert to authenticated
        with check (created_by = auth.uid()
                    and public.can_access_house((select house_id from public.flocks where id = flock_id)));
      create policy %1$s_update on public.%1$I for update to authenticated
        using ((created_by = auth.uid() and public.can_access_house(house_id)) or public.can_manage_house(house_id))
        with check ((created_by = auth.uid() and public.can_access_house(house_id)) or public.can_manage_house(house_id));
    $f$, t);
  end loop;
end $$;
-- Sürü hareketleri (ayıklama/transfer/ek giriş) yalnızca yönetici seviyesi
drop policy flock_movements_insert on public.flock_movements;
create policy flock_movements_insert on public.flock_movements for insert to authenticated
  with check (created_by = auth.uid()
              and public.can_manage_house((select house_id from public.flocks where id = flock_id)));

-- dispatch: yalnız yöneticiler (complete_flock RPC üzerinden)
create policy dispatch_select on public.dispatch_records for select to authenticated
  using (public.can_access_house(house_id));

-- medication catalog
create policy medprod_select on public.medication_products for select to authenticated
  using (public.is_org_member(org_id));
create policy medprod_insert on public.medication_products for insert to authenticated
  with check (public.org_role(org_id) in ('owner','manager'));
create policy medprod_update on public.medication_products for update to authenticated
  using (public.org_role(org_id) in ('owner','manager'))
  with check (public.org_role(org_id) in ('owner','manager'));

-- settings
create policy tt_select on public.temperature_targets for select to authenticated
  using (public.is_org_member(org_id));
create policy tt_write on public.temperature_targets for all to authenticated
  using (public.is_org_owner(org_id)) with check (public.is_org_owner(org_id));
create policy wt_select on public.weight_targets for select to authenticated
  using (public.is_org_member(org_id));
create policy wt_write on public.weight_targets for all to authenticated
  using (public.is_org_owner(org_id)) with check (public.is_org_owner(org_id));
create policy as_select on public.alert_settings for select to authenticated
  using (public.is_org_member(org_id));
create policy as_update on public.alert_settings for update to authenticated
  using (public.is_org_owner(org_id)) with check (public.is_org_owner(org_id));

create policy np_all on public.notification_preferences for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid() and public.is_org_member(org_id));
create policy pt_all on public.push_tokens for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy notif_select on public.notifications for select to authenticated
  using (user_id = auth.uid());
create policy notif_update on public.notifications for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- audit: sahip tümünü, sorumlu yönettiği kümeleri görür
create policy audit_select on public.audit_logs for select to authenticated
  using (public.is_org_owner(org_id) or (house_id is not null and public.can_manage_house(house_id)));

-- ---------------------------------------------------------------------
-- Grants: anon hiçbir tabloya erişemez. Silme yok (soft delete).
-- ---------------------------------------------------------------------
revoke all on all tables in schema public from anon;
revoke all on all functions in schema public from anon;
grant usage on schema public to authenticated;
grant select on all tables in schema public to authenticated;
grant insert, update on
  public.organizations, public.profiles, public.farms, public.houses, public.flocks,
  public.mortality_entries, public.coal_entries, public.medication_products, public.medication_applications,
  public.weight_measurements, public.temperature_measurements, public.daily_notes, public.flock_movements,
  public.temperature_targets, public.weight_targets, public.alert_settings, public.notification_preferences, public.push_tokens,
  public.notifications, public.invitations, public.organization_members
  to authenticated;
grant insert, delete on public.house_assignments to authenticated;
grant update (permissions) on public.house_assignments to authenticated;
grant delete on public.weight_targets, public.temperature_targets, public.push_tokens, public.organization_members to authenticated;
-- Hassas sütunların istemciden yazılmasını engelle
revoke insert, update on public.organizations from authenticated;
grant update (name) on public.organizations to authenticated;
revoke update on public.notifications from authenticated;
grant update (read_at) on public.notifications to authenticated;
revoke insert on public.notifications, public.invitations, public.organization_members from authenticated;
revoke update on public.organization_members from authenticated;
grant update (role) on public.organization_members to authenticated;
