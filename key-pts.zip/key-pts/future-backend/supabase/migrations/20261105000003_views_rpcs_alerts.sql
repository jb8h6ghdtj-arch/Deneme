-- =====================================================================
-- KEY PTS — Migration 003: Read models (views), RPCs, server-side alerts
-- =====================================================================

-- ---------------------------------------------------------------------
-- Daily read model per flock
--   Her gün için bir satır üretir (giriş tarihi → bugün/kapanış).
--   deaths NULL  = o gün ölüm kaydı GİRİLMEMİŞ
--   deaths 0     = o gün "0 ölüm" olarak kaydedilmiş
--   daily_mortality_pct = günlük ölüm / gün başı mevcut × 100
--   cumulative_mortality_pct = kümülatif ölüm / (başlangıç + ek girişler) × 100
-- ---------------------------------------------------------------------
create or replace view public.v_flock_daily
with (security_invoker = true) as
with bounds as (
  select f.id as flock_id, f.org_id, f.farm_id, f.house_id, f.placement_date, f.initial_count,
         (select age_base from public.farms where id = f.farm_id) as age_base,
         case when f.status = 'active' then public.farm_today(f.farm_id)
              else coalesce((select max(entry_date) from public.dispatch_records d
                             where d.flock_id = f.id and d.deleted_at is null),
                            (f.completed_at at time zone 'Europe/Istanbul')::date)
         end as end_date
  from public.flocks f
),
days as (
  select b.*, gs::date as day, (gs::date - b.placement_date + b.age_base) as age_day
  from bounds b, generate_series(b.placement_date, greatest(b.end_date, b.placement_date), interval '1 day') gs
),
mort as (
  select flock_id, entry_date, sum(count)::int as deaths, count(*)::int as entries
  from public.mortality_entries where deleted_at is null group by 1,2
),
mov as (
  select flock_id, entry_date,
         sum(case when movement_type in ('addition','transfer_in') then count else 0 end)::int as birds_in,
         sum(case when movement_type in ('addition','transfer_in') then 0 else count end)::int as birds_out
  from public.flock_movements where deleted_at is null group by 1,2
),
disp as (
  select flock_id, entry_date, sum(bird_count)::int as dispatched
  from public.dispatch_records where deleted_at is null group by 1,2
),
coal as (
  select flock_id, entry_date, sum(bag_count) as coal_bags, sum(total_kg) as coal_kg, count(*)::int as coal_entries
  from public.coal_entries where deleted_at is null group by 1,2
),
med as (
  select flock_id, entry_date, count(*)::int as med_count
  from public.medication_applications where deleted_at is null group by 1,2
),
wt as (
  select distinct on (flock_id, entry_date) flock_id, entry_date, avg_weight_g, sample_count
  from public.weight_measurements where deleted_at is null
  order by flock_id, entry_date, created_at desc
),
tmp as (
  select flock_id, entry_date, min(temperature_c) as temp_min, max(temperature_c) as temp_max,
         round(avg(temperature_c), 1) as temp_avg, count(*)::int as temp_count
  from public.temperature_measurements where deleted_at is null group by 1,2
),
notes as (
  select flock_id, entry_date, count(*)::int as note_count
  from public.daily_notes where deleted_at is null group by 1,2
),
joined as (
  select d.flock_id, d.org_id, d.farm_id, d.house_id, d.day, d.age_day, d.initial_count,
         mort.deaths, coalesce(mort.entries, 0) as mortality_entries,
         coalesce(mov.birds_in, 0) as birds_in, coalesce(mov.birds_out, 0) as birds_out,
         coalesce(disp.dispatched, 0) as dispatched,
         coal.coal_bags, coal.coal_kg, coalesce(coal.coal_entries, 0) as coal_entries,
         coalesce(med.med_count, 0) as med_count,
         wt.avg_weight_g, wt.sample_count as weight_sample_count,
         tmp.temp_min, tmp.temp_max, tmp.temp_avg, coalesce(tmp.temp_count, 0) as temp_count,
         coalesce(notes.note_count, 0) as note_count
  from days d
  left join mort  on mort.flock_id  = d.flock_id and mort.entry_date  = d.day
  left join mov   on mov.flock_id   = d.flock_id and mov.entry_date   = d.day
  left join disp  on disp.flock_id  = d.flock_id and disp.entry_date  = d.day
  left join coal  on coal.flock_id  = d.flock_id and coal.entry_date  = d.day
  left join med   on med.flock_id   = d.flock_id and med.entry_date   = d.day
  left join wt    on wt.flock_id    = d.flock_id and wt.entry_date    = d.day
  left join tmp   on tmp.flock_id   = d.flock_id and tmp.entry_date   = d.day
  left join notes on notes.flock_id = d.flock_id and notes.entry_date = d.day
),
running as (
  select j.*,
    j.initial_count
      + coalesce(sum(j.birds_in - j.birds_out - coalesce(j.deaths,0) - j.dispatched)
          over (partition by j.flock_id order by j.day rows between unbounded preceding and 1 preceding), 0)
      as start_of_day_alive,
    sum(coalesce(j.deaths,0)) over (partition by j.flock_id order by j.day) as cumulative_deaths,
    j.initial_count + sum(j.birds_in) over (partition by j.flock_id order by j.day) as placed_to_date
  from joined j
)
select r.flock_id, r.org_id, r.farm_id, r.house_id, r.day, r.age_day,
       r.deaths, (r.deaths is not null) as mortality_recorded, r.mortality_entries,
       r.birds_in, r.birds_out, r.dispatched,
       r.start_of_day_alive::int,
       (r.start_of_day_alive + r.birds_in - r.birds_out - coalesce(r.deaths,0) - r.dispatched)::int as end_of_day_alive,
       case when r.deaths is null or r.start_of_day_alive <= 0 then null
            else round(r.deaths::numeric * 100 / r.start_of_day_alive, 3) end as daily_mortality_pct,
       r.cumulative_deaths::int,
       round(r.cumulative_deaths::numeric * 100 / nullif(r.placed_to_date, 0), 3) as cumulative_mortality_pct,
       r.coal_bags, r.coal_kg, r.coal_entries, r.med_count,
       r.avg_weight_g, r.weight_sample_count,
       r.temp_min, r.temp_max, r.temp_avg, r.temp_count, r.note_count
from running r;

-- ---------------------------------------------------------------------
-- Flock overview (kartlar ve detay başlığı)
-- ---------------------------------------------------------------------
create or replace view public.v_flock_overview
with (security_invoker = true) as
select f.id as flock_id, f.org_id, f.farm_id, f.house_id, h.name as house_name, h.capacity, h.heating_type,
       h.coal_tracking, h.sort_order,
       f.name, f.cycle_no, f.status, f.placement_date, f.initial_count, f.breed,
       f.expected_slaughter_date, f.responsible_user_id, f.completed_at, f.version,
       fm.chick_phase_days, fm.age_base,
       t.today,
       (least(t.today, coalesce((f.completed_at at time zone fm.timezone)::date, t.today)) - f.placement_date + fm.age_base) as age_day,
       case when f.expected_slaughter_date is null or f.status <> 'active' then null else f.expected_slaughter_date - t.today end as days_to_slaughter,
       public.flock_placed_total(f.id) as placed_total,
       public.flock_alive_count(f.id) as alive_count,
       coalesce(md.total_deaths, 0) as total_deaths,
       round(coalesce(md.total_deaths, 0)::numeric * 100 / nullif(public.flock_placed_total(f.id), 0), 3)
         as cumulative_mortality_pct,
       mt.deaths as today_deaths,                       -- NULL: bugün henüz kayıt yok
       (mt.deaths is not null) as today_mortality_recorded,
       ct.bags as today_coal_bags, ct.kg as today_coal_kg,
       coalesce(medt.cnt, 0) as today_med_count,
       lw.avg_weight_g as last_weight_g, lw.entry_date as last_weight_date, lw.sample_count as last_weight_sample, lw.created_at as last_weight_at,
       lt.temperature_c as last_temperature_c, lt.measured_at as last_temperature_at,
       wd.max_withdrawal_end as withdrawal_end_date,
       (f.expected_slaughter_date is not null and wd.max_withdrawal_end is not null
        and wd.max_withdrawal_end >= f.expected_slaughter_date) as withdrawal_conflict
from public.flocks f
join public.houses h on h.id = f.house_id
join public.farms fm on fm.id = f.farm_id
cross join lateral (select public.farm_today(f.farm_id) as today) t
left join lateral (select sum(count)::int as total_deaths from public.mortality_entries
                   where flock_id = f.id and deleted_at is null) md on true
left join lateral (select sum(count)::int as deaths from public.mortality_entries
                   where flock_id = f.id and deleted_at is null and entry_date = t.today) mt on true
left join lateral (select sum(bag_count) as bags, sum(total_kg) as kg from public.coal_entries
                   where flock_id = f.id and deleted_at is null and entry_date = t.today) ct on true
left join lateral (select count(*)::int as cnt from public.medication_applications
                   where flock_id = f.id and deleted_at is null and entry_date = t.today) medt on true
left join lateral (select avg_weight_g, entry_date, sample_count, created_at from public.weight_measurements
                   where flock_id = f.id and deleted_at is null order by entry_date desc, created_at desc limit 1) lw on true
left join lateral (select temperature_c, measured_at from public.temperature_measurements
                   where flock_id = f.id and deleted_at is null order by measured_at desc limit 1) lt on true
left join lateral (select max(withdrawal_end_date) as max_withdrawal_end from public.medication_applications
                   where flock_id = f.id and deleted_at is null and withdrawal_days > 0) wd on true;

-- Birleşik işlem geçmişi (çalışan işlem geçmişi raporu)
create or replace view public.v_activity
with (security_invoker = true) as
select 'mortality'::text as kind, id, flock_id, house_id, org_id, entry_date, created_at, created_by,
       count::numeric as value, null::text as label, note, version, updated_at from public.mortality_entries where deleted_at is null
union all
select 'coal', id, flock_id, house_id, org_id, entry_date, created_at, created_by, bag_count, coal_type, note, version, updated_at
  from public.coal_entries where deleted_at is null
union all
select 'medication', id, flock_id, house_id, org_id, entry_date, created_at, created_by, amount, product_name || ' (' || unit || ')', note, version, updated_at
  from public.medication_applications where deleted_at is null
union all
select 'weight', id, flock_id, house_id, org_id, entry_date, created_at, created_by, avg_weight_g, sample_count || ' örnek', note, version, updated_at
  from public.weight_measurements where deleted_at is null
union all
select 'temperature', id, flock_id, house_id, org_id, entry_date, created_at, created_by, temperature_c,
       case when humidity_pct is null then null else humidity_pct || '% nem' end, note, version, updated_at
  from public.temperature_measurements where deleted_at is null
union all
select 'note', id, flock_id, house_id, org_id, entry_date, created_at, created_by, null, null, body, version, updated_at
  from public.daily_notes where deleted_at is null
union all
select 'movement', id, flock_id, house_id, org_id, entry_date, created_at, created_by, count, movement_type::text, note, version, updated_at
  from public.flock_movements where deleted_at is null;

grant select on public.v_flock_daily, public.v_flock_overview, public.v_activity to authenticated;

-- ---------------------------------------------------------------------
-- RPC: İlk kurulum sihirbazı
-- p_farm  : {"name","location_text","contact_name","contact_phone","contact_email","default_heating","default_coal_bag_kg"}
-- p_houses: [{"name","capacity","heating_type"}]
-- ---------------------------------------------------------------------
create or replace function public.create_organization_with_farm(p_org_name text, p_farm jsonb, p_houses jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_org uuid;
  v_farm uuid;
  h jsonb;
  i int := 0;
begin
  if v_uid is null then raise exception 'NOT_AUTHENTICATED' using errcode = '28000'; end if;
  if jsonb_typeof(p_houses) <> 'array' or jsonb_array_length(p_houses) = 0 then
    raise exception 'HOUSES_REQUIRED' using errcode = '22023';
  end if;
  if jsonb_array_length(p_houses) > 100 then
    raise exception 'TOO_MANY_HOUSES' using errcode = '22023';
  end if;

  insert into organizations (name, created_by) values (coalesce(nullif(trim(p_org_name), ''), p_farm ->> 'name'), v_uid)
    returning id into v_org;
  insert into organization_members (org_id, user_id, role) values (v_org, v_uid, 'owner');

  insert into farms (org_id, name, location_text, contact_name, contact_phone, contact_email,
                     default_heating, default_coal_bag_kg, age_base)
  values (v_org, p_farm ->> 'name', p_farm ->> 'location_text', p_farm ->> 'contact_name',
          p_farm ->> 'contact_phone', p_farm ->> 'contact_email',
          coalesce((p_farm ->> 'default_heating')::heating_type, 'coal'),
          coalesce((p_farm ->> 'default_coal_bag_kg')::numeric, 25),
          coalesce((p_farm ->> 'age_base')::smallint, 0))
  returning id into v_farm;

  for h in select * from jsonb_array_elements(p_houses) loop
    i := i + 1;
    insert into houses (farm_id, org_id, name, capacity, heating_type, sort_order)
    values (v_farm, v_org, h ->> 'name', (h ->> 'capacity')::int,
            coalesce((h ->> 'heating_type')::heating_type, (p_farm ->> 'default_heating')::heating_type, 'coal'), i);
  end loop;

  insert into alert_settings (farm_id, org_id) values (v_farm, v_org);
  insert into notification_preferences (user_id, org_id) values (v_uid, v_org);

  return jsonb_build_object('org_id', v_org, 'farm_id', v_farm);
end $$;

-- ---------------------------------------------------------------------
-- RPC: Davet oluştur / kabul et
-- ---------------------------------------------------------------------
create or replace function public.create_invitation(p_org uuid, p_role app_role, p_house_ids uuid[], p_email text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_role app_role := public.org_role(p_org);
  v_code text;
  v_house uuid;
  v_id uuid;
begin
  if v_role is null then raise exception 'NOT_A_MEMBER' using errcode = '42501'; end if;
  if p_role = 'owner' then raise exception 'CANNOT_INVITE_OWNER' using errcode = '42501'; end if;
  if v_role = 'worker' then raise exception 'FORBIDDEN' using errcode = '42501'; end if;
  if v_role = 'manager' and p_role <> 'worker' then raise exception 'MANAGER_CAN_INVITE_WORKERS_ONLY' using errcode = '42501'; end if;

  foreach v_house in array coalesce(p_house_ids, '{}') loop
    if not exists (select 1 from houses where id = v_house and org_id = p_org) then
      raise exception 'HOUSE_NOT_IN_ORG' using errcode = '42501';
    end if;
    if v_role = 'manager' and not public.can_manage_house(v_house) then
      raise exception 'HOUSE_NOT_MANAGED' using errcode = '42501';
    end if;
  end loop;

  -- 8 karakterli, karışması zor harflerden oluşan kod
  v_code := (select string_agg(substr('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', (get_byte(b, i) % 32) + 1, 1), '')
             from (select gen_random_bytes(8) b) x, generate_series(0, 7) i);

  insert into invitations (org_id, role, house_ids, email, code, invited_by)
  values (p_org, p_role, coalesce(p_house_ids, '{}'), lower(nullif(trim(p_email), '')), v_code, auth.uid())
  returning id into v_id;
  return jsonb_build_object('id', v_id, 'code', v_code);
end $$;

create or replace function public.accept_invitation(p_code text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  inv invitations%rowtype;
  v_uid uuid := auth.uid();
  v_house uuid;
begin
  if v_uid is null then raise exception 'NOT_AUTHENTICATED' using errcode = '28000'; end if;
  select * into inv from invitations where code = upper(trim(p_code)) for update;
  if not found or inv.revoked_at is not null then raise exception 'INVITE_INVALID' using errcode = 'P0002'; end if;
  if inv.accepted_at is not null then raise exception 'INVITE_USED' using errcode = '22023'; end if;
  if inv.expires_at < now() then raise exception 'INVITE_EXPIRED' using errcode = '22023'; end if;
  if inv.email is not null and inv.email <> lower((select email from auth.users where id = v_uid)) then
    raise exception 'INVITE_EMAIL_MISMATCH' using errcode = '42501';
  end if;
  if exists (select 1 from organization_members where org_id = inv.org_id and user_id = v_uid) then
    raise exception 'ALREADY_MEMBER' using errcode = '23505';
  end if;

  insert into organization_members (org_id, user_id, role) values (inv.org_id, v_uid, inv.role);
  foreach v_house in array inv.house_ids loop
    insert into house_assignments (org_id, house_id, user_id, created_by, permissions)
    values (inv.org_id, v_house, v_uid, inv.invited_by,
            case when inv.role = 'manager' then array['record','manage'] else array['record'] end) on conflict do nothing;
  end loop;
  insert into notification_preferences (user_id, org_id) values (v_uid, inv.org_id) on conflict do nothing;
  update invitations set accepted_by = v_uid, accepted_at = now() where id = inv.id;
  return jsonb_build_object('org_id', inv.org_id, 'role', inv.role);
end $$;

-- ---------------------------------------------------------------------
-- RPC: Dönem kapanış özeti ve kapatma
-- ---------------------------------------------------------------------
create or replace function public.flock_closing_summary(p_flock uuid)
returns jsonb language plpgsql stable security invoker set search_path = public as $$
declare
  f flocks%rowtype;
  r jsonb;
begin
  select * into f from flocks where id = p_flock;   -- RLS uygulanır
  if not found then raise exception 'FLOCK_NOT_FOUND' using errcode = 'P0002'; end if;

  select jsonb_build_object(
    'flock_id', f.id,
    'initial_count', f.initial_count,
    'placed_total', flock_placed_total(f.id),
    'total_deaths', coalesce((select sum(count) from mortality_entries where flock_id = f.id and deleted_at is null), 0),
    'birds_in', coalesce((select sum(count) from flock_movements where flock_id = f.id and deleted_at is null
                          and movement_type in ('addition','transfer_in')), 0),
    'birds_out', coalesce((select sum(count) from flock_movements where flock_id = f.id and deleted_at is null
                           and movement_type not in ('addition','transfer_in')), 0),
    'dispatched', coalesce((select sum(bird_count) from dispatch_records where flock_id = f.id and deleted_at is null), 0),
    'dispatched_weight_kg', (select sum(total_live_weight_kg) from dispatch_records where flock_id = f.id and deleted_at is null),
    'alive_unaccounted', flock_alive_count(f.id),
    'coal_bags', coalesce((select sum(bag_count) from coal_entries where flock_id = f.id and deleted_at is null), 0),
    'coal_kg', coalesce((select sum(total_kg) from coal_entries where flock_id = f.id and deleted_at is null), 0),
    'medications', coalesce((select jsonb_agg(jsonb_build_object('product', product_name, 'applications', n,
                               'total', total, 'unit', unit) order by product_name)
                             from (select product_name, unit, count(*) n, sum(amount) total from medication_applications
                                   where flock_id = f.id and deleted_at is null group by product_name, unit) m), '[]'),
    'mortality_days_missing', (select count(*) from v_flock_daily where flock_id = f.id and not mortality_recorded),
    'days', (select count(*) from v_flock_daily where flock_id = f.id)
  ) into r;
  return r;
end $$;

create or replace function public.complete_flock(
  p_flock uuid, p_client_id uuid, p_dispatch_date date, p_bird_count int,
  p_total_live_weight_kg numeric default null, p_destination text default null, p_notes text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  f flocks%rowtype;
  v_alive int;
  v_summary jsonb;
begin
  select * into f from flocks where id = p_flock for update;
  if not found then raise exception 'FLOCK_NOT_FOUND' using errcode = 'P0002'; end if;
  if not public.can_manage_house(f.house_id) then raise exception 'FORBIDDEN' using errcode = '42501'; end if;
  if f.status <> 'active' then raise exception 'FLOCK_CLOSED' using errcode = '42501'; end if;

  -- Mükerrer kapanış isteği (offline tekrar gönderim) → mevcut sonucu döndür
  if exists (select 1 from dispatch_records where client_id = p_client_id) then
    return public.flock_closing_summary(p_flock);
  end if;

  perform set_config('keypts.closing_flock', f.id::text, true);
  insert into dispatch_records (client_id, flock_id, org_id, farm_id, house_id, entry_date, bird_count,
                                total_live_weight_kg, destination, note, created_by)
  values (p_client_id, f.id, f.org_id, f.farm_id, f.house_id, p_dispatch_date, p_bird_count,
          p_total_live_weight_kg, p_destination, p_notes, auth.uid());

  update flocks set status = 'completed', completed_at = now(), closing_notes = p_notes where id = f.id;
  perform set_config('keypts.closing_flock', '', true);

  v_summary := public.flock_closing_summary(p_flock);
  v_alive := (v_summary ->> 'alive_unaccounted')::int;
  return v_summary || jsonb_build_object(
    'discrepancy', v_alive,
    'discrepancy_message', case when v_alive = 0 then null
      else 'Kayıtlara göre ' || v_alive || ' hayvan sevk/ölüm/çıkış ile açıklanamıyor.' end);
end $$;

-- ---------------------------------------------------------------------
-- Alerts
-- ---------------------------------------------------------------------
-- Alıcılar: organizasyon sahipleri + kümeye atanmış sorumlular
create or replace function public.alert_recipients(p_house uuid, p_pref text)
returns table (user_id uuid, org_id uuid)
language sql stable security definer set search_path = public as $$
  select distinct m.user_id, m.org_id
  from houses h
  join organization_members m on m.org_id = h.org_id
  left join notification_preferences np on np.user_id = m.user_id and np.org_id = m.org_id
  where h.id = p_house
    and (m.role = 'owner'
         or (m.role = 'manager' and exists (select 1 from house_assignments a
                                            where a.house_id = h.id and a.user_id = m.user_id)))
    and coalesce((to_jsonb(np) ->> p_pref)::boolean, p_pref <> 'on_new_entry')
$$;

create or replace function public.notify_house(
  p_house uuid, p_flock uuid, p_pref text, p_kind notification_kind, p_severity text,
  p_title text, p_body text, p_dedupe text, p_data jsonb default '{}', p_exclude uuid default null)
returns void language sql security definer set search_path = public as $$
  insert into notifications (org_id, user_id, kind, severity, title, body, data, flock_id, house_id, dedupe_key)
  select r.org_id, r.user_id, p_kind, p_severity, p_title, p_body, p_data, p_flock, p_house, p_dedupe
  from public.alert_recipients(p_house, p_pref) r
  where p_exclude is null or r.user_id <> p_exclude
  on conflict (user_id, dedupe_key) do nothing
$$;

create or replace function public.tg_alert_mortality()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  s alert_settings%rowtype;
  v_house_name text;
  v_start int;
  v_day int;
  v_pct numeric;
  v_level text;
begin
  if new.deleted_at is not null then return null; end if;
  select a.* into s from alert_settings a where a.farm_id = new.farm_id;
  if not found then return null; end if;
  select name into v_house_name from houses where id = new.house_id;

  v_start := flock_alive_count(new.flock_id, new.entry_date)
             + coalesce((select sum(case when movement_type in ('addition','transfer_in') then count else 0 end)
                         from flock_movements where flock_id = new.flock_id and entry_date = new.entry_date
                           and deleted_at is null), 0);
  select coalesce(sum(count), 0) into v_day from mortality_entries
    where flock_id = new.flock_id and entry_date = new.entry_date and deleted_at is null;
  if v_start <= 0 then return null; end if;
  v_pct := round(v_day::numeric * 100 / v_start, 3);

  v_level := case when v_pct >= s.daily_mortality_critical_pct then 'critical'
                  when v_pct >= s.daily_mortality_warn_pct then 'warning' end;
  if v_level is not null then
    perform notify_house(new.house_id, new.flock_id, 'on_mortality', 'mortality_threshold', v_level,
      v_house_name || ': günlük ölüm eşiği aşıldı',
      to_char(new.entry_date, 'DD.MM.YYYY') || ' itibarıyla ' || v_day || ' ölüm (%' ||
        replace(to_char(v_pct, 'FM990.00'), '.', ',') || '). Eşik: %' ||
        replace(to_char(case when v_level = 'critical' then s.daily_mortality_critical_pct else s.daily_mortality_warn_pct end, 'FM990.00'), '.', ','),
      'mort:' || new.flock_id || ':' || new.entry_date || ':' || v_level,
      jsonb_build_object('pct', v_pct, 'deaths', v_day, 'date', new.entry_date));
  end if;
  return null;
end $$;

create or replace function public.tg_alert_temperature()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_age int;
  t temperature_targets%rowtype;
  v_house_name text;
begin
  if new.deleted_at is not null then return null; end if;
  v_age := public.flock_age(new.flock_id, new.entry_date);
  select * into t from temperature_targets
    where farm_id = new.farm_id and v_age between day_from and day_to
    order by day_from desc limit 1;
  if not found then return null; end if;   -- hedef tanımlı değilse uyarı üretilmez
  if new.temperature_c between t.min_c and t.max_c then return null; end if;
  select name into v_house_name from houses where id = new.house_id;
  perform notify_house(new.house_id, new.flock_id, 'on_temperature', 'temperature_out_of_range', 'warning',
    v_house_name || ': sıcaklık hedef aralık dışında',
    replace(new.temperature_c::text, '.', ',') || ' °C ölçüldü (' || v_age || '. gün hedef: ' ||
      replace(t.min_c::text, '.', ',') || '–' || replace(t.max_c::text, '.', ',') || ' °C)',
    'temp:' || new.id,
    jsonb_build_object('temperature_c', new.temperature_c, 'min_c', t.min_c, 'max_c', t.max_c));
  return null;
end $$;

create or replace function public.tg_alert_withdrawal()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  f flocks%rowtype;
  v_house_name text;
begin
  if new.deleted_at is not null or new.withdrawal_days = 0 then return null; end if;
  select * into f from flocks where id = new.flock_id;
  if f.expected_slaughter_date is null or new.withdrawal_end_date < f.expected_slaughter_date then return null; end if;
  select name into v_house_name from houses where id = new.house_id;
  perform notify_house(new.house_id, new.flock_id, 'on_withdrawal', 'withdrawal_conflict', 'critical',
    v_house_name || ': ilaç bekleme süresi kesim planıyla çakışıyor',
    new.product_name || ' bekleme süresi ' || to_char(new.withdrawal_end_date, 'DD.MM.YYYY') ||
      ' tarihine kadar sürüyor; planlanan kesim ' || to_char(f.expected_slaughter_date, 'DD.MM.YYYY') ||
      '. Veterinerinize danışın.',
    'wd:' || new.id,
    jsonb_build_object('withdrawal_end_date', new.withdrawal_end_date, 'slaughter', f.expected_slaughter_date));
  return null;
end $$;

-- Kesim tarihi sonradan değiştirilirse çakışmaları yeniden kontrol et
create or replace function public.tg_alert_withdrawal_on_flock()
returns trigger language plpgsql security definer set search_path = public as $$
declare m record;
begin
  if new.status <> 'active' or new.expected_slaughter_date is not distinct from old.expected_slaughter_date
     or new.expected_slaughter_date is null then
    return null;
  end if;
  for m in select * from medication_applications
           where flock_id = new.id and deleted_at is null and withdrawal_days > 0
             and withdrawal_end_date >= new.expected_slaughter_date loop
    perform notify_house(new.house_id, new.id, 'on_withdrawal', 'withdrawal_conflict', 'critical',
      (select name from houses where id = new.house_id) || ': ilaç bekleme süresi kesim planıyla çakışıyor',
      m.product_name || ' bekleme süresi ' || to_char(m.withdrawal_end_date, 'DD.MM.YYYY') ||
        ' tarihine kadar; yeni kesim tarihi ' || to_char(new.expected_slaughter_date, 'DD.MM.YYYY') || '.',
      'wd:' || m.id || ':' || new.expected_slaughter_date);
  end loop;
  return null;
end $$;

create or replace function public.tg_alert_new_entry()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_label text;
begin
  v_label := case tg_table_name
    when 'mortality_entries' then 'ölüm kaydı'
    when 'coal_entries' then 'kömür kaydı'
    when 'medication_applications' then 'ilaç kaydı'
    when 'weight_measurements' then 'tartım kaydı'
    when 'temperature_measurements' then 'sıcaklık kaydı'
    else 'not' end;
  perform notify_house(new.house_id, new.flock_id, 'on_new_entry', 'new_entry', 'info',
    (select name from houses where id = new.house_id) || ': yeni ' || v_label,
    coalesce((select full_name from profiles where id = new.created_by), 'Bir çalışan') || ' yeni ' || v_label || ' girdi.',
    'new:' || tg_table_name || ':' || new.id, '{}', new.created_by);
  return null;
end $$;

create trigger zz_alert_mortality after insert or update of count, deleted_at on public.mortality_entries
  for each row execute function public.tg_alert_mortality();
create trigger zz_alert_temperature after insert on public.temperature_measurements
  for each row execute function public.tg_alert_temperature();
create trigger zz_alert_withdrawal after insert on public.medication_applications
  for each row execute function public.tg_alert_withdrawal();
create trigger zz_alert_withdrawal_flock after update of expected_slaughter_date on public.flocks
  for each row execute function public.tg_alert_withdrawal_on_flock();
do $$
declare t text;
begin
  foreach t in array array['mortality_entries','coal_entries','medication_applications','weight_measurements',
                           'temperature_measurements','daily_notes']
  loop
    execute format('create trigger zz_alert_new_entry after insert on public.%I
                    for each row execute function public.tg_alert_new_entry()', t);
  end loop;
end $$;

-- Zamanlanmış uyarılar: eksik günlük rapor, yaklaşan kesim.
-- pg_cron veya alerts-cron Edge Function ile saatlik çağrılır (service_role).
create or replace function public.run_scheduled_alerts()
returns int language plpgsql security definer set search_path = public as $$
declare
  r record;
  v_count int := 0;
  v_now_local timestamp;
  v_days int;
begin
  for r in
    select f.id, f.house_id, f.expected_slaughter_date, h.name as house_name, fm.timezone,
           s.missing_report_hour, s.slaughter_reminder_days
    from flocks f join houses h on h.id = f.house_id join farms fm on fm.id = f.farm_id
    join alert_settings s on s.farm_id = f.farm_id
    where f.status = 'active'
  loop
    v_now_local := now() at time zone r.timezone;
    if extract(hour from v_now_local) >= r.missing_report_hour
       and not exists (select 1 from mortality_entries where flock_id = r.id and deleted_at is null
                       and entry_date = v_now_local::date) then
      perform notify_house(r.house_id, r.id, 'on_missing_report', 'missing_report', 'warning',
        r.house_name || ': günlük kayıt eksik',
        'Bugün için henüz ölüm kaydı girilmedi. Ölüm yoksa "0" olarak kaydedin.',
        'missing:' || r.id || ':' || v_now_local::date);
      v_count := v_count + 1;
    end if;

    if r.expected_slaughter_date is not null then
      v_days := r.expected_slaughter_date - v_now_local::date;
      if v_days between 0 and r.slaughter_reminder_days then
        perform notify_house(r.house_id, r.id, 'on_slaughter', 'slaughter_approaching', 'info',
          r.house_name || ': kesim yaklaşıyor',
          case when v_days = 0 then 'Planlanan kesim tarihi bugün.'
               else 'Planlanan kesime ' || v_days || ' gün kaldı (' || to_char(r.expected_slaughter_date, 'DD.MM.YYYY') || ').' end,
          'slaughter:' || r.id || ':' || v_now_local::date);
        v_count := v_count + 1;
      end if;
    end if;
  end loop;
  return v_count;
end $$;

revoke all on function public.run_scheduled_alerts() from public, anon, authenticated;
revoke all on function public.notify_house(uuid, uuid, text, notification_kind, text, text, text, text, jsonb, uuid) from public, anon, authenticated;
revoke all on function public.alert_recipients(uuid, text) from public, anon, authenticated;
grant execute on function public.create_organization_with_farm(text, jsonb, jsonb),
                          public.create_invitation(uuid, app_role, uuid[], text),
                          public.accept_invitation(text),
                          public.complete_flock(uuid, uuid, date, int, numeric, text, text),
                          public.flock_closing_summary(uuid),
                          public.flock_alive_count(uuid, date),
                          public.flock_placed_total(uuid),
                          public.farm_today(uuid), public.flock_age(uuid, date),
                          public.org_role(uuid), public.is_org_member(uuid), public.is_org_owner(uuid),
                          public.can_access_house(uuid), public.can_manage_house(uuid), public.shares_org_with(uuid)
  to authenticated;

-- Realtime: panelin canlı güncellenmesi için
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    alter publication supabase_realtime add table
      public.mortality_entries, public.coal_entries, public.medication_applications,
      public.weight_measurements, public.temperature_measurements, public.daily_notes,
      public.flocks, public.notifications;
  end if;
end $$;

-- Fotoğraf deposu (Supabase Storage). Yol biçimi: {org_id}/{house_id}/{uuid}.jpg
do $$
begin
  if exists (select 1 from pg_namespace where nspname = 'storage') then
    insert into storage.buckets (id, name, public) values ('entry-photos', 'entry-photos', false)
      on conflict (id) do nothing;
    execute $p$
      create policy entry_photos_read on storage.objects for select to authenticated
        using (bucket_id = 'entry-photos' and public.can_access_house(((storage.foldername(name))[2])::uuid));
      create policy entry_photos_write on storage.objects for insert to authenticated
        with check (bucket_id = 'entry-photos' and public.can_access_house(((storage.foldername(name))[2])::uuid));
    $p$;
  end if;
end $$;
