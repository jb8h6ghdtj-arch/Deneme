-- =====================================================================
-- KEY PTS — Veritabanı kabul testleri (Bölüm 23 senaryoları + Bölüm 20 kuralları)
-- Her test başarısız olursa ON_ERROR_STOP ile süreç durur.
-- =====================================================================
\set QUIET on
create schema if not exists t;
grant usage on schema t to authenticated, anon;

create or replace function t.act_as(p_email text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claim.sub', (select id::text from auth.users where email = p_email), false);
end $$;

create or replace function t.ok(p_cond boolean, p_msg text) returns void language plpgsql as $$
begin
  if p_cond is not true then raise exception 'FAIL: %', p_msg; end if;
  raise notice 'PASS: %', p_msg;
end $$;

-- p_sql çalıştırıldığında p_pattern içeren hata bekler
create or replace function t.throws(p_sql text, p_pattern text, p_msg text) returns void language plpgsql as $$
begin
  begin
    execute p_sql;
  exception when others then
    if sqlerrm ilike '%' || p_pattern || '%' then
      raise notice 'PASS: % (→ %)', p_msg, sqlerrm; return;
    end if;
    raise exception 'FAIL: % — beklenmeyen hata: %', p_msg, sqlerrm;
  end;
  raise exception 'FAIL: % — hata bekleniyordu', p_msg;
end $$;
grant execute on all functions in schema t to authenticated, anon;

-- Kullanıcılar
insert into auth.users (email, raw_user_meta_data) values
  ('owner@key.test',   '{"full_name":"Kemal Sahip"}'),
  ('manager@key.test', '{"full_name":"Murat Sorumlu"}'),
  ('worker1@key.test', '{"full_name":"Ali Bakıcı"}'),
  ('worker2@key.test', '{"full_name":"Veli Bakıcı"}'),
  ('other@farm-b.test','{"full_name":"Başka Çiftlik"}');

select t.ok((select count(*) from public.profiles) = 5, 'Yeni kullanıcı için profil otomatik oluşur');

-- ---------------------------------------------------------------------
-- Senaryo 1: Sahip üç kümes oluşturur, farklı kapasiteler
-- ---------------------------------------------------------------------
select t.act_as('owner@key.test');
set role authenticated;

create temp table ctx as
select (r ->> 'org_id')::uuid as org_id, (r ->> 'farm_id')::uuid as farm_id
from (select public.create_organization_with_farm('KEY Tarım',
        '{"name":"KEY Broiler Farm","default_heating":"coal","default_coal_bag_kg":25}',
        '[{"name":"Kümes 1","capacity":25000},{"name":"Kümes 2","capacity":30000},{"name":"Kümes 3","capacity":20000,"heating_type":"gas"}]'
      ) r) x;
grant select on ctx to authenticated;

select t.ok((select count(*) from houses) = 3, 'S1: üç kümes oluşturuldu');
select t.ok((select sum(capacity) from houses) = 75000, 'S1: toplam kapasite 75.000');
select t.ok((select coal_tracking from houses where name = 'Kümes 3') = false, 'S1: gazlı kümeste kömür takibi kapalı');
select t.ok(public.org_role((select org_id from ctx)) = 'owner', 'S1: kurucu sahip rolünde');

-- Test 2/3: 5 kümes, her biri farklı kapasite
insert into houses (farm_id, org_id, name, capacity, heating_type)
select farm_id, org_id, 'Kümes 4', 18000, 'coal'::heating_type from ctx union all
select farm_id, org_id, 'Kümes 5', 42000, 'electric'::heating_type from ctx;
select t.ok((select count(*) from houses) = 5 and (select count(distinct capacity) from houses) = 5, 'T2/T3: 5 kümes, 5 farklı kapasite');

-- ---------------------------------------------------------------------
-- Senaryo 2: Farklı civciv sayıları, bağımsız dönemler
-- ---------------------------------------------------------------------
insert into flocks (house_id, placement_date, initial_count, expected_slaughter_date, breed)
select id, public.farm_today((select farm_id from ctx)) - 23,
       case name when 'Kümes 1' then 25000 when 'Kümes 2' then 29500 else 19000 end,
       public.farm_today((select farm_id from ctx)) + 20, 'Ross 308'
from houses where name in ('Kümes 1','Kümes 2','Kümes 3');

select t.ok((select count(*) from flocks where status = 'active') = 3, 'S2: üç aktif dönem');
select t.ok((select initial_count from flocks f join houses h on h.id = f.house_id where h.name = 'Kümes 2') = 29500,
            'S2: kapasite (30.000) ile yerleştirilen (29.500) ayrı tutulur');
select t.ok((select age_day from v_flock_overview where house_name = 'Kümes 1') = 23, 'S2: yaş otomatik hesaplanır (giriş günü = 0. gün → 23. gün)');
update farms set age_base = 1;
select t.ok((select age_day from v_flock_overview where house_name = 'Kümes 1') = 24, 'Gün standardı tek ayardan değişir (1 tabanlı → 24. gün)');
update farms set age_base = 0;
select t.ok((select bool_and(cycle_no = 1) from flocks), 'S2: dönem numarası otomatik');
select t.throws($$insert into flocks (house_id, placement_date, initial_count)
                  select id, current_date - 1, 100 from houses where name = 'Kümes 1'$$,
                'flocks_one_active_per_house', 'S2: aynı kümeste ikinci aktif dönem açılamaz');

-- Ekip: davet ve atama
create temp table inv (role text, code text);
grant all on inv to authenticated;
insert into inv select 'manager', public.create_invitation((select org_id from ctx), 'manager',
   array(select id from houses where name in ('Kümes 1','Kümes 2')), null) ->> 'code';
insert into inv select 'worker1', public.create_invitation((select org_id from ctx), 'worker',
   array(select id from houses where name = 'Kümes 1'), 'worker1@key.test') ->> 'code';
insert into inv select 'worker2', public.create_invitation((select org_id from ctx), 'worker',
   array(select id from houses where name = 'Kümes 2'), null) ->> 'code';

reset role; select t.act_as('manager@key.test'); set role authenticated;
select public.accept_invitation((select code from inv where role = 'manager'));
reset role; select t.act_as('worker1@key.test'); set role authenticated;
select public.accept_invitation((select code from inv where role = 'worker1'));
reset role; select t.act_as('worker2@key.test'); set role authenticated;
select public.accept_invitation((select code from inv where role = 'worker2'));
reset role; select t.act_as('other@farm-b.test'); set role authenticated;
select t.throws($$select public.accept_invitation((select code from inv where role = 'worker1'))$$,
                'INVITE_USED', 'Davet kodu yalnızca bir kez kullanılabilir');
reset role;

-- Başka çiftlik (Çiftlik B)
select t.act_as('other@farm-b.test'); set role authenticated;
select public.create_organization_with_farm('B Ltd', '{"name":"B Farm"}', '[{"name":"B-1","capacity":10000}]');
insert into flocks (house_id, placement_date, initial_count) select id, current_date - 5, 9000 from houses;
reset role;

-- ---------------------------------------------------------------------
-- Senaryo 3: Bakıcı yalnızca yetkili kümeyi görür, 18 ölüm kaydeder
-- ---------------------------------------------------------------------
select t.act_as('worker1@key.test'); set role authenticated;
select t.ok((select count(*) from houses) = 1 and (select name from houses) = 'Kümes 1',
            'S3: bakıcı yalnızca atandığı kümeyi görür');
select t.ok((select count(*) from flocks) = 1, 'S3: bakıcı yalnızca kendi kümesinin dönemini görür');

-- Yetki yükseltme denemeleri (istemciden rol değiştirme)
do $$
declare n int;
begin
  update organization_members set role = 'owner' where user_id = auth.uid();
  get diagnostics n = row_count;
  perform t.ok(n = 0 and (select role from organization_members where user_id = auth.uid()) = 'worker',
               'Bakıcı kendi rolünü "owner" yapamaz (RLS)');
  update flocks set initial_count = 1;
  get diagnostics n = row_count;
  perform t.ok(n = 0, 'Bakıcı dönem bilgilerini değiştiremez');
end $$;
select t.throws($$insert into organization_members (org_id, user_id, role) select org_id, auth.uid(), 'owner' from ctx$$,
                'permission denied', 'Bakıcı kendine üyelik/rol ekleyemez');
do $$
declare n int;
begin
  update house_assignments set permissions = array['record','manage'] where user_id = auth.uid();
  get diagnostics n = row_count;
  perform t.ok(n = 0 and not public.can_manage_house((select house_id from house_assignments where user_id = auth.uid())),
               'Bakıcı kendine kümes yönetim yetkisi veremez');
end $$;
reset role;
do $$
declare v_h2 uuid := (select id from houses where name = 'Kümes 2');
begin
  set local role authenticated;
  perform t.throws(format($q$insert into house_assignments (house_id, user_id) values (%L, auth.uid())$q$, v_h2),
                   'row-level security', 'Bakıcı kendini başka kümeye atayamaz');
  reset role;
end $$;
set role authenticated;

insert into mortality_entries (client_id, flock_id, entry_date, count, note)
select 'aaaaaaaa-0000-0000-0000-000000000001', id, public.farm_today(farm_id), 18, 'Sabah kontrolü' from flocks;

select t.ok((select today_deaths from v_flock_overview) = 18, 'S3: bugünkü ölüm 18');
select t.ok((select alive_count from v_flock_overview) = 24982, 'S3: mevcut hayvan sayısı 25.000 − 18 = 24.982');
select t.ok((select org_id from mortality_entries limit 1) = (select org_id from ctx),
            'S3: org/kümes bilgisi dönemden türetilir (istemci sahteleyemez)');

-- Çift kayıt önlemi: aynı client_id ikinci kez gönderilir (offline yeniden deneme)
insert into mortality_entries (client_id, flock_id, entry_date, count)
select 'aaaaaaaa-0000-0000-0000-000000000001', id, public.farm_today(farm_id), 18 from flocks
on conflict (client_id) do nothing;
select t.ok((select sum(count) from mortality_entries) = 18, 'S3/S7: aynı client_id ile tekrar gönderim mükerrer kayıt oluşturmaz');

-- Gün içinde ikinci ölüm kaydı → otomatik toplam
insert into mortality_entries (client_id, flock_id, entry_date, count)
select gen_random_uuid(), id, public.farm_today(farm_id), 4 from flocks;
select t.ok((select today_deaths from v_flock_overview) = 22, 'Bir günde birden fazla ölüm kaydı toplanır (18+4)');

-- Kurallar
select t.throws($$insert into mortality_entries (client_id, flock_id, entry_date, count)
                  select gen_random_uuid(), id, public.farm_today(farm_id), -1 from flocks$$,
                'check', 'Negatif ölüm sayısı reddedilir');
select t.throws($$insert into mortality_entries (client_id, flock_id, entry_date, count)
                  select gen_random_uuid(), id, public.farm_today(farm_id), 999999 from flocks$$,
                'EXCEEDS_ALIVE', 'Ölüm sayısı mevcut hayvan sayısını aşamaz');
select t.throws($$insert into mortality_entries (client_id, flock_id, entry_date, count)
                  select gen_random_uuid(), id, public.farm_today(farm_id) + 1, 1 from flocks$$,
                'DATE_IN_FUTURE', 'İleri tarihli kayıt reddedilir');
select t.throws($$insert into mortality_entries (client_id, flock_id, entry_date, count)
                  select gen_random_uuid(), id, placement_date - 1, 1 from flocks$$,
                'DATE_BEFORE_PLACEMENT', 'Giriş tarihinden önceki kayıt reddedilir');
select t.throws($$insert into flock_movements (client_id, flock_id, entry_date, movement_type, count)
                  select gen_random_uuid(), id, public.farm_today(farm_id), 'cull', 5 from flocks$$,
                'row-level security', 'Bakıcı sürü hareketi (ayıklama/transfer) giremez');

-- Kayıt yok ≠ sıfır ölüm
select t.ok((select count(*) from v_flock_daily where not mortality_recorded) = 23,
            'Kayıt girilmeyen 23 gün "kayıt yok" olarak işaretlenir (sıfır sayılmaz)');
select t.ok((select deaths is null and daily_mortality_pct is null from v_flock_daily order by day limit 1),
            'Kayıtsız günün ölüm sayısı ve oranı NULL');
insert into mortality_entries (client_id, flock_id, entry_date, count)
select gen_random_uuid(), id, placement_date, 0 from flocks;
select t.ok((select deaths = 0 and mortality_recorded from v_flock_daily order by day limit 1),
            '"0 ölüm" kaydı kayıtsız günden ayrıdır');

-- Oranlar
select t.ok((select daily_mortality_pct from v_flock_daily order by day desc limit 1) = round(22 * 100.0 / 25000, 3),
            'Günlük ölüm oranı = günlük ölüm / gün başı mevcut × 100');
select t.ok((select cumulative_mortality_pct from v_flock_overview) = round(22 * 100.0 / 25000, 3),
            'Kümülatif ölüm oranı = toplam ölüm / yerleştirilen × 100');

-- Düzeltme → denetim kaydı (eski/yeni değer, kişi, zaman)
update mortality_entries set count = 17, note = 'Düzeltme: 17' where client_id = 'aaaaaaaa-0000-0000-0000-000000000001';
reset role;
select t.ok((select old_data ->> 'count' = '18' and new_data ->> 'count' = '17'
                    and actor_id = (select id from auth.users where email = 'worker1@key.test')
                    and 'count' = any(changed_fields)
             from audit_logs where table_name = 'mortality_entries' and action = 'UPDATE'),
            'Düzeltmede eski/yeni değer, çalışan kimliği ve zaman denetime yazılır');
select t.ok((select version from mortality_entries where client_id = 'aaaaaaaa-0000-0000-0000-000000000001') = 2,
            'Düzenleme sürüm numarasını artırır (çakışma tespiti için)');

-- Eşzamanlı düzenleme: eski sürümle güncelleme 0 satır etkiler (sessiz üzerine yazma yok)
select t.act_as('worker1@key.test'); set role authenticated;
do $$
declare n int;
begin
  update mortality_entries set count = 16 where client_id = 'aaaaaaaa-0000-0000-0000-000000000001' and version = 1;
  get diagnostics n = row_count;
  perform t.ok(n = 0, 'Eski sürüme dayalı düzenleme reddedilir (optimistic concurrency)');
end $$;

-- ---------------------------------------------------------------------
-- Senaryo 4: 8 torba kömür
-- ---------------------------------------------------------------------
insert into coal_entries (client_id, flock_id, entry_date, bag_count, bag_weight_kg)
select gen_random_uuid(), id, public.farm_today(farm_id), 8, 25 from flocks;
select t.ok((select today_coal_bags = 8 and today_coal_kg = 200 from v_flock_overview),
            'S4: 8 torba × 25 kg = 200 kg, bugünkü kömüre eklenir');
select t.throws($$update coal_entries set total_kg = 1$$, 'DEFAULT', 'Toplam kg istemciden yazılamaz (torba/kg karışmaz)');

-- ---------------------------------------------------------------------
-- Senaryo 5: Veteriner talimatlı ilaç + sahip geçmişte görür
-- ---------------------------------------------------------------------
select t.throws($$insert into medication_products (org_id, name) select org_id, 'X' from ctx$$,
                'row-level security', 'Bakıcı ilaç kataloğunu değiştiremez');
reset role; select t.act_as('owner@key.test'); set role authenticated;
insert into medication_products (org_id, name, default_unit, withdrawal_days)
select org_id, 'Ürün A', 'ml', 0 from ctx union all
select org_id, 'Ürün B', 'g', 25 from ctx;
reset role; select t.act_as('worker1@key.test'); set role authenticated;

insert into medication_applications (client_id, flock_id, product_id, entry_date, amount, unit, method, vet_instruction_ref)
select gen_random_uuid(), f.id, p.id, public.farm_today(f.farm_id), 500, 'ml', 'drinking_water', 'Reçete #2026-118'
from flocks f, medication_products p where p.name = 'Ürün A';
reset role; select t.act_as('owner@key.test'); set role authenticated;
select t.ok((select count(*) from v_activity a join profiles p on p.id = a.created_by
             where a.kind = 'medication' and p.full_name = 'Ali Bakıcı' and a.label like 'Ürün A%') = 1,
            'S5: sahip ilaç kaydını işlem geçmişinde bakıcı adıyla görür');

-- Bekleme süresi çakışması (25 gün > kesime 20 gün)
reset role; select t.act_as('worker1@key.test'); set role authenticated;
insert into medication_applications (client_id, flock_id, product_id, entry_date, amount, unit)
select gen_random_uuid(), f.id, p.id, public.farm_today(f.farm_id), 100, 'g'
from flocks f, medication_products p where p.name = 'Ürün B';
select t.ok((select withdrawal_conflict from v_flock_overview), 'Bekleme süresi kesim tarihini aşınca çakışma işaretlenir');
reset role;
select t.ok(exists (select 1 from notifications n join auth.users u on u.id = n.user_id
                    where n.kind = 'withdrawal_conflict' and u.email = 'owner@key.test'),
            'Bekleme süresi çakışması sahibe bildirim üretir');

-- ---------------------------------------------------------------------
-- Senaryo 6: Örneklem tartımı, birim dönüşümü
-- ---------------------------------------------------------------------
select t.act_as('worker1@key.test'); set role authenticated;
insert into weight_measurements (client_id, flock_id, entry_date, sample_count, input_mode, input_value, input_unit)
select gen_random_uuid(), id, public.farm_today(farm_id) - 7, 50, 'average', 0.62, 'kg' from flocks;
insert into weight_measurements (client_id, flock_id, entry_date, sample_count, input_mode, input_value, input_unit)
select gen_random_uuid(), id, public.farm_today(farm_id), 40, 'total', 46, 'kg' from flocks;
select t.ok((select last_weight_g = 1150 and last_weight_sample = 40 from v_flock_overview),
            'S6: toplam 46 kg / 40 örnek = 1.150 g ortalama; örneklem büyüklüğü saklanır');
select t.ok((select avg_weight_g from weight_measurements where input_unit = 'kg' and input_mode = 'average') = 620,
            'S6: 0,62 kg → 620 g dönüşümü');
select t.ok((select count(*) from v_flock_daily where avg_weight_g is not null) = 2,
            'S6: ölçüm yapılmayan günlere tartım değeri yazılmaz');
select t.throws($$insert into weight_measurements (client_id, flock_id, entry_date, sample_count, input_value, input_unit)
                  select gen_random_uuid(), id, public.farm_today(farm_id), 10, 50, 'kg' from flocks$$,
                'check', 'Mantıksız ağırlık (50 kg ortalama) reddedilir');

-- Sıcaklık hedefi: tanımlı değilse uyarı yok; tanımlanınca hedef dışı uyarı
insert into temperature_measurements (client_id, flock_id, measured_at, temperature_c, entry_date)
select gen_random_uuid(), id, now(), 35, current_date from flocks;
reset role;
select t.ok(not exists (select 1 from notifications where kind = 'temperature_out_of_range'),
            'Hedef aralık tanımlanmadan sıcaklık uyarısı üretilmez (keyfi teşhis yok)');
select t.act_as('owner@key.test'); set role authenticated;
insert into temperature_targets (org_id, farm_id, day_from, day_to, min_c, max_c)
select org_id, farm_id, 15, 28, 22, 26 from ctx;
reset role; select t.act_as('worker1@key.test'); set role authenticated;
insert into temperature_measurements (client_id, flock_id, measured_at, temperature_c, entry_date)
select gen_random_uuid(), id, now(), 29.5, current_date from flocks;
reset role;
select t.ok(exists (select 1 from notifications where kind = 'temperature_out_of_range'),
            'Sahibin tanımladığı aralık dışındaki ölçüm uyarı üretir');

-- ---------------------------------------------------------------------
-- Senaryo 8: Sahip başka cihazdan güncel verileri görür
-- (Veriler sunucuda; sahip tüm kümeleri ve bakıcının kayıtlarını okur)
-- ---------------------------------------------------------------------
select t.act_as('owner@key.test'); set role authenticated;
select t.ok((select count(*) from v_flock_overview) = 3, 'S8: sahip kendi çiftliğindeki tüm kümeleri görür');
select t.ok((select sum(count) from mortality_entries) = 21, 'S8: sahip bakıcının senkronize kayıtlarını görür');
select t.ok((select count(*) from audit_logs) > 0, 'S8: sahip denetim kayıtlarını görür');

-- Sorumlu (manager): yalnızca atandığı kümeler
reset role; select t.act_as('manager@key.test'); set role authenticated;
select t.ok((select count(*) from houses) = 2, 'Sorumlu yalnızca yetki verilen 2 kümeyi görür');
select t.throws($$select public.create_invitation((select org_id from ctx), 'manager', '{}', null)$$,
                'MANAGER_CAN_INVITE_WORKERS_ONLY', 'Sorumlu yeni sorumlu davet edemez');
reset role;
do $$
declare v_h3 uuid := (select id from houses where name = 'Kümes 3');
begin
  set local role authenticated;
  perform t.throws(format($q$select public.create_invitation((select org_id from ctx), 'worker', array[%L::uuid], null)$q$, v_h3),
                   'HOUSE_NOT_MANAGED', 'Sorumlu yetkisi olmayan kümeye bakıcı davet edemez');
  reset role;
end $$;
set role authenticated;

-- Kümes bazlı yetki: sahip, sorumlunun Kümes 2 yönetim yetkisini kaldırır
reset role; select t.act_as('owner@key.test'); set role authenticated;
update house_assignments set permissions = array['record']
  where user_id = (select id from auth.users where email = 'manager@key.test') and house_id = (select id from houses where name = 'Kümes 2');
reset role; select t.act_as('manager@key.test'); set role authenticated;
select t.ok(not public.can_manage_house((select id from houses where name = 'Kümes 2'))
            and public.can_access_house((select id from houses where name = 'Kümes 2')),
            'Sorumlu yetkisi kümes bazında sınırlandırılır (Kümes 2: yalnız kayıt)');
select t.ok(public.can_manage_house((select id from houses where name = 'Kümes 1')), 'Sorumlu Kümes 1''i yönetmeye devam eder');
-- Sorumlu sürü hareketi girer (ayıklama) → mevcut sayı düşer
insert into flock_movements (client_id, flock_id, entry_date, movement_type, count, note)
select gen_random_uuid(), f.id, public.farm_today(f.farm_id), 'cull', 10, 'Ayıklama'
from flocks f join houses h on h.id = f.house_id where h.name = 'Kümes 1';
select t.ok((select alive_count from v_flock_overview where house_name = 'Kümes 1') = 25000 - 21 - 10,
            'Ayıklama mevcut hayvan sayısından düşülür');

-- Sorumlu başkasının kaydını düzeltebilir; worker2 düzeltemez
reset role; select t.act_as('worker2@key.test'); set role authenticated;
do $$
declare n int;
begin
  update mortality_entries set count = 1;  -- worker1'in kümesi: görünmez
  get diagnostics n = row_count;
  perform t.ok(n = 0, 'Bakıcı başka kümenin kaydını değiştiremez');
end $$;

-- ---------------------------------------------------------------------
-- Senaryo 10: Yetkisiz erişim
-- ---------------------------------------------------------------------
reset role; select t.act_as('other@farm-b.test'); set role authenticated;
select t.ok((select count(*) from houses) = 1 and (select name from houses) = 'B-1',
            'S10: Çiftlik B kullanıcısı Çiftlik A kümelerini göremez');
select t.ok((select count(*) from mortality_entries) = 0, 'S10: Çiftlik A ölüm kayıtları görünmez');
select t.ok((select count(*) from audit_logs where org_id = (select org_id from ctx)) = 0, 'S10: Çiftlik A denetim kayıtları görünmez');
select t.throws($$insert into mortality_entries (client_id, flock_id, entry_date, count)
                  values (gen_random_uuid(), (select f.id from flocks f join houses h on h.id=f.house_id where h.name='Kümes 1'), current_date, 1)$$,
                'FLOCK_NOT_FOUND', 'S10: Çiftlik A dönemine kayıt yazamaz');
reset role;
-- Saldırgan Çiftlik A'nın flock_id'sini bilse bile:
do $$
declare v_flock uuid := (select f.id from flocks f join houses h on h.id=f.house_id where h.name='Kümes 1');
begin
  perform t.act_as('other@farm-b.test');
  set local role authenticated;
  perform t.throws(format($q$insert into mortality_entries (client_id, flock_id, entry_date, count)
                    values (gen_random_uuid(), %L, public.farm_today((select id from public.farms limit 1)), 1)$q$, v_flock),
                  'row-level security', 'S10: flock_id bilinse bile başka çiftliğe yazılamaz (RLS)');
  perform t.throws(format($q$select public.complete_flock(%L, gen_random_uuid(), current_date, 100)$q$, v_flock),
                  'FORBIDDEN', 'S10: başka çiftliğin dönemi kapatılamaz');
  reset role;
end $$;

select t.act_as('worker1@key.test'); set role authenticated;
select t.ok((select count(*) from houses where name = 'Kümes 2') = 0, 'S10: bakıcı yetkisiz kümeyi göremez');
select t.throws($$select public.complete_flock((select id from flocks limit 1), gen_random_uuid(), current_date, 100)$$,
                'FORBIDDEN', 'Bakıcı dönemi kapatamaz');
reset role;
set role anon;
select t.throws($$select count(*) from public.houses$$, 'permission denied', 'Anonim kullanıcı hiçbir veriye erişemez');
reset role;

-- ---------------------------------------------------------------------
-- Bildirimler: eşik aşımı ve tercih
-- ---------------------------------------------------------------------
select t.ok(exists (select 1 from notifications where kind = 'mortality_threshold')
            = ((22 * 100.0 / 25000) >= 0.30), 'Ölüm eşiği kontrolü yapılandırılmış eşiklere göre çalışır');
select t.act_as('worker1@key.test'); set role authenticated;
insert into mortality_entries (client_id, flock_id, entry_date, count)
select gen_random_uuid(), id, public.farm_today(farm_id) - 1, 200 from flocks;  -- %0,8 > kritik %0,6
reset role;
select t.ok(exists (select 1 from notifications n join auth.users u on u.id = n.user_id
                    where n.kind = 'mortality_threshold' and n.severity = 'critical' and u.email = 'owner@key.test'),
            'Kritik ölüm eşiği sahibe bildirim üretir');
select t.ok(not exists (select 1 from notifications n join auth.users u on u.id = n.user_id
                        where u.email = 'worker1@key.test'), 'Bakıcıya yönetim bildirimi gitmez');
select t.ok(not exists (select 1 from notifications where kind = 'new_entry'),
            '"Yeni kayıt" bildirimi varsayılan kapalı (tercihe bağlı)');
select t.ok(public.run_scheduled_alerts() >= 0, 'Zamanlanmış uyarı fonksiyonu çalışır');

-- ---------------------------------------------------------------------
-- Senaryo 9: Dönem kapanışı, arşiv, yeni dönem
-- ---------------------------------------------------------------------
select t.act_as('owner@key.test'); set role authenticated;
create temp table closing as
select public.complete_flock(f.id, 'bbbbbbbb-0000-0000-0000-000000000001', public.farm_today(f.farm_id), 24700, 67925,
                             'Entegre tesis', 'Sorunsuz dönem') as s
from flocks f join houses h on h.id = f.house_id where h.name = 'Kümes 1';
select t.ok((select (s ->> 'discrepancy')::int from closing) = 25000 - 221 - 10 - 24700,
            'S9: başlangıç ile sevk arasındaki tutarsızlık hesaplanıp belirtilir');
select t.ok((select s ->> 'coal_bags' from closing)::numeric = 8, 'S9: kapanış özetinde toplam kömür');
select t.ok(jsonb_array_length((select s -> 'medications' from closing)) = 2, 'S9: kapanış özetinde ilaç özeti');
select t.ok((select avg_weight_kg from dispatch_records) = 2.750, 'S9: ortalama sevk ağırlığı = 67.925 / 24.700');

-- Mükerrer kapanış isteği (offline tekrar) güvenli
select t.throws($$select public.complete_flock(f.id, 'bbbbbbbb-0000-0000-0000-000000000001', current_date, 24700)
                  from flocks f join houses h on h.id = f.house_id where h.name = 'Kümes 1'$$,
                'FLOCK_CLOSED', 'S9: kapalı dönem yeniden kapatılamaz');

reset role; select t.act_as('worker1@key.test'); set role authenticated;
select t.throws($$insert into mortality_entries (client_id, flock_id, entry_date, count)
                  select gen_random_uuid(), id, current_date, 1 from flocks$$,
                'FLOCK_CLOSED', 'S9: tamamlanmış döneme kayıt eklenemez');
select t.throws($$update mortality_entries set count = 1$$, 'FLOCK_CLOSED', 'S9: tamamlanmış dönem kayıtları değiştirilemez');

reset role; select t.act_as('owner@key.test'); set role authenticated;
insert into flocks (house_id, placement_date, initial_count)
select id, public.farm_today(farm_id), 24000 from houses where name = 'Kümes 1';
select t.ok((select cycle_no from flocks f join houses h on h.id = f.house_id where h.name = 'Kümes 1' and status = 'active') = 2,
            'S9: aynı kümede 2. dönem başlatılır');
select t.ok((select total_deaths = 0 and alive_count = 24000 from v_flock_overview
             where house_name = 'Kümes 1' and status = 'active'),
            'S9: yeni dönem önceki dönemin verilerini devralmaz (veri sızıntısı yok)');
select t.ok((select total_deaths from v_flock_overview where house_name = 'Kümes 1' and status = 'completed') = 221,
            'S9: geçmiş dönem kayıtları arşivde korunur');
select t.ok((select count(*) from v_flock_daily f join flocks fl on fl.id = f.flock_id where fl.status = 'completed') = 24,
            'S9: arşivlenmiş dönemin günlük geçmişi okunabilir');
reset role;

select t.act_as('owner@key.test'); set role authenticated;
insert into mortality_entries (client_id, flock_id, entry_date, count)
select gen_random_uuid(), f.id, f.placement_date + 1, 3 from flocks f join houses h on h.id = f.house_id where h.name = 'Kümes 2' and f.status = 'active';
select t.throws($$update flocks set placement_date = placement_date + 5 where status = 'active' and house_id = (select id from houses where name = 'Kümes 2')$$,
                'PLACEMENT_AFTER_ENTRIES', 'Giriş tarihi mevcut kayıtların sonrasına taşınamaz');
update flocks set expected_slaughter_date = expected_slaughter_date + 3 where status = 'active' and house_id = (select id from houses where name = 'Kümes 2');
select t.ok((select days_to_slaughter from v_flock_overview where house_name = 'Kümes 2' and status = 'active') = 23, 'Sahip kesim planını değiştirebilir; kalan gün yeniden hesaplanır');
reset role;
select t.throws($$delete from organization_members where role = 'owner' and org_id = (select org_id from ctx)$$,
                'LAST_OWNER', 'Organizasyonun son sahibi kaldırılamaz');

\echo '=== Tüm veritabanı kabul testleri geçti ==='
