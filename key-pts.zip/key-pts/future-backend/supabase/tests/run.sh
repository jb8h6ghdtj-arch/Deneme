#!/usr/bin/env bash
# Yerel PostgreSQL üzerinde migration + RLS + kabul senaryosu testleri
# Kullanım: PGHOST=/tmp PGPORT=54329 ./supabase/tests/run.sh
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
DB=keypts_test
psql -U postgres -q -c "drop database if exists $DB" -c "create database $DB"
P="psql -U postgres -d $DB -v ON_ERROR_STOP=1 -q -o /dev/null"
$P -f "$DIR/tests/00_supabase_stub.sql"
for f in "$DIR"/migrations/*.sql; do echo "→ migration $(basename "$f")"; $P -f "$f"; done
for f in "$DIR"/tests/1*.sql; do echo "→ test $(basename "$f")"; $P -f "$f"; done
echo "ALL DATABASE TESTS PASSED"
