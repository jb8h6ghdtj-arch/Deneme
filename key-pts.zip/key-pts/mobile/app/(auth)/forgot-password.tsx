// Yerel şifre sıfırlama: sunucu olmadığı için e-posta gönderilmez.
// Kullanıcı adı + kurulumda girilen çiftlik adı doğrulanır, yeni şifre belirlenir.
import React, { useState } from 'react';
import { Button, Card, Notice, Screen, Text, TextField } from '../../src/components/ui';
import { errorMessage } from '../../src/lib/errors';
import { dataClient } from '../../src/lib/data';
import { nav } from '../../src/navigation/nav';

export default function ForgotPassword() {
  const [v, setV] = useState({ user: '', farm: '', pw: '', pw2: '' });
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ tone: 'success' | 'danger'; text: string } | null>(null);
  const submit = async () => {
    if (!v.user.trim() || !v.farm.trim()) return setMsg({ tone: 'danger', text: 'Kullanıcı adını ve çiftlik adını girin.' });
    if (v.pw.length < 6) return setMsg({ tone: 'danger', text: 'Yeni şifre en az 6 karakter olmalı.' });
    if (v.pw !== v.pw2) return setMsg({ tone: 'danger', text: 'Şifreler eşleşmiyor.' });
    setBusy(true); setMsg(null);
    const { error } = await dataClient.auth.resetPasswordLocal({ username: v.user, farmName: v.farm, newPassword: v.pw });
    setBusy(false);
    if (error) return setMsg({ tone: 'danger', text: errorMessage(error) });
    setMsg({ tone: 'success', text: 'Şifreniz güncellendi. Yeni şifrenizle giriş yapabilirsiniz.' });
    setTimeout(() => nav.back(), 1200);
  };
  return (
    <Screen title="Şifremi Unuttum" back>
      <Card style={{ gap: 14 }}>
        <Text variant="cardTitle">Şifrenizi yenileyin</Text>
        <Text muted>KEY PTS bu cihazda çalışır. Doğrulama için kullanıcı adınızı ve kurulumda girdiğiniz çiftlik adını yazın.</Text>
        <TextField label="Kullanıcı adı" icon="user" value={v.user} onChangeText={(x) => setV({ ...v, user: x })} autoCapitalize="none" autoCorrect={false} />
        <TextField label="Çiftlik adı" icon="farm" value={v.farm} onChangeText={(x) => setV({ ...v, farm: x })} />
        <TextField label="Yeni şifre" icon="lock" value={v.pw} onChangeText={(x) => setV({ ...v, pw: x })} secureTextEntry />
        <TextField label="Yeni şifre (tekrar)" icon="lock" value={v.pw2} onChangeText={(x) => setV({ ...v, pw2: x })} secureTextEntry />
        {msg && <Notice tone={msg.tone}>{msg.text}</Notice>}
        <Button title="Şifreyi Yenile" icon="check" loading={busy} onPress={submit} />
      </Card>
    </Screen>
  );
}
