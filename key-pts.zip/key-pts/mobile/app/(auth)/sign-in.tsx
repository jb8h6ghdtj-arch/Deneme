// Giriş ekranı — referans: lacivert gradyan, kurumsal logo, koyu cam görünümlü alanlar, turuncu buton, kümes içi görsel.
import { zodResolver } from '@hookform/resolvers/zod';
import { LinearGradient } from 'expo-linear-gradient';
import { Link } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { z } from 'zod';
import { KeyPTSLogoOnDark } from '../../src/components/brand/Logo';
import { PoultryHouseScene } from '../../src/components/brand/PoultryHouseScene';
import { Icon, type IconName } from '../../src/components/Icon';
import { Button, Text } from '../../src/components/ui';
import { useAppStatus } from '../../src/stores/appStatus';
import { useLayout } from '../../src/hooks/useLayout';
import { errorMessage } from '../../src/lib/errors';
import { dataClient } from '../../src/lib/data';
import { colors, fontFamily, radius, spacing } from '../../src/theme';

const schema = z.object({
  email: z.string().trim().min(1, 'Kullanıcı adınızı girin'),
  password: z.string().min(1, 'Şifrenizi girin'),
});

function DarkField({ icon, error, right, ...p }: React.ComponentProps<typeof TextInput> & { icon: IconName; error?: string; right?: React.ReactNode }) {
  return (
    <View style={{ gap: 4 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md, height: 54, borderRadius: radius.pill, paddingHorizontal: spacing.xl,
        backgroundColor: colors.input.onNavy, borderWidth: 1, borderColor: error ? '#FF8A8F' : colors.input.onNavyBorder }}>
        <Icon name={icon} color="#E8EDF3" size={20} />
        <TextInput placeholderTextColor="#C2CCD7" style={{ flex: 1, color: '#fff', fontFamily: fontFamily.medium, fontSize: 15 }} maxFontSizeMultiplier={1.3} {...p} />
        {right}
      </View>
      {error ? <Text variant="caption" color="#FFB3B6">{error}</Text> : null}
    </View>
  );
}

export default function SignIn() {
  const insets = useSafeAreaInsets();
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const sample = useAppStatus((s) => s.sample);
  const { width, height } = useLayout();
  const logoW = Math.min(240, width * 0.58);
  const { control, handleSubmit, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(schema), defaultValues: { email: '', password: '' } });
  const onSubmit = handleSubmit(async (v) => {
    setError(null);
    const { error: e } = await dataClient.auth.signInWithPassword({ email: v.email.trim(), password: v.password });
    if (e) setError(errorMessage(e));
  });

  return (
    <LinearGradient colors={[colors.brand.navySoft, colors.brand.navy, colors.brand.navyDeep]} style={{ flex: 1 }}>
      <StatusBar style="light" />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled" bounces={false}>
          <View style={{ paddingTop: insets.top + (height < 640 ? 24 : 56), paddingHorizontal: Math.max(20, Math.min(32, width * 0.07)), width: '100%', maxWidth: 480, alignSelf: 'center', gap: spacing.lg }}>
            <View style={{ alignItems: 'center', marginBottom: height < 640 ? 20 : 36 }}><KeyPTSLogoOnDark width={logoW} /></View>
            <Controller control={control} name="email" render={({ field }) => (
              <DarkField icon="user" placeholder="Kullanıcı Adı" value={field.value} onChangeText={field.onChange} autoCapitalize="none" autoCorrect={false}
                autoComplete="username" textContentType="username" accessibilityLabel="Kullanıcı Adı" error={errors.email?.message} returnKeyType="next" />
            )} />
            <Controller control={control} name="password" render={({ field }) => (
              <DarkField icon="lock" placeholder="Şifre" value={field.value} onChangeText={field.onChange} secureTextEntry={!show} autoComplete="password" textContentType="password"
                accessibilityLabel="Şifre" error={errors.password?.message} onSubmitEditing={() => void onSubmit()} returnKeyType="go"
                right={<Pressable onPress={() => setShow(!show)} hitSlop={10} accessibilityLabel={show ? 'Şifreyi gizle' : 'Şifreyi göster'}><Icon name={show ? 'eyeOff' : 'eye'} color="#E8EDF3" size={20} /></Pressable>} />
            )} />
            {error && <View style={{ padding: spacing.md, borderRadius: radius.input, backgroundColor: 'rgba(217,75,85,0.18)', borderWidth: 1, borderColor: 'rgba(255,138,143,0.4)' }} accessibilityRole="alert"><Text variant="label" color="#FFD3D5">{error}</Text></View>}
            <Button title="Giriş Yap" pill loading={isSubmitting} onPress={() => void onSubmit()} />
            <Link href="/(auth)/forgot-password" asChild>
              <Pressable hitSlop={8} style={{ alignSelf: 'center' }}><Text variant="bodyStrong" color="#E8EDF3" style={{ textDecorationLine: 'underline' }}>Şifremi Unuttum</Text></Pressable>
            </Link>
            {sample ? <Text variant="caption" color="#AFC0D0" style={{ textAlign: 'center' }}>Bu cihazda örnek veriler yüklü.</Text> : null}
          </View>
          <View style={{ flex: 1, minHeight: 160, justifyContent: 'flex-end', marginTop: 24 }}><PoultryHouseScene height={Math.max(170, Math.min(300, height * 0.34))} /></View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}
