import { Tabs } from 'expo-router';
import React from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useActiveOrg } from '../../src/api/queries';
import { Icon, type IconName } from '../../src/components/Icon';
import { colors, fontFamily } from '../../src/theme';

export default function TabsLayout() {
  const insets = useSafeAreaInsets();
  const { role } = useActiveOrg();
  const icon = (name: IconName) => ({ color, focused }: { color: unknown; focused: boolean }) => <Icon name={name} color={String(color)} size={22} strokeWidth={focused ? 2.4 : 2} />;
  return (
    <Tabs screenOptions={{
      headerShown: false,
      tabBarActiveTintColor: colors.brand.orange, tabBarInactiveTintColor: colors.text.primary,
      tabBarStyle: { backgroundColor: colors.surface.primary, borderTopColor: colors.border.default, height: 68 + insets.bottom, paddingTop: 6, paddingBottom: Math.max(insets.bottom, 8) },
      tabBarLabelStyle: { fontSize: 11, lineHeight: 15, paddingBottom: 1, fontFamily: fontFamily.medium },
    }}>
      <Tabs.Screen name="index" options={{ title: 'Ana Sayfa', tabBarIcon: icon('home') }} />
      <Tabs.Screen name="houses" options={{ title: 'Kümesler', tabBarIcon: icon('house') }} />
      <Tabs.Screen name="record" options={{ title: 'Kayıt Ekle', tabBarIcon: icon('plus') }} />
      <Tabs.Screen name="reports" options={{ title: 'Raporlar', tabBarIcon: icon('chart'), href: role === 'worker' ? null : undefined }} />
      <Tabs.Screen name="profile" options={{ title: 'Profil', tabBarIcon: icon('profile') }} />
    </Tabs>
  );
}
