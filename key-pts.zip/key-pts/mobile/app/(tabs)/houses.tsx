// Kümesler — referans ekran 11. Kapasite (fiziksel sınır) ile mevcut hayvan (kalan) ayrı gösterilir.
import { router } from 'expo-router';
import { nav, routes, type ModuleKind, type SingleEntryKind } from '../../src/navigation/nav';
import React from 'react';
import { RefreshControl, View } from 'react-native';
import { useActiveFlocks, useActiveOrg, useHouses } from '../../src/api/queries';
import { Icon } from '../../src/components/Icon';
import { Button, Card, EmptyState, Loading, Pill, Row, Screen, Text } from '../../src/components/ui';
import { fmtInt, fmtPct } from '../../src/lib/format';
import { colors, fontFamily, spacing } from '../../src/theme';

export default function Houses() {
  const { role } = useActiveOrg();
  const houses = useHouses();
  const flocks = useActiveFlocks();
  return (
    <Screen title="Kümesler"
      refreshControl={<RefreshControl refreshing={houses.isRefetching} onRefresh={() => { void houses.refetch(); void flocks.refetch(); }} tintColor={colors.brand.orange} />}>
      {houses.isLoading ? <Loading /> : !houses.data?.length ? <EmptyState icon="house" title="Görüntüleyebileceğiniz kümes yok" /> : houses.data.map((h) => {
        const f = flocks.data?.find((x) => x.house_id === h.id);
        return (
          <Card key={h.id} onPress={() => nav.push(routes.house(h.id))} accessibilityLabel={`${h.name}, ${f ? 'aktif' : 'pasif'}`} style={{ paddingVertical: 14 }}>
            <Row gap={spacing.lg}>
              <Icon name="house" color={colors.text.secondary} size={46} strokeWidth={1.5} />
              <View style={{ flex: 1, gap: 2 }}>
                <Row justify="space-between"><Text variant="cardTitle" style={{ fontSize: 16 }}>{h.name}</Text>{f ? <Pill label="Aktif" tone="success" /> : <Pill label="Pasif" />}</Row>
                <Text variant="body">Kapasite: <Text variant="body" style={{ fontFamily: fontFamily.semibold }}>{fmtInt(h.capacity)}</Text></Text>
                {f ? (
                  <>
                    <Text variant="body">Kalan: <Text variant="body" style={{ fontFamily: fontFamily.semibold }}>{fmtInt(f.alive_count)}</Text> <Text variant="caption" muted>({f.age_day}. gün)</Text></Text>
                    <Text variant="body">Ölüm Oranı: <Text variant="body" style={{ fontFamily: fontFamily.semibold }}>{fmtPct(f.cumulative_mortality_pct)}</Text></Text>
                  </>
                ) : <Text variant="body" muted>Aktif üretim dönemi yok</Text>}
              </View>
              <Icon name="chevronRight" color={colors.text.secondary} />
            </Row>
          </Card>
        );
      })}
      {role === 'owner' ? <Button title="Kümes Ekle" icon="plus" variant="secondary" onPress={() => nav.push(routes.newHouse())} /> : null}
    </Screen>
  );
}
