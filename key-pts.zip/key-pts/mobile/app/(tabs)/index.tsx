// Çiftlik Sahibi Dashboard (referans ekran 2) + Kümes Bakıcısı ana ekranı
import React, { useMemo, useState } from 'react';
import { Pressable, RefreshControl, View } from 'react-native';
import { useActiveFlocks, useActiveOrg, useActivity, useAlertSettings, useFarm, useHouses, useNotifications, useProfileNames } from '../../src/api/queries';
import { KeyPTSLogoCompact } from '../../src/components/brand/Logo';
import { KpiTile, StatusPill } from '../../src/components/cards';
import { Icon } from '../../src/components/Icon';
import { useLayout } from '../../src/hooks/useLayout';
import { nav, routes } from '../../src/navigation/nav';
import { Card, Divider, EmptyState, ErrorState, Loading, Pill, Row, Screen, SectionHeader, SelectCard, SelectSheet, Text } from '../../src/components/ui';
import { houseStatus, useFarmSummary } from '../../src/features/dashboard/useFarmSummary';
import { formatDate, formatShortDate, formatTime, localDate } from '../../src/lib/dates';
import { errorMessage } from '../../src/lib/errors';
import { fmtInt, fmtKg, fmtNum, fmtPct } from '../../src/lib/format';
import { useSession } from '../../src/stores/session';
import { colors, fontFamily, spacing } from '../../src/theme';

export default function Home() {
  return <OwnerDashboard />;
}

const KIND: Record<string, string> = { mortality: 'ölüm', coal: 'kömür', medication: 'ilaç', weight: 'tartım', temperature: 'sıcaklık', note: 'not', movement: 'sürü hareketi' };

export function BellButton() {
  const n = useNotifications();
  const unread = n.data?.filter((x) => !x.read_at).length ?? 0;
  return (
    <Pressable onPress={() => nav.push(routes.notifications())} hitSlop={8} accessibilityLabel={`Bildirimler, ${unread} okunmamış`} style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
      <Icon name="bell" color="#fff" size={23} />
      {unread > 0 && (
        <View style={{ position: 'absolute', top: 4, right: 4, minWidth: 17, height: 17, borderRadius: 9, backgroundColor: colors.brand.orange, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3, borderWidth: 1.5, borderColor: colors.brand.navy }}>
          <Text style={{ fontSize: 9.5, fontFamily: fontFamily.bold }} color="#fff">{unread > 9 ? '9+' : unread}</Text>
        </View>
      )}
    </Pressable>
  );
}

function OwnerDashboard() {
  const { orgId, memberships } = useActiveOrg();
  const setActiveOrg = useSession((s) => s.setActiveOrg);
  const farm = useFarm();
  const houses = useHouses();
  const flocks = useActiveFlocks();
  const th = useAlertSettings(farm.data?.id ?? null);
  const act = useActivity({ orgId, limit: 6 });
  const names = useProfileNames();
  const [sel, setSel] = useState<string>('all');
  const [pick, setPick] = useState<'flock' | 'farm' | null>(null);
  const list = useMemo(() => (flocks.data ?? []).filter((f) => sel === 'all' || f.flock_id === sel), [flocks.data, sel]);
  const k = useFarmSummary(list);
  const chosen = sel === 'all' ? null : list[0];
  const today = localDate();
  const idle = (houses.data ?? []).filter((h) => !(flocks.data ?? []).some((f) => f.house_id === h.id));
  const missing = (flocks.data ?? []).filter((f) => !f.today_mortality_recorded);
  const refetch = () => { void flocks.refetch(); void houses.refetch(); void act.refetch(); };

  const flockTitle = chosen ? `Aktif Sürü: ${chosen.name}` : (flocks.data?.length ?? 0) === 1 ? `Aktif Sürü: ${flocks.data![0].name}` : `Aktif Sürüler: ${flocks.data?.length ?? 0} kümes`;
  const one = chosen ?? (flocks.data?.length === 1 ? flocks.data[0] : null);
  const placements = [...new Set((flocks.data ?? []).map((f) => f.placement_date))];
  const flockSub = one ? `(Başlangıç: ${formatDate(one.placement_date, { day: 'numeric', month: 'short', year: 'numeric' })} • Yaş: ${one.age_day}. gün)`
    : `(${placements.length === 1 ? `Başlangıç: ${formatDate(placements[0], { day: 'numeric', month: 'short', year: 'numeric' })} • ` : 'Farklı giriş tarihleri • '}Yaş: ${k.ageLabel})`;

  return (
    <Screen left={<KeyPTSLogoCompact height={30} />} right={<BellButton />}
      header={
        <View style={{ paddingHorizontal: 4, marginTop: 6, gap: 2 }}>
          <Text variant="bodyStrong" color="#fff" style={{ fontSize: 16 }}>Merhaba,</Text>
          <Text variant="display" color="#fff" style={{ fontSize: 22 }}>Çiftlik Genel Durumu</Text>
          {memberships.length > 1 && (
            <Pressable onPress={() => setPick('farm')} style={{ marginTop: 6, alignSelf: 'flex-start' }}><Pill label={`${farm.data?.name ?? 'Çiftlik'} · değiştir`} tone="orange" /></Pressable>
          )}
        </View>
      }
      overlap={flocks.data?.length ? <SelectCard elevated title={flockTitle} sub={flockSub} onPress={() => setPick('flock')} /> : undefined}
      refreshControl={<RefreshControl refreshing={flocks.isRefetching} onRefresh={refetch} tintColor={colors.brand.orange} />}>
      {flocks.isLoading ? <Loading /> : flocks.error && !flocks.data ? <ErrorState message={errorMessage(flocks.error)} onRetry={refetch} /> : (
        <>
          {!flocks.data?.length ? (
            <EmptyState icon="bird" title="Aktif üretim dönemi yok" body="Kümesler sekmesinden bir kümese civciv girişi yaparak dönemi başlatın." />
          ) : (
            <Row wrap gap={spacing.md} align="stretch">
              <KpiTile icon="bird" fg={colors.module.birds.fg} label="Toplam Mevcut Hayvan" value={`${fmtInt(k.alive)}`} sub={`Başlangıç ${fmtInt(k.initial)}`} />
              <KpiTile icon="mortality" fg={colors.status.danger} label="Bugünkü Ölüm" value={k.recordedCount ? `${fmtInt(k.todayDeaths)} baş` : 'Kayıt yok'}
                sub={k.recordedCount < k.count ? `${k.recordedCount}/${k.count} kümes girdi` : `Toplam ${fmtInt(k.totalDeaths)} (${fmtPct(k.cumPct)})`} subTone={k.recordedCount < k.count ? 'warning' : 'danger'} />
              <KpiTile icon="weight" fg={colors.module.weight.fg} label="Ort. Canlı Ağırlık" value={k.weight.avgG == null ? 'Tartım yok' : fmtKg(k.weight.avgG)}
                sub={k.weight.avgG == null ? 'Ölçüm girilmedi' : `Son tartım: ${k.weight.oldestDate === today ? 'Bugün' : formatShortDate(k.weight.oldestDate)}${k.weight.measured < k.weight.total ? ` · ${k.weight.measured}/${k.weight.total} kümes` : ''}`}
                subTone={k.weight.oldestDate && k.weight.oldestDate < today ? 'warning' : 'muted'} />
              <KpiTile icon="coal" fg={colors.status.info} label="Bugünkü Kömür" value={k.coalRecorded ? `${fmtNum(k.coalBags, 1)} torba` : 'Kayıt yok'}
                sub={k.coalRecorded ? (k.coalRecorded < k.coalHouses ? `${k.coalRecorded}/${k.coalHouses} kümes · ${fmtNum(k.coalKg, 0)} kg` : `(Bugün) · ${fmtNum(k.coalKg, 0)} kg`) : '(Bugün)'} subTone={k.coalRecorded < k.coalHouses ? 'warning' : 'muted'} />
            </Row>
          )}
          <Text variant="caption" muted>Veriler bu cihazda kayıtlı · son güncelleme {formatTime(new Date(flocks.dataUpdatedAt || Date.now()).toISOString())}</Text>
          {k.weight.avgG != null && k.weight.total > 1 && (
            <Text variant="caption" muted style={{ marginTop: -8 }}>Ortalama ağırlık: her kümesin son örneklem tartımı, kümes mevcuduna göre ağırlıklandırılmıştır.</Text>
          )}

          <SectionHeader title="Kümes Özeti" action="Tümünü Gör" onAction={() => nav.tab(routes.houses())} />
          <Card padded={false}>
            {(flocks.data ?? []).map((f, i) => {
              const s = houseStatus(f, th.data);
              return (
                <View key={f.flock_id}>
                  {i > 0 && <Divider inset={spacing.lg} />}
                  <Pressable onPress={() => nav.push(routes.house(f.house_id))} accessibilityRole="button"
                    style={({ pressed }) => ({ paddingHorizontal: spacing.lg, paddingVertical: 12, backgroundColor: pressed ? colors.surface.secondary : 'transparent' })}>
                    <Row gap={spacing.sm}>
                      <View style={{ flex: 1.1 }}>
                        <Text variant="cardTitle">{f.house_name}</Text>
                        <Text variant="caption" muted>{fmtInt(f.alive_count)} baş</Text>
                      </View>
                      <Text variant="label" style={{ flex: 1.3 }}>Ölüm: {fmtInt(f.total_deaths)} <Text variant="label" color={colors.status.danger}>({fmtPct(f.cumulative_mortality_pct)})</Text></Text>
                      <StatusPill status={s.status} />
                    </Row>
                    {s.reason && s.status !== 'normal' ? <Text variant="caption" color={s.status === 'critical' ? colors.status.danger : s.status === 'attention' ? colors.status.warning : colors.text.secondary} style={{ marginTop: 4 }}>{s.reason}</Text> : null}
                  </Pressable>
                </View>
              );
            })}
            {idle.map((h) => (
              <View key={h.id}>
                <Divider inset={spacing.lg} />
                <Pressable onPress={() => nav.push(routes.house(h.id))} style={{ paddingHorizontal: spacing.lg, paddingVertical: 12 }}>
                  <Row justify="space-between"><View><Text variant="cardTitle">{h.name}</Text><Text variant="caption" muted>Kapasite {fmtInt(h.capacity)}</Text></View><Pill label="Pasif" /></Row>
                </Pressable>
              </View>
            ))}
            {!houses.data?.length && <View style={{ padding: spacing.lg }}><Text muted>Henüz kümes yok.</Text></View>}
          </Card>

          <SectionHeader title="Son Kayıtlar" action="Tümü" onAction={() => nav.push(routes.activity())} />
          <Card padded={false}>
            {missing.length > 0 && (
              <View style={{ padding: spacing.md, paddingHorizontal: spacing.lg, backgroundColor: colors.status.warningSoft }}>
                <Text variant="label" color={colors.text.primary}><Text variant="label" style={{ fontFamily: fontFamily.bold }}>Eksik kayıt: </Text>{missing.map((f) => f.house_name).join(', ')} — bugün ölüm kaydı girilmedi.</Text>
              </View>
            )}
            {!act.data?.length ? <View style={{ padding: spacing.lg }}><Text muted>Henüz kayıt yok.</Text></View> : act.data.map((a, i) => (
              <View key={a.kind + a.id}>
                {i > 0 && <Divider inset={spacing.lg} />}
                <Row style={{ paddingHorizontal: spacing.lg, paddingVertical: 10 }} gap={spacing.md}>
                  <Text variant="caption" muted style={{ width: 42 }}>{formatTime(a.created_at)}</Text>
                  <View style={{ flex: 1 }}>
                    <Text variant="label" numberOfLines={1}><Text variant="label" style={{ fontFamily: fontFamily.semibold }}>{names.get(a.created_by) ?? 'Kullanıcı'}</Text> · {(flocks.data ?? []).find((f) => f.house_id === a.house_id)?.house_name ?? ''}</Text>
                    <Text variant="caption" muted numberOfLines={1}>{KIND[a.kind]}{a.value != null ? `: ${fmtNum(a.value, 2)}` : ''}{a.label ? ` · ${a.label}` : ''}{a.entry_date !== today ? ` · ${formatShortDate(a.entry_date)} tarihli` : ''}</Text>
                  </View>
                </Row>
              </View>
            ))}
          </Card>
        </>
      )}
      <SelectSheet visible={pick === 'flock'} title="Sürü seçin" value={sel} onClose={() => setPick(null)} onSelect={setSel}
        options={[{ value: 'all', label: 'Tüm aktif sürüler', sub: `${flocks.data?.length ?? 0} kümes · yaş ${ageRangeLabel(flocks.data ?? [])}` },
          ...(flocks.data ?? []).map((f) => ({ value: f.flock_id, label: `${f.house_name} · ${f.name}`, sub: `Başlangıç ${formatShortDate(f.placement_date)} · ${f.age_day}. gün` }))]} />
      <SelectSheet visible={pick === 'farm'} title="Çiftlik seçin" value={orgId} onClose={() => setPick(null)} onSelect={(v) => setActiveOrg(v)}
        options={memberships.map((m) => ({ value: m.org_id, label: m.organizations?.name ?? m.org_id }))} />
    </Screen>
  );
}

function ageRangeLabel(fl: { age_day: number }[]) {
  const a = [...new Set(fl.map((f) => f.age_day))].sort((x, y) => x - y);
  return !a.length ? '—' : a.length === 1 ? `${a[0]}. gün` : `${a[0]}–${a[a.length - 1]}. gün`;
}
