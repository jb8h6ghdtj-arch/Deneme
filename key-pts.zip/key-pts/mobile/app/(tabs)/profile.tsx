// Profil / Ayarlar — referans ekran 12
import Constants from 'expo-constants';
import { router } from 'expo-router';
import React from 'react';
import { View } from 'react-native';
import { useActiveOrg, useFarm, useHouses } from '../../src/api/queries';
import { RoosterMark } from '../../src/components/brand/Logo';
import { ListCard, ListRow } from '../../src/components/cards';
import { Card, Pill, Row, Screen, Text } from '../../src/components/ui';
import { nav, routes } from '../../src/navigation/nav';
import { useSignOut } from '../../src/features/auth/useSignOut';
import { useSession } from '../../src/stores/session';
import { colors } from '../../src/theme';

const ROLE: Record<string, string> = { owner: 'Çiftlik Sahibi', manager: 'Çiftlik Yöneticisi', worker: 'Kümes Bakıcısı' };

export default function Settings() {
  const user = useSession((s) => s.session?.user);
  const { role } = useActiveOrg();
  const farm = useFarm();
  const houses = useHouses();
  const signOut = useSignOut();
  const owner = role === 'owner', mgr = role !== 'worker';
  const cap = (houses.data ?? []).reduce((s, h) => s + h.capacity, 0);
  return (
    <Screen title="Ayarlar">
      <Card>
        <Row gap={14}>
          <View style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: colors.brand.navy, alignItems: 'center', justifyContent: 'center' }}><RoosterMark width={34} /></View>
          <View style={{ flex: 1 }}>
            <Text variant="cardTitle">{(user?.user_metadata?.full_name as string) ?? user?.email}</Text>
            <Text variant="caption" muted>{user?.email}</Text>
          </View>
          {role ? <Pill label={ROLE[role]} tone="orange" /> : null}
        </Row>
      </Card>
      <ListCard>
        {mgr ? <ListRow icon="farm" fg={colors.brand.navy} title="Çiftlik Bilgileri" subtitle={`(${houses.data?.length ?? 0} kümes, toplam kapasite ${cap.toLocaleString('tr-TR')})`} onPress={() => nav.push(routes.settings('farm'))} /> : null}
        {mgr ? <ListRow icon="medication" fg={colors.status.info} title="İlaç Listesi" subtitle="(Sık kullanılan ilaçlar)" onPress={() => nav.push(routes.settings('medications'))} /> : null}
        <ListRow icon="bird" fg={colors.brand.orange} title="Sürü Yönetimi" subtitle={mgr ? '(Yeni sürü başlat, geçmiş sürüler)' : '(Geçmiş sürüler)'} onPress={() => nav.push(routes.flockHistory())} />
        {mgr ? <ListRow icon="bell" fg={colors.brand.orange} title="Bildirim Ayarları" subtitle="(Ölüm, sıcaklık vb. uyarılar)" onPress={() => nav.push(routes.settings('alerts'))} /> : null}
        {owner ? <ListRow icon="flag" fg={colors.status.danger} title="Uyarı Eşikleri ve Hedefler" subtitle="(Ölüm eşikleri, sıcaklık ve ağırlık hedefleri)" onPress={() => nav.push(routes.settings('alerts'))} /> : null}
        <ListRow icon="backup" fg={colors.status.info} title="Veri Yönetimi" subtitle="Bu cihazda kayıtlı · dışa aktar, sıfırla" onPress={() => nav.push(routes.settings('backup'))} />
        {mgr ? <ListRow icon="backup" fg={colors.brand.navy} title="Veri Yedekleme" subtitle="(Dışa aktarma, yedekleme bilgisi)" onPress={() => nav.push(routes.settings('backup'))} /> : null}
        <ListRow icon="security" fg={colors.brand.navy} title="Güvenlik" subtitle="(Şifre, oturum)" onPress={() => nav.push(routes.settings('security'))} />
        <ListRow icon="logout" title="Çıkış Yap" danger onPress={() => void signOut()} />
      </ListCard>
      <Text variant="caption" muted style={{ textAlign: 'center' }}>KEY PTS · Poultry Tracking System · v{Constants.expoConfig?.version} · {farm.data?.name ?? ''}</Text>
    </Screen>
  );
}
