// "Kayıt Ekle" sekmesi: önce kümes seçilir, ardından o kümenin günlük kayıt formu açılır.
// Form ayrı bir yığın ekranıdır; kümes bağlamı rota parametresiyle (houseId) taşınır.
import React from 'react';
import { RefreshControl, View } from 'react-native';
import { useActiveFlocks, useHouses } from '../../src/api/queries';
import { Icon } from '../../src/components/Icon';
import { Card, EmptyState, IconBadge, Loading, Pill, Row, Screen, Text, Button } from '../../src/components/ui';
import { fmtInt } from '../../src/lib/format';
import { nav, routes } from '../../src/navigation/nav';
import { draftKey, isDirty, useDrafts } from '../../src/stores/drafts';
import { colors, spacing } from '../../src/theme';

export default function RecordTab() {
  const flocks = useActiveFlocks();
  const houses = useHouses();
  const drafts = useDrafts((s) => s.drafts);
  const idle = (houses.data ?? []).filter((h) => !(flocks.data ?? []).some((f) => f.house_id === h.id));
  return (
    <Screen title="Kayıt Ekle" refreshControl={<RefreshControl refreshing={flocks.isRefetching} onRefresh={() => { void flocks.refetch(); }} tintColor={colors.brand.orange} />}>
      <Text muted>Kayıt girmek istediğiniz kümesi seçin.</Text>
      {flocks.isLoading ? <Loading /> : !flocks.data?.length ? (
        <EmptyState icon="house" title="Aktif üretim dönemi olan kümes yok" body="Kayıt girebilmek için önce bir kümeste yeni sürü başlatın."
          action={<Button title="Yeni Sürü Başlat" icon="plus" compact onPress={() => nav.push(routes.newFlock())} />} />
      ) : flocks.data.map((f) => {
        const hasDraft = Object.entries(drafts).some(([k, d]) => k.includes(`|${f.house_id}|${f.flock_id}|`) && isDirty(d));
        return (
          <Card key={f.flock_id} onPress={() => nav.push(routes.dailyRecord(f.house_id))} accessibilityLabel={`${f.house_name} günlük kayıt`}>
            <Row gap={spacing.md}>
              <IconBadge name="house" fg={colors.brand.navy} bg={colors.surface.tertiary} size={46} iconSize={24} />
              <View style={{ flex: 1, gap: 2 }}>
                <Text variant="cardTitle">{f.house_name}</Text>
                <Text variant="label" muted>{f.name} · {f.age_day}. gün · {fmtInt(f.alive_count)} baş</Text>
                <Row wrap gap={6} style={{ marginTop: 4 }}>
                  {f.today_mortality_recorded ? <Pill label="Bugünkü ölüm girildi" tone="success" /> : <Pill label="Bugün kayıt yok" tone="warning" />}
                  {hasDraft ? <Pill label="Kaydedilmemiş taslak" tone="orange" /> : null}
                </Row>
              </View>
              <Icon name="chevronRight" color={colors.text.secondary} />
            </Row>
          </Card>
        );
      })}
      {idle.length > 0 && <Text variant="caption" muted>Aktif dönemi olmayan kümeler: {idle.map((h) => h.name).join(', ')}</Text>}
    </Screen>
  );
}

