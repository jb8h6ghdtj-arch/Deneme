// Raporlar — referans ekran 9: Genel / Kümes Bazlı / Sürü Performansı, sürü filtresi, 4 KPI, Günlük Ölüm Trendi, PDF/CSV
import { router } from 'expo-router';
import { nav, routes, type ModuleKind, type SingleEntryKind } from '../../src/navigation/nav';
import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { useActiveOrg, useAlertSettings, useAllFlocks, useFlocksDaily, useWeightTargets } from '../../src/api/queries';
import { TintedKpi } from '../../src/components/cards';
import { BarChart, TrendChart } from '../../src/components/charts/TrendChart';
import { Button, Card, Divider, EmptyState, Loading, Notice, Pill, PillTabs, Row, Screen, SectionHeader, SelectCard, SelectSheet, Text } from '../../src/components/ui';
import { addDays } from '../../src/domain/calculations';
import type { FlockDay, FlockOverview } from '../../src/domain/types';
import { comparisonReport, mortalityReport } from '../../src/features/reportBuilders';
import { formatDate, formatShortDate, localDate } from '../../src/lib/dates';
import { shareCsv, sharePdf, type Cell } from '../../src/lib/export';
import { fmtInt, fmtKg, fmtNum, fmtPct } from '../../src/lib/format';
import { colors, spacing } from '../../src/theme';

type Tab = 'general' | 'house' | 'performance';
type Range = 'day' | 'week' | 'cycle';

/** Seçili sürülerin günlük verisini yetiştirme gününe göre birleştirir (yalnız kayıtlı kümeler toplanır). */
function aggregateByAge(days: FlockDay[]) {
  const by = new Map<number, { deaths: number; start: number; recorded: number; total: number }>();
  days.forEach((d) => {
    const c = by.get(d.age_day) ?? { deaths: 0, start: 0, recorded: 0, total: 0 };
    c.total += 1;
    if (d.mortality_recorded) { c.deaths += d.deaths ?? 0; c.start += d.start_of_day_alive; c.recorded += 1; }
    by.set(d.age_day, c);
  });
  return [...by.entries()].sort((a, b) => a[0] - b[0]).map(([age, c]) => ({ age, ...c, pct: c.recorded ? (c.deaths / c.start) * 100 : null }));
}

export default function Reports() {
  const { orgId } = useActiveOrg();
  const all = useAllFlocks();
  const [tab, setTab] = useState<Tab>('general');
  const [range, setRange] = useState<Range>('cycle');
  const [sel, setSel] = useState<string>('active');
  const [pick, setPick] = useState(false);
  const active = (all.data ?? []).filter((f) => f.status === 'active');
  const flocks: FlockOverview[] = sel === 'active' ? active : (all.data ?? []).filter((f) => f.flock_id === sel);
  const ref = flocks[0];
  const end = ref?.status === 'active' ? localDate() : ref?.completed_at?.slice(0, 10) ?? localDate();
  const from = range === 'day' ? end : range === 'week' ? addDays(end, -6) : undefined;
  const daily = useFlocksDaily(flocks.map((f) => f.flock_id), from);
  const th = useAlertSettings(ref?.farm_id ?? null);
  const days = daily.data ?? [];

  const k = useMemo(() => {
    const deaths = days.reduce((s, d) => s + (d.deaths ?? 0), 0);
    const placed = flocks.reduce((s, f) => s + f.placed_total, 0);
    const bags = days.reduce((s, d) => s + Number(d.coal_bags ?? 0), 0);
    const kg = days.reduce((s, d) => s + Number(d.coal_kg ?? 0), 0);
    const meds = days.reduce((s, d) => s + d.med_count, 0);
    const missing = days.filter((d) => !d.mortality_recorded).length;
    const w = flocks.filter((f) => f.last_weight_g != null);
    const birds = w.reduce((s, f) => s + f.alive_count, 0);
    const avg = birds ? w.reduce((s, f) => s + Number(f.last_weight_g) * f.alive_count, 0) / birds : null;
    return { deaths, pct: placed ? (deaths / placed) * 100 : null, bags, kg, meds, missing, avg, weighed: w.length };
  }, [days, flocks]);
  const agg = useMemo(() => aggregateByAge(days), [days]);
  const sub = sel === 'active' ? `${active.length} aktif kümes` : `${ref?.house_name ?? ''} · ${ref?.status === 'active' ? 'aktif' : 'arşiv'}`;
  const rangeLabel = range === 'day' ? 'Günlük' : range === 'week' ? 'Haftalık (son 7 gün)' : 'Üretim dönemi';

  const exportReport = async (fmt: 'csv' | 'pdf') => {
    const r = mortalityReport(days);
    const houseOf = (d: FlockDay) => flocks.find((f) => f.flock_id === d.flock_id)?.house_name ?? '';
    const rows: Cell[][] = r.rows.map((row, i) => [houseOf(days[i]), ...row]);
    const headers = ['Kümes', ...r.headers];
    const title = `${rangeLabel} rapor — ${ref?.name ?? 'Sürü'}`;
    if (fmt === 'csv') return shareCsv(`keypts-${range}-rapor`, headers, rows);
    return sharePdf({ title, subtitle: `${sub} · ${from ? `${formatDate(from)} – ` : ''}${formatDate(end)}`, headers, rows,
      summary: [['Ölüm oranı', fmtPct(k.pct)], ['Toplam ölüm', fmtInt(k.deaths)], ['Kömür', `${fmtNum(k.bags, 1)} torba / ${fmtNum(k.kg, 0)} kg`], ['İlaç kaydı', fmtInt(k.meds)], ['Ort. ağırlık', fmtKg(k.avg)]],
      footnote: `"Kayıt yok" günleri sıfır sayılmamıştır (${k.missing} gün). Ağırlıklar örneklem tartımıdır ve kümes mevcuduna göre ağırlıklandırılmıştır.` });
  };

  return (
    <Screen title="Raporlar">
      <PillTabs value={tab} onChange={setTab} options={[{ value: 'general', label: 'Genel' }, { value: 'house', label: 'Kümes Bazlı' }, { value: 'performance', label: 'Sürü Performansı' }]} />
      <SelectCard title={sel === 'active' ? `Sürü: Tüm aktif sürüler` : `Sürü: ${ref?.name ?? ''} · ${ref?.house_name ?? ''}`} sub={sub} onPress={() => setPick(true)} />
      {all.isLoading || daily.isLoading ? <Loading /> : !flocks.length ? <EmptyState icon="chart" title="Raporlanacak veri yok" body="Aktif veya tamamlanmış bir üretim dönemi olduğunda raporlar burada görünür." /> : (
        <>
          {tab === 'general' && (
            <>
              <PillTabs value={range} onChange={setRange} options={[{ value: 'day', label: 'Günlük' }, { value: 'week', label: 'Haftalık' }, { value: 'cycle', label: 'Dönem' }]} />
              <Row wrap gap={spacing.md}>
                <TintedKpi icon="trend" fg={colors.status.danger} bg={colors.status.dangerSoft} label="Toplam Ölüm Oranı" value={fmtPct(k.pct)} sub={`${fmtInt(k.deaths)} baş`} />
                <TintedKpi icon="trend" fg="#5B4FC9" bg="#ECEEF8" label="Ort. Canlı Ağırlık" value={fmtKg(k.avg)} sub={k.weighed ? `${k.weighed}/${flocks.length} kümes` : 'Tartım yok'} />
                <TintedKpi icon="coal" fg={colors.brand.orange} bg={colors.brand.orangeSoft} label="Toplam Kömür" value={`${fmtNum(k.bags, 1)} torba`} sub={`${fmtNum(k.kg, 0)} kg`} />
                <TintedKpi icon="medication" fg="#1E9C8F" bg="#E2F3F5" label="İlaç Uygulama" value={`${fmtInt(k.meds)} kayıt`} />
              </Row>
              <Card style={{ gap: spacing.sm }}>
                <Text variant="cardTitle">Günlük Ölüm Trendi</Text>
                <TrendChart labels={agg.map((a) => String(a.age))} series={[{ name: 'Günlük ölüm %', values: agg.map((a) => a.pct) }]}
                  format={(n) => `%${fmtNum(n, 3)}`} tooltip={(i, v) => [`%${fmtNum(v, 2)}`, `(${agg[i].age}. gün)`]} />
                <Text variant="caption" muted>X ekseni: yetiştirme günü. Dokunarak değeri görün. {agg.some((a) => a.recorded < a.total) ? 'Bazı günlerde tüm kümeler kayıt girmedi; oran yalnız kayıtlı kümelerden hesaplanır.' : ''}</Text>
              </Card>
              {k.missing > 0 && <Notice tone="warning">{`${k.missing} kümes-gün için ölüm kaydı yok. Bu günler sıfır sayılmadı; toplamlar eksik olabilir.`}</Notice>}
              <Row gap={spacing.md}>
                <Button title="PDF Raporu" icon="file" variant="secondary" style={{ flex: 1 }} onPress={() => void exportReport('pdf')} />
                <Button title="CSV Raporu" icon="download" variant="secondary" style={{ flex: 1 }} onPress={() => void exportReport('csv')} />
              </Row>
            </>
          )}
          {tab === 'house' && <HouseBased flocks={flocks} days={days} thresholdsCritical={th.data?.daily_mortality_critical_pct} />}
          {tab === 'performance' && <Performance flocks={flocks} days={days} all={all.data ?? []} />}
        </>
      )}
      <SelectSheet visible={pick} title="Sürü seçin" value={sel} onClose={() => setPick(false)} onSelect={setSel}
        options={[{ value: 'active', label: 'Tüm aktif sürüler', sub: `${active.length} kümes` },
          ...(all.data ?? []).map((f) => ({ value: f.flock_id, label: `${f.house_name} · ${f.name}`, sub: `${f.status === 'active' ? 'Aktif' : 'Arşiv'} · ${formatShortDate(f.placement_date)} · ${f.age_day}. gün` }))]} />
    </Screen>
  );
}

function HouseBased({ flocks, days, thresholdsCritical }: { flocks: FlockOverview[]; days: FlockDay[]; thresholdsCritical?: number }) {
  const ages = [...new Set(days.map((d) => d.age_day))].sort((a, b) => a - b);
  const series = flocks.map((f) => {
    const m = new Map(days.filter((d) => d.flock_id === f.flock_id).map((d) => [d.age_day, d]));
    return { name: f.house_name, values: ages.map((a) => { const d = m.get(a); return d?.cumulative_mortality_pct == null ? null : Number(d.cumulative_mortality_pct); }), area: false };
  });
  const coal = flocks.map((f) => days.filter((d) => d.flock_id === f.flock_id).reduce((s, d) => s + Number(d.coal_bags ?? 0), 0));
  return (
    <>
      <Card padded={false}>
        <Row style={{ paddingHorizontal: spacing.lg, paddingVertical: 8, backgroundColor: colors.surface.tertiary }}>
          {['Kümes', 'Mevcut', 'Ölüm %', 'Kömür', 'Ağırlık'].map((h, i) => <Text key={h} variant="caption" muted style={{ flex: i ? 1 : 1.2, textAlign: i ? 'right' : 'left' }}>{h}</Text>)}
        </Row>
        {flocks.map((f, i) => (
          <View key={f.flock_id}>{i > 0 && <Divider />}
            <Row style={{ paddingHorizontal: spacing.lg, paddingVertical: 10 }}>
              <Text variant="bodyStrong" style={{ flex: 1.2 }}>{f.house_name}</Text>
              <Text variant="label" style={{ flex: 1, textAlign: 'right' }}>{fmtInt(f.alive_count)}</Text>
              <Text variant="label" style={{ flex: 1, textAlign: 'right' }} color={colors.status.danger}>{fmtPct(f.cumulative_mortality_pct)}</Text>
              <Text variant="label" style={{ flex: 1, textAlign: 'right' }}>{fmtNum(coal[i], 0)}</Text>
              <Text variant="label" style={{ flex: 1, textAlign: 'right' }}>{f.last_weight_g ? fmtKg(f.last_weight_g) : '—'}</Text>
            </Row>
          </View>
        ))}
      </Card>
      <Card style={{ gap: spacing.sm }}>
        <Text variant="cardTitle">Kümülatif Ölüm % — Kümesler Arası</Text>
        <TrendChart labels={ages.map(String)} series={series} format={(n) => `%${fmtNum(n, 2)}`} />
      </Card>
      <Card style={{ gap: spacing.sm }}>
        <Text variant="cardTitle">Kömür Tüketimi (torba)</Text>
        <BarChart labels={flocks.map((f) => f.house_name.replace('Kümes ', 'K'))} values={coal} />
      </Card>
      <Row gap={spacing.md}>
        <Button title="PDF" icon="file" variant="secondary" style={{ flex: 1 }} onPress={() => { const r = comparisonReport(flocks); void sharePdf({ title: 'Kümesler Arası Performans', subtitle: formatDate(localDate()), ...r }); }} />
        <Button title="CSV" icon="download" variant="secondary" style={{ flex: 1 }} onPress={() => { const r = comparisonReport(flocks); void shareCsv('kumes-karsilastirma', r.headers, r.rows); }} />
      </Row>
      {thresholdsCritical != null ? <Text variant="caption" muted>Kritik günlük ölüm eşiği: %{fmtNum(thresholdsCritical, 3)}</Text> : null}
    </>
  );
}

function Performance({ flocks, days, all }: { flocks: FlockOverview[]; days: FlockDay[]; all: FlockOverview[] }) {
  const wt = useWeightTargets(flocks[0]?.farm_id ?? null);
  const ages = [...new Set(days.map((d) => d.age_day))].sort((a, b) => a - b);
  const series = flocks.map((f) => {
    const m = new Map(days.filter((d) => d.flock_id === f.flock_id).map((d) => [d.age_day, d]));
    return { name: f.house_name, values: ages.map((a) => { const v = m.get(a)?.avg_weight_g; return v == null ? null : Number(v); }), area: false, connectGaps: true };
  });
  const target = wt.data?.length ? [{ name: 'Hedef', values: ages.map((a) => { const t = wt.data!.find((x) => x.age_day === a); return t ? Number(t.target_g) : null; }), dashed: true, color: colors.text.muted, connectGaps: true }] : [];
  const completed = all.filter((f) => f.status !== 'active');
  return (
    <>
      <Card style={{ gap: spacing.sm }}>
        <Text variant="cardTitle">Ağırlık Gelişimi (g) — ölçülen örneklemler</Text>
        <TrendChart labels={ages.map(String)} series={[...series, ...target]} format={(n) => fmtInt(n)} />
        <Text variant="caption" muted>Yalnız gerçek tartım günleri çizilir. Kesikli çizgi çiftliğin tanımladığı hedef eğridir (tanımlıysa).</Text>
      </Card>
      {flocks.filter((f) => f.status === 'active').map((f) => (
        <Card key={f.flock_id} style={{ gap: 4 }}>
          <Row justify="space-between"><Text variant="cardTitle">{f.house_name}</Text><Pill label={f.days_to_slaughter == null ? 'Kesim planı yok' : `Kesime ${f.days_to_slaughter} gün`} tone="orange" /></Row>
          <Text variant="label" muted>{f.age_day}. gün · son tartım {f.last_weight_g ? `${fmtKg(f.last_weight_g)} (${formatShortDate(f.last_weight_date)})` : 'yok'} · ölüm {fmtPct(f.cumulative_mortality_pct)}</Text>
        </Card>
      ))}
      <SectionHeader title="Dönem Kapanış Raporları" />
      {!completed.length ? <EmptyState title="Tamamlanmış dönem yok" /> : completed.map((f) => (
        <Card key={f.flock_id} onPress={() => nav.push(routes.house(f.house_id))} style={{ gap: 2 }}>
          <Row justify="space-between"><Text variant="cardTitle">{f.house_name} · {f.name}</Text><Pill label="Arşiv" /></Row>
          <Text variant="label" muted>{formatShortDate(f.placement_date)} – {formatShortDate(f.completed_at)} · {fmtInt(f.initial_count)} başlangıç · ölüm {fmtPct(f.cumulative_mortality_pct)}</Text>
        </Card>
      ))}
    </>
  );
}
