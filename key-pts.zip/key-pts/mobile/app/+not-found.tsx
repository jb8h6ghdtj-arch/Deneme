// Bilinmeyen adres / silinmiş kayda giden bağlantı: güvenli şekilde Ana Sayfa'ya döndürür
import React from 'react';
import { NotFoundScreen } from '../src/components/ui';
import { routes } from '../src/navigation/nav';

export default function NotFound() {
  return <NotFoundScreen title="Kayıt Bulunamadı" message="Aradığınız ekran veya kayıt bulunamadı. Silinmiş ya da taşınmış olabilir." backTo={routes.home()} backLabel="Ana Sayfa'ya Dön" />;
}
