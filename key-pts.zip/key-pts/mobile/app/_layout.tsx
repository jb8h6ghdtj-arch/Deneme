import '../src/i18n';
import { Inter_400Regular } from '@expo-google-fonts/inter/400Regular';
import { Inter_500Medium } from '@expo-google-fonts/inter/500Medium';
import { Inter_600SemiBold } from '@expo-google-fonts/inter/600SemiBold';
import { Inter_700Bold } from '@expo-google-fonts/inter/700Bold';
import { Inter_800ExtraBold } from '@expo-google-fonts/inter/800ExtraBold';
import { Inter_800ExtraBold_Italic } from '@expo-google-fonts/inter/800ExtraBold_Italic';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useFonts } from 'expo-font';
import { Stack, useSegments } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import React, { useEffect, useState } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useActiveOrg } from '../src/api/queries';
import { dataClient } from '../src/lib/data';
import { logError } from '../src/lib/log';
import { nav, routes } from '../src/navigation/nav';
import { hasAccount, initLocalData, isSampleData, onDataChange } from '../src/services/local/localClient';
import { useAppStatus } from '../src/stores/appStatus';
import { useDrafts } from '../src/stores/drafts';
import { useSession } from '../src/stores/session';
import { colors } from '../src/theme';

void SplashScreen.preventAutoHideAsync().catch(() => {});

// Veri cihazda: ağ yok, yeniden deneme gereksiz; her yazmadan sonra sorgular yenilenir.
const queryClient = new QueryClient({ defaultOptions: { queries: { staleTime: Infinity, retry: 0, networkMode: 'always' }, mutations: { networkMode: 'always' } } });

function AuthGate({ splashDone }: { splashDone: boolean }) {
  const { session, ready, setSession, setReady } = useSession();
  const { hasAccount: account } = useAppStatus();
  const segments = useSegments();
  const { orgId, loading } = useActiveOrg();

  useEffect(() => {
    void dataClient.auth.getSession().then(({ data }) => { setSession(data.session as never); setReady(); });
    const { data: sub } = dataClient.auth.onAuthStateChange((_e, s) => { setSession(s as never); useAppStatus.getState().set({ hasAccount: hasAccount() }); });
    return () => sub.subscription.unsubscribe();
  }, [setReady, setSession]);

  // Korumalı rota kapısı: hesap yoksa kurulum, oturum yoksa giriş, çiftlik yoksa kurulum
  useEffect(() => {
    if (!ready || !splashDone) return;
    const group = segments[0] as string | undefined;
    if (!account) { if (group !== 'onboarding') nav.resetTo('/onboarding'); return; }
    if (!session) { if (group !== '(auth)') nav.resetTo('/(auth)/sign-in'); return; }
    if (loading) return;
    if (!orgId) { if (group !== 'onboarding') nav.resetTo('/onboarding'); return; }
    if (!group || group === '(auth)' || group === 'onboarding') nav.resetTo(routes.home());
  }, [ready, splashDone, account, session, orgId, loading, segments]);
  return null;
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({ Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold, Inter_800ExtraBold, Inter_800ExtraBold_Italic });
  const [dataReady, setDataReady] = useState(false);
  const [splashDone, setSplashDone] = useState(false);
  useEffect(() => {
    initLocalData()
      .then(() => { useAppStatus.getState().set({ ready: true, sample: isSampleData(), hasAccount: hasAccount() }); useDrafts.getState().prune(); })
      .catch((e) => logError('initLocalData', e))
      .finally(() => setDataReady(true));
    return onDataChange(() => { useAppStatus.getState().set({ sample: isSampleData(), hasAccount: hasAccount() }); void queryClient.invalidateQueries(); });
  }, []);
  useEffect(() => { if (fontError) logError('fonts', fontError); }, [fontError]);
  const ready = (fontsLoaded || !!fontError) && dataReady;
  useEffect(() => {
    if (!ready) return;
    void SplashScreen.hideAsync().catch(() => {});
    const t = setTimeout(() => setSplashDone(true), 700);
    return () => clearTimeout(t);
  }, [ready]);
  if (!ready) return null;
  return (
    <SafeAreaProvider>
      <QueryClientProvider client={queryClient}>
        <AuthGate splashDone={splashDone} />
        <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.surface.secondary }, animation: 'slide_from_right', gestureEnabled: true, fullScreenGestureEnabled: true }}>
          <Stack.Screen name="index" options={{ animation: 'fade', gestureEnabled: false }} />
          <Stack.Screen name="(auth)" options={{ animation: 'fade', gestureEnabled: false }} />
          <Stack.Screen name="onboarding" options={{ animation: 'fade', gestureEnabled: false }} />
          <Stack.Screen name="(tabs)" options={{ animation: 'fade', gestureEnabled: false }} />
          <Stack.Screen name="record/medications" options={{ presentation: 'modal' }} />
        </Stack>
      </QueryClientProvider>
    </SafeAreaProvider>
  );
}
