// Çalışan işlem geçmişi: kim, hangi kümeye, ne zaman, hangi değeri girdi + düzeltmeler (eski → yeni)
import { useQuery } from '@tanstack/react-query';
import { useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { View } from 'react-native';
import { useActiveOrg, useActivity, useHouses, useProfileNames } from '../src/api/queries';
import { Button, Card, Divider, EmptyState, Loading, PillTabs, Row, Screen, Text } from '../src/components/ui';
import { activityReport } from '../src/features/reportBuilders';
import { formatDateTime, formatShortDate } from '../src/lib/dates';
import { shareCsv } from '../src/lib/export';
import { fmtNum } from '../src/lib/format';
import { dataClient } from '../src/lib/data';
import { spacing } from '../src/theme';

const KIND: Record<string, string> = { mortality: 'Ölüm', coal: 'Kömür', medication: 'İlaç', weight: 'Tartım', temperature: 'Sıcaklık', note: 'Not', movement: 'Sürü hareketi' };
const TABLE: Record<string, string> = { mortality_entries: 'Ölüm', coal_entries: 'Kömür', medication_applications: 'İlaç', weight_measurements: 'Tartım', temperature_measurements: 'Sıcaklık', daily_notes: 'Not', flocks: 'Dönem', houses: 'Kümes', flock_movements: 'Sürü hareketi', dispatch_records: 'Sevk' };

export default function Activity() {
  const { flockId } = useLocalSearchParams<{ flockId?: string }>();
  const { orgId } = useActiveOrg();
  const [view, setView] = useState<'entries' | 'changes'>('entries');
  const act = useActivity({ orgId, flockId, limit: 200 });
  const names = useProfileNames();
  const houses = new Map((useHouses().data ?? []).map((h) => [h.id, h.name]));
  const audit = useQuery({ queryKey: ['audit', orgId, flockId], enabled: !!orgId && view === 'changes', queryFn: async () => {
    let q = dataClient.from('audit_logs').select('*').eq('org_id', orgId!).eq('action', 'UPDATE').order('created_at', { ascending: false }).limit(100);
    if (flockId) q = q.eq('flock_id', flockId);
    const { data, error } = await q; if (error) throw error;
    return data as { id: number; table_name: string; actor_id: string; created_at: string; changed_fields: string[] | null; old_data: Record<string, unknown>; new_data: Record<string, unknown>; house_id: string | null }[];
  } });
  return (
    <Screen title="İşlem Geçmişi" back>
      <PillTabs value={view} onChange={setView} options={[{ value: 'entries', label: 'Kayıtlar' }, { value: 'changes', label: 'Düzeltmeler' }]} />
      {view === 'entries' ? (act.isLoading ? <Loading /> : !act.data?.length ? <EmptyState title="Kayıt yok" /> : (
        <>
          <Button title="CSV olarak dışa aktar" icon="download" variant="secondary" compact onPress={() => { const r = activityReport(act.data ?? [], names, houses); void shareCsv('islem-gecmisi', r.headers, r.rows); }} />
          <Card padded={false}>
            {act.data.map((a, i) => (
              <View key={a.kind + a.id}>{i > 0 && <Divider inset={spacing.lg} />}
                <View style={{ paddingHorizontal: spacing.lg, paddingVertical: 10 }}>
                  <Row justify="space-between"><Text variant="bodyStrong">{KIND[a.kind]} · {houses.get(a.house_id) ?? ''}{a.value != null ? ` · ${fmtNum(a.value, 2)}` : ''}</Text><Text variant="caption" muted>{formatShortDate(a.entry_date)}</Text></Row>
                  {a.label || a.note ? <Text variant="label" muted numberOfLines={2}>{[a.label, a.note].filter(Boolean).join(' — ')}</Text> : null}
                  <Text variant="caption" muted>{names.get(a.created_by) ?? 'Kullanıcı'} · gönderim {formatDateTime(a.created_at)}{a.version > 1 ? ' · düzeltildi' : ''}</Text>
                </View>
              </View>
            ))}
          </Card>
        </>
      )) : audit.isLoading ? <Loading /> : !audit.data?.length ? <EmptyState title="Düzeltme yok" body="Kayıtlarda yapılan değişiklikler eski ve yeni değerleriyle burada listelenir." /> : (
        <Card padded={false}>
          {audit.data.map((a, i) => (
            <View key={a.id}>{i > 0 && <Divider inset={spacing.lg} />}
              <View style={{ paddingHorizontal: spacing.lg, paddingVertical: 10, gap: 2 }}>
                <Text variant="bodyStrong">{TABLE[a.table_name] ?? a.table_name}{a.house_id ? ` · ${houses.get(a.house_id) ?? ''}` : ''}</Text>
                {(a.changed_fields ?? []).map((f) => <Text key={f} variant="label">{f}: {String(a.old_data?.[f] ?? '—')} → {String(a.new_data?.[f] ?? '—')}</Text>)}
                <Text variant="caption" muted>{names.get(a.actor_id) ?? 'Kullanıcı'} · {formatDateTime(a.created_at)}</Text>
              </View>
            </View>
          ))}
        </Card>
      )}
    </Screen>
  );
}
