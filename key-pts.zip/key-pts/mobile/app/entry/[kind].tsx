// Detaylı tekil kayıt: ölüm nedeni + fotoğraf, toplam örnek ağırlığıyla tartım, saat + nem ile sıcaklık, not.
import * as ImagePicker from 'expo-image-picker';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useCallback, useMemo, useState } from 'react';
import { Image, Pressable, View } from 'react-native';
import { storeEntryPhoto, useRecordEntry } from '../../src/api/mutations';
import { useActiveFlocks, useActiveOrg, useTemperatureTargets } from '../../src/api/queries';
import { Button, Card, DatePickerSheet, FramedField, Loading, NotFoundScreen, Notice, PillTabs, Row, Screen, StickyFooter, Text, TextField, Toast } from '../../src/components/ui';
import { averageWeightGrams, flockAgeDay, LIMITS } from '../../src/domain/calculations';
import { MORTALITY_CAUSES, type EntryKind, type WeightInputMode, type WeightUnit } from '../../src/domain/types';
import { formatDate, istanbulLocalToIso, localDate } from '../../src/lib/dates';
import { errorMessage } from '../../src/lib/errors';
import { fmtGram, fmtInt, fmtNum, parseDecimal } from '../../src/lib/format';
import { newId } from '../../src/lib/uuid';
import { nav, routes } from '../../src/navigation/nav';
import { colors, fontFamily, radius } from '../../src/theme';

const TITLE: Record<string, string> = { mortality: 'Ölüm Kaydı', coal: 'Kömür Kaydı', weight: 'Tartım Kaydı', temperature: 'Sıcaklık Kaydı', note: 'Günlük Not', medication: 'İlaç Kaydı' };
const CAUSE: Record<string, string> = { unknown: 'Belirsiz', weak_chick: 'Zayıf civciv', respiratory: 'Solunum', digestive: 'Sindirim', leg_problem: 'Bacak', heat_stress: 'Sıcak stresi', cold_stress: 'Soğuk stresi', crushing: 'Ezilme', predator: 'Yırtıcı', other: 'Diğer' };

export default function Entry() {
  const p = useLocalSearchParams<{ kind: string; houseId: string }>();
  const kind = (['mortality', 'coal', 'weight', 'temperature', 'note'].includes(p.kind) ? p.kind : 'note') as EntryKind;
  const flocks = useActiveFlocks();
  const f = flocks.data?.find((x) => x.house_id === p.houseId);
  const { orgId } = useActiveOrg();
  const targets = useTemperatureTargets(f?.farm_id ?? null);
  const save = useRecordEntry();
  const [clientId] = useState(() => newId());
  const today = localDate();
  const [date, setDate] = useState(today);
  const [sheet, setSheet] = useState(false);
  const [v, setV] = useState({ count: '', cause: null as string | null, bags: '', bagKg: '25', coalType: '', price: '', sample: '', value: '', temp: '', hum: '', time: new Intl.DateTimeFormat('tr-TR', { timeZone: 'Europe/Istanbul', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date()), note: '' });
  const [mode, setMode] = useState<WeightInputMode>('total');
  const [unit, setUnit] = useState<WeightUnit>('kg');
  const [photo, setPhoto] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [toast, setToast] = useState<{ m: string; t: 'success' | 'warning' | 'danger' } | null>(null);
  const hide = useCallback(() => setToast(null), []);
  const avg = useMemo(() => { const x = parseDecimal(v.value), s = parseInt(v.sample, 10); return x && s ? averageWeightGrams(x, unit, mode, s) : null; }, [v.value, v.sample, unit, mode]);
  if (flocks.isLoading) return <Screen title={TITLE[kind]} back><Loading /></Screen>;
  if (!f) return <NotFoundScreen title={TITLE[kind]} message="Bu kümeste aktif dönem bulunamadı." backTo={routes.houses()} backLabel="Kümeslere Dön" />;
  const age = flockAgeDay(f.placement_date, date, f.age_base);
  const target = targets.data?.find((t) => age >= t.day_from && age <= t.day_to);
  const set = (k: keyof typeof v) => (x: string) => setV({ ...v, [k]: x });

  const submit = async () => {
    setErr(null);
    let fields: Record<string, unknown> = {}; let label = '';
    const n = parseDecimal;
    if (kind === 'mortality') { const c = Number(v.count); if (!Number.isInteger(c) || c < 0 || v.count === '') return setErr('Ölen hayvan sayısını girin (yoksa 0).'); if (c > f.alive_count) return setErr(`Mevcut hayvan sayısını (${fmtInt(f.alive_count)}) aşamaz.`); fields = { count: c, cause: v.cause }; label = `${f.house_name}: ${c} ölüm`; }
    if (kind === 'coal') { const b = n(v.bags), kg = n(v.bagKg); if (b == null || b < 0 || !kg || kg > LIMITS.bagKgMax) return setErr('Torba sayısı ve ağırlığını kontrol edin.'); fields = { bag_count: b, bag_weight_kg: kg, coal_type: v.coalType.trim() || null, unit_price: n(v.price) }; label = `${f.house_name}: ${fmtNum(b, 1)} torba`; }
    if (kind === 'weight') { const s = parseInt(v.sample, 10); if (!s || !avg) return setErr('Örnek sayısı ve ağırlığı girin.'); if (avg < LIMITS.weightGramsMin || avg > LIMITS.weightGramsMax) return setErr(`Ortalama ${fmtGram(avg)} mantıksız; birimi ve giriş şeklini kontrol edin.`); fields = { sample_count: s, input_mode: mode, input_value: n(v.value), input_unit: unit, avg_weight_g: avg }; label = `${f.house_name}: tartım ${fmtGram(avg)}`; }
    if (kind === 'temperature') { const t = n(v.temp), h = v.hum ? n(v.hum) : null; if (t == null || t < LIMITS.tempMin || t > LIMITS.tempMax) return setErr('Sıcaklık -30–60 °C arası olmalı.'); if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(v.time)) return setErr('Saat SS:DD biçiminde olmalı.'); if (h != null && (h < 0 || h > 100)) return setErr('Nem 0–100 arası olmalı.'); fields = { temperature_c: t, humidity_pct: h, measured_at: istanbulLocalToIso(date, v.time) }; label = `${f.house_name}: ${fmtNum(t, 1)} °C`; }
    if (kind === 'note') { if (!v.note.trim()) return setErr('Not metnini girin.'); fields = { body: v.note.trim() }; label = `${f.house_name}: not`; }
    if (kind !== 'note') fields.note = v.note.trim() || null;
    setBusy(true);
    try {
      if (photo) fields.photo_path = await storeEntryPhoto(photo);
      const r = await save(kind, { flockId: f.flock_id, houseId: f.house_id, entryDate: date, clientId }, fields);
      if (r.status === 'failed') return setToast({ m: errorMessage(r.error), t: 'danger' });
      if (r.status === 'duplicate') return setToast({ m: 'Bu kayıt az önce eklendi.', t: 'warning' });
      setToast({ m: `✓ Başarıyla Kaydedildi · ${label}`, t: 'success' });
      setTimeout(() => nav.back(routes.house(f.house_id)), 1000);
    } catch (e) { setToast({ m: errorMessage(e), t: 'danger' }); } finally { setBusy(false); }
  };

  return (
    <Screen title={TITLE[kind]} back footer={<StickyFooter><Button title="Kaydet" icon="check" loading={busy} onPress={submit} /></StickyFooter>}>
      <Card style={{ gap: 12 }}>
        <FramedField label="Kümes" value={f.house_name} sub={f.name} disabled trailing="house" />
        <FramedField label="Tarih" value={formatDate(date, { day: 'numeric', month: 'short', year: 'numeric' })} sub={`(Sürü Yaşı: ${age}. gün)`} trailing="calendar" onPress={() => setSheet(true)} />
      </Card>
      <Card style={{ gap: 12 }}>
        {kind === 'mortality' && (<>
          <TextField label="Ölen hayvan sayısı (baş)" value={v.count} onChangeText={(x) => set('count')(x.replace(/\D/g, ''))} keyboardType="number-pad" hint="Ölüm yoksa 0 girin." />
          <Text variant="label" muted>Ölüm nedeni (isteğe bağlı)</Text>
          <Row wrap gap={6}>{MORTALITY_CAUSES.map((c) => <Pressable key={c} onPress={() => setV({ ...v, cause: v.cause === c ? null : c })} style={{ paddingHorizontal: 10, paddingVertical: 6, borderRadius: radius.pill, borderWidth: 1, borderColor: v.cause === c ? colors.brand.orange : colors.border.default, backgroundColor: v.cause === c ? colors.brand.orangeSoft : colors.surface.primary }}><Text variant="caption" color={v.cause === c ? colors.brand.orangeDark : colors.text.secondary} style={{ fontFamily: fontFamily.semibold }}>{CAUSE[c]}</Text></Pressable>)}</Row>
        </>)}
        {kind === 'coal' && (<>
          <TextField label="Torba sayısı" value={v.bags} onChangeText={set('bags')} keyboardType="decimal-pad" />
          <TextField label="Torba ağırlığı" value={v.bagKg} onChangeText={set('bagKg')} keyboardType="decimal-pad" suffix="kg" hint={parseDecimal(v.bags) ? `Toplam ${fmtNum((parseDecimal(v.bags) ?? 0) * (parseDecimal(v.bagKg) ?? 0), 1)} kg` : undefined} />
          <TextField label="Kömür türü (isteğe bağlı)" value={v.coalType} onChangeText={set('coalType')} />
          <TextField label="Torba birim fiyatı (isteğe bağlı)" value={v.price} onChangeText={set('price')} keyboardType="decimal-pad" suffix="₺" />
        </>)}
        {kind === 'weight' && (<>
          <Notice>Tartım örneklemdir; sürünün tamamının ölçümü değildir.</Notice>
          <TextField label="Tartılan örnek hayvan sayısı" value={v.sample} onChangeText={(x) => set('sample')(x.replace(/\D/g, ''))} keyboardType="number-pad" />
          <PillTabs value={mode} onChange={setMode} options={[{ value: 'total', label: 'Toplam örnek ağırlığı' }, { value: 'average', label: 'Ortalama ağırlık' }]} />
          <Row gap={8} align="flex-end"><View style={{ flex: 1 }}><TextField label={mode === 'total' ? 'Toplam ağırlık' : 'Ortalama ağırlık'} value={v.value} onChangeText={set('value')} keyboardType="decimal-pad" /></View>
            <View style={{ width: 110, paddingBottom: 4 }}><PillTabs value={unit} onChange={setUnit} options={[{ value: 'kg', label: 'kg' }, { value: 'g', label: 'g' }]} /></View></Row>
          {avg ? <Text variant="bodyStrong">Ortalama: {fmtGram(avg)}</Text> : null}
        </>)}
        {kind === 'temperature' && (<>
          <Notice>Manuel ölçüm. Sensör bağlı değilken canlı veri gösterilmez.</Notice>
          <Row gap={8}><View style={{ flex: 1 }}><TextField label="Saat" value={v.time} onChangeText={set('time')} keyboardType="numbers-and-punctuation" maxLength={5} /></View><View style={{ flex: 1 }}><TextField label="Sıcaklık" value={v.temp} onChangeText={set('temp')} keyboardType="decimal-pad" suffix="°C" /></View></Row>
          <TextField label="Nem (isteğe bağlı)" value={v.hum} onChangeText={set('hum')} keyboardType="decimal-pad" suffix="%" />
          {target ? <Notice tone={v.temp && (parseDecimal(v.temp)! < target.min_c || parseDecimal(v.temp)! > target.max_c) ? 'warning' : 'success'}>{`${age}. gün hedef aralık: ${fmtNum(target.min_c, 1)}–${fmtNum(target.max_c, 1)} °C`}</Notice> : <Notice>Bu yaş için hedef aralık tanımlı değil.</Notice>}
        </>)}
        <TextField label={kind === 'note' ? 'Gözlem / not' : 'Açıklama (isteğe bağlı)'} value={v.note} onChangeText={set('note')} multiline maxLength={kind === 'note' ? 4000 : 1000} />
        {(kind === 'mortality' || kind === 'note') && (photo
          ? <View style={{ gap: 6 }}><Image source={{ uri: photo }} style={{ width: '100%', height: 180, borderRadius: 10 }} /><Button title="Fotoğrafı kaldır" variant="ghost" compact onPress={() => setPhoto(null)} /></View>
          : <Button title="Fotoğraf ekle (isteğe bağlı)" variant="secondary" compact onPress={async () => {
              const perm = await ImagePicker.requestCameraPermissionsAsync();
              const r = perm.granted ? await ImagePicker.launchCameraAsync({ quality: 0.6 }) : await ImagePicker.launchImageLibraryAsync({ quality: 0.6, mediaTypes: ['images'] });
              if (!r.canceled) setPhoto(r.assets[0].uri);
            }} />)}
      </Card>
      {err && <Notice tone="danger">{err}</Notice>}
      <DatePickerSheet visible={sheet} value={date} min={f.placement_date} max={today} onSelect={setDate} onClose={() => setSheet(false)} />
      <Toast message={toast?.m ?? null} tone={toast?.t} onHide={hide} />
    </Screen>
  );
}
