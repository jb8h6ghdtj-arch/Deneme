// Dönem Kapatma: özet → sevk bilgileri → tutarsızlık kontrolü → arşiv
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { invalidateOperational, useFlock } from '../../src/api/queries';
import { StatBox } from '../../src/components/cards';
import { Button, Card, DatePickerSheet, FramedField, Loading, Notice, Row, Screen, StickyFooter, Text, TextField } from '../../src/components/ui';
import { formatDate, localDate } from '../../src/lib/dates';
import { errorMessage } from '../../src/lib/errors';
import { fmtInt, fmtNum, parseDecimal } from '../../src/lib/format';
import { dataClient } from '../../src/lib/data';
import { newId } from '../../src/lib/uuid';

interface Summary { initial_count: number; total_deaths: number; birds_in: number; birds_out: number; alive_unaccounted: number; coal_bags: number; coal_kg: number;
  medications: { product: string; applications: number; total: number; unit: string }[]; mortality_days_missing: number; days: number; discrepancy?: number; discrepancy_message?: string | null }

export default function CompleteFlock() {
  const qc = useQueryClient();
  const { flockId } = useLocalSearchParams<{ flockId: string }>();
  const flock = useFlock(flockId ?? null);
  const summary = useQuery({ queryKey: ['closingSummary', flockId], enabled: !!flockId,
    queryFn: async () => { const { data, error } = await dataClient.rpc('flock_closing_summary', { p_flock: flockId }); if (error) throw error; return data as Summary; } });
  const [clientId] = useState(newId);
  const [date, setDate] = useState(localDate());
  const [count, setCount] = useState<string | null>(null);
  const [weight, setWeight] = useState('');
  const [dest, setDest] = useState('');
  const [notes, setNotes] = useState('');
  const [confirm, setConfirm] = useState(false);
  const [sheet, setSheet] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Summary | null>(null);
  const alive = flock.data?.alive_count ?? 0;
  const n = parseInt(count ?? String(alive), 10) || 0;
  const avg = useMemo(() => { const w = parseDecimal(weight); return w && n ? w / n : null; }, [weight, n]);
  if (flock.isLoading || summary.isLoading || !flock.data) return <Screen title="Dönemi Tamamla" back><Loading /></Screen>;
  const s = result ?? summary.data;
  const submit = async () => {
    if (!confirm) return setConfirm(true);
    if (n <= 0) return setError('Kesime gönderilen hayvan sayısını girin.');
    setBusy(true); setError(null);
    const { data, error: e } = await dataClient.rpc('complete_flock', { p_flock: flockId, p_client_id: clientId, p_dispatch_date: date, p_bird_count: n,
      p_total_live_weight_kg: parseDecimal(weight), p_destination: dest.trim() || null, p_notes: notes.trim() || null });
    setBusy(false);
    if (e) return setError(errorMessage(e));
    setResult(data as Summary); invalidateOperational(qc);
  };
  return (
    <Screen title="Dönemi Tamamla" back footer={<StickyFooter>{result ? <Button title="Tamam" onPress={() => router.back()} /> :
      <Button title={confirm ? 'Onaylıyorum, dönemi kapat' : 'Dönemi Tamamla'} icon="flag" variant={confirm ? 'danger' : 'primary'} loading={busy} onPress={submit} />}</StickyFooter>}>
      <Card style={{ paddingVertical: 10 }}><Text variant="bodyStrong" style={{ textAlign: 'center' }}>{flock.data.house_name} · {flock.data.name} · {flock.data.age_day}. gün</Text></Card>
      {s && (
        <>
          <Row gap={8}>
            <StatBox label="Başlangıç" value={fmtInt(s.initial_count)} />
            <StatBox label="Toplam ölüm" value={fmtInt(s.total_deaths)} tone="danger" />
            <StatBox label="Diğer çıkış" value={fmtInt(s.birds_out)} />
          </Row>
          <Card style={{ gap: 6 }}>
            <Row justify="space-between"><Text muted>Toplam kömür</Text><Text variant="bodyStrong">{fmtNum(s.coal_bags, 1)} torba · {fmtNum(s.coal_kg, 0)} kg</Text></Row>
            <Row justify="space-between"><Text muted>Üretim süresi</Text><Text variant="bodyStrong">{s.days} gün</Text></Row>
            <Text muted>İlaç geçmişi</Text>
            {s.medications.length ? s.medications.map((m) => <Text key={m.product + m.unit} variant="label">• {m.product}: {m.applications} uygulama · {fmtNum(m.total, 2)} {m.unit}</Text>) : <Text variant="label">Kayıt yok</Text>}
          </Card>
          {s.mortality_days_missing > 0 && <Notice tone="warning">{`${s.mortality_days_missing} gün için ölüm kaydı yok. Kapanıştan sonra eklenemez.`}</Notice>}
        </>
      )}
      {result ? (
        <>
          <Notice tone="success">Dönem tamamlandı ve arşivlendi. Aynı kümeste yeni dönem başlatabilirsiniz.</Notice>
          {result.discrepancy ? <Notice tone="warning">{result.discrepancy_message ?? ''}</Notice> : <Notice tone="success">Kayıtlar başlangıç sayısıyla tutarlı.</Notice>}
        </>
      ) : (
        <Card style={{ gap: 14 }}>
          <FramedField label="Kesim / sevk tarihi" value={formatDate(date, { day: 'numeric', month: 'short', year: 'numeric' })} trailing="calendar" onPress={() => setSheet(true)} />
          <TextField label="Sevk edilen hayvan sayısı" value={count ?? String(alive)} onChangeText={(v) => setCount(v.replace(/\D/g, ''))} keyboardType="number-pad" hint={`Kayıtlara göre mevcut: ${fmtInt(alive)}`} />
          {alive - n !== 0 && <Notice tone="warning">{alive - n > 0 ? `Kayıtlara göre ${fmtInt(alive - n)} hayvan ölüm/çıkış/sevk ile açıklanamıyor.` : `Sevk sayısı kayıtlı mevcuttan ${fmtInt(n - alive)} fazla; sistem bunu kabul etmez.`}</Notice>}
          <TextField label="Toplam sevk edilen canlı ağırlık (isteğe bağlı)" value={weight} onChangeText={setWeight} keyboardType="decimal-pad" suffix="kg" hint={avg ? `Ortalama sevk ağırlığı: ${fmtNum(avg, 3)} kg` : undefined} />
          <TextField label="Sevk yeri (isteğe bağlı)" value={dest} onChangeText={setDest} />
          <TextField label="Kapanış notları (isteğe bağlı)" value={notes} onChangeText={setNotes} multiline />
          {confirm && <Notice tone="warning">Dönem kapandığında bu döneme yeni kayıt eklenemez. Tüm veriler arşivde korunur.</Notice>}
          {error && <Notice tone="danger">{error}</Notice>}
        </Card>
      )}
      <DatePickerSheet visible={sheet} value={date} min={flock.data.placement_date} max={localDate()} onSelect={setDate} onClose={() => setSheet(false)} />
    </Screen>
  );
}
