// Sürü Yönetimi / Geçmiş Üretim Dönemleri
import { router } from 'expo-router';
import { nav, routes, type ModuleKind, type SingleEntryKind } from '../../src/navigation/nav';
import React from 'react';
import { View } from 'react-native';
import { useActiveOrg, useAllFlocks, useHouses } from '../../src/api/queries';
import { Button, Card, EmptyState, Loading, Pill, Row, Screen, SectionHeader, Text } from '../../src/components/ui';
import { formatShortDate } from '../../src/lib/dates';
import { fmtInt, fmtPct } from '../../src/lib/format';

export default function FlockHistory() {
  const { role } = useActiveOrg();
  const houses = useHouses();
  const all = useAllFlocks();
  if (all.isLoading) return <Screen title="Sürü Yönetimi" back><Loading /></Screen>;
  const idle = (houses.data ?? []).filter((h) => !(all.data ?? []).some((f) => f.house_id === h.id && f.status === 'active'));
  return (
    <Screen title="Sürü Yönetimi" back>
      {role !== 'worker' && idle.length > 0 && (
        <>
          <SectionHeader title="Yeni sürü başlat" />
          {idle.map((h) => (
            <Card key={h.id} style={{ gap: 8 }}>
              <Row justify="space-between"><Text variant="cardTitle">{h.name}</Text><Pill label="Pasif" /></Row>
              <Button title="Civciv Girişi / Yeni Dönem" icon="plus" compact onPress={() => nav.push(routes.newFlock(h.id))} />
            </Card>
          ))}
        </>
      )}
      <SectionHeader title="Tüm üretim dönemleri" />
      {!all.data?.length ? <EmptyState title="Henüz üretim dönemi yok" /> : all.data.map((f) => (
        <Card key={f.flock_id} onPress={() => nav.push(routes.house(f.house_id))} style={{ gap: 2 }}>
          <Row justify="space-between"><Text variant="cardTitle">{f.house_name} · {f.cycle_no}. dönem</Text><Pill label={f.status === 'active' ? 'Aktif' : 'Arşiv'} tone={f.status === 'active' ? 'success' : 'neutral'} /></Row>
          <Text variant="label" muted>{f.name} · {formatShortDate(f.placement_date)} – {f.status === 'active' ? 'devam ediyor' : formatShortDate(f.completed_at)}</Text>
          <View><Text variant="label">{fmtInt(f.initial_count)} başlangıç · {fmtInt(f.total_deaths)} ölüm ({fmtPct(f.cumulative_mortality_pct)}) · {f.age_day}. gün</Text></View>
        </Card>
      ))}
    </Screen>
  );
}
