// Yeni üretim dönemi (sürü) başlatma
import { useQueryClient } from '@tanstack/react-query';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { invalidateOperational, useFarm, useHouses, useMembers } from '../../src/api/queries';
import { Button, Card, DatePickerSheet, FramedField, Notice, Screen, SelectSheet, StickyFooter, TextField } from '../../src/components/ui';
import { addDays, daysBetween } from '../../src/domain/calculations';
import { formatDate, localDate } from '../../src/lib/dates';
import { errorMessage } from '../../src/lib/errors';
import { fmtInt } from '../../src/lib/format';
import { dataClient } from '../../src/lib/data';

export default function NewFlock() {
  const qc = useQueryClient();
  const { houseId } = useLocalSearchParams<{ houseId: string }>();
  const houses = useHouses();
  const farm = useFarm();
  const members = useMembers();
  const [hid, setHid] = useState(houseId ?? null);
  const house = houses.data?.find((h) => h.id === hid);
  const today = localDate();
  const [placement, setPlacement] = useState(today);
  const [slaughter, setSlaughter] = useState(addDays(today, 45));
  const [count, setCount] = useState('');
  const [breed, setBreed] = useState('');
  const [name, setName] = useState(`Sürü #${today.slice(0, 4)}-${today.slice(5, 7)}`);
  const [resp, setResp] = useState<string | null>(null);
  const [desc, setDesc] = useState('');
  const [sheet, setSheet] = useState<'house' | 'placement' | 'slaughter' | 'resp' | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const n = parseInt(count, 10);
  const base = farm.data?.age_base ?? 0;

  const submit = async () => {
    if (!house) return setError('Kümes seçin.');
    if (!n || n <= 0) return setError('Başlangıç civciv sayısını girin.');
    setBusy(true); setError(null);
    const { error: e } = await dataClient.from('flocks').insert({ house_id: house.id, placement_date: placement, initial_count: n, breed: breed.trim() || null,
      expected_slaughter_date: slaughter, name: name.trim() || null, responsible_user_id: resp, description: desc.trim() || null } as never);
    setBusy(false);
    if (e) return setError(errorMessage(e));
    invalidateOperational(qc); router.back();
  };

  return (
    <Screen title="Yeni Sürü Başlat" back footer={<StickyFooter><Button title="Dönemi Başlat" icon="check" loading={busy} onPress={submit} /></StickyFooter>}>
      <Card style={{ gap: 14 }}>
        <FramedField label="Kümes" value={house?.name ?? 'Seçin'} sub={house ? `Kapasite ${fmtInt(house.capacity)}` : undefined} onPress={() => setSheet('house')} />
        <FramedField label="Civciv giriş tarihi" value={formatDate(placement, { day: 'numeric', month: 'short', year: 'numeric' })} sub={`(${base}. gün)`} trailing="calendar" onPress={() => setSheet('placement')} />
        <TextField label="Başlangıç civciv sayısı" value={count} onChangeText={(s) => setCount(s.replace(/\D/g, ''))} keyboardType="number-pad" suffix="baş" />
        {house && n > house.capacity ? <Notice tone="warning">{`Yerleştirilen sayı kümes kapasitesinin (${fmtInt(house.capacity)}) üzerinde.`}</Notice> : null}
        <FramedField label="Beklenen kesim tarihi" value={formatDate(slaughter, { day: 'numeric', month: 'short', year: 'numeric' })} sub={`(${daysBetween(placement, slaughter) + base}. gün)`} trailing="calendar" onPress={() => setSheet('slaughter')} />
        <TextField label="Dönem adı / numarası" value={name} onChangeText={setName} />
        <TextField label="Civciv türü / genetiği (isteğe bağlı)" value={breed} onChangeText={setBreed} placeholder="Ör. Ross 308" />
        <FramedField label="Sorumlu çalışan (isteğe bağlı)" value={members.data?.find((m) => m.user_id === resp)?.profiles?.full_name ?? 'Seçilmedi'} onPress={() => setSheet('resp')} />
        <TextField label="Açıklama (isteğe bağlı)" value={desc} onChangeText={setDesc} multiline />
      </Card>
      <Notice>Süre sabit değildir; kesim tarihini dönem boyunca Sürü Takvimi ekranından değiştirebilirsiniz.</Notice>
      {error && <Notice tone="danger">{error}</Notice>}
      <SelectSheet visible={sheet === 'house'} title="Kümes" value={hid} onClose={() => setSheet(null)} onSelect={setHid} options={(houses.data ?? []).map((h) => ({ value: h.id, label: h.name, sub: `Kapasite ${fmtInt(h.capacity)}` }))} />
      <SelectSheet visible={sheet === 'resp'} title="Sorumlu çalışan" value={resp} onClose={() => setSheet(null)} onSelect={setResp} options={(members.data ?? []).map((m) => ({ value: m.user_id, label: m.profiles?.full_name ?? 'Kullanıcı' }))} />
      <DatePickerSheet visible={sheet === 'placement'} value={placement} max={today} min={addDays(today, -60)} onSelect={(d) => { setPlacement(d); if (slaughter <= d) setSlaughter(addDays(d, 45)); }} onClose={() => setSheet(null)} />
      <DatePickerSheet visible={sheet === 'slaughter'} value={slaughter} min={addDays(placement, 1)} max={addDays(placement, 120)} onSelect={setSlaughter} onClose={() => setSheet(null)} />
    </Screen>
  );
}
