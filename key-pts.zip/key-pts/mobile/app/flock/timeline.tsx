// Sürü Takvimi — referans ekran 10: dikey zaman çizelgesi; aktif gün turuncu. Kesim planı değiştirilebilir.
import { useQueryClient } from '@tanstack/react-query';
import { useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { invalidateOperational, useActiveFlocks, useActiveOrg, useFlock } from '../../src/api/queries';
import { RoosterMark } from '../../src/components/brand/Logo';
import { Icon, type IconName } from '../../src/components/Icon';
import { Button, DatePickerSheet, Loading, Notice, Row, Screen, SelectCard, SelectSheet, Text } from '../../src/components/ui';
import { addDays, broilerStartAge, dateForAge, flockAgeDay } from '../../src/domain/calculations';
import { formatDate, localDate } from '../../src/lib/dates';
import { errorMessage } from '../../src/lib/errors';
import { fmtInt, fmtKg } from '../../src/lib/format';
import { dataClient } from '../../src/lib/data';
import { colors, fontFamily, radius, spacing } from '../../src/theme';

interface Step { key: string; icon: IconName; fg: string; bg: string; title: string; body: string; active?: boolean; done?: boolean }

export default function Timeline() {
  const params = useLocalSearchParams<{ flockId?: string }>();
  const qc = useQueryClient();
  const active = useActiveFlocks();
  const { role } = useActiveOrg();
  const [flockId, setFlockId] = useState<string | null>(params.flockId ?? null);
  useEffect(() => { if (!flockId && active.data?.length) setFlockId(active.data[0].flock_id); }, [active.data, flockId]);
  const q = useFlock(flockId);
  const f = q.data;
  const [pick, setPick] = useState<'flock' | 'date' | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!f) return <Screen title="Sürü Takvimi" back><Loading /></Screen>;
  const today = localDate();
  const base = f.age_base;
  const bAge = broilerStartAge(f.chick_phase_days, base);
  const sAge = f.expected_slaughter_date ? flockAgeDay(f.placement_date, f.expected_slaughter_date, base) : null;
  const m = colors.module;
  const steps: Step[] = ([
    { key: 'in', icon: 'bird', fg: m.birds.fg, bg: m.birds.bg, title: `${base}. Gün – ${formatDate(f.placement_date, { day: 'numeric', month: 'short', year: 'numeric' })}`, body: `Civciv Girişi (${fmtInt(f.initial_count)} baş)`, done: true },
    { key: 'broiler', icon: 'medication', fg: colors.status.info, bg: colors.status.infoSoft, title: `${bAge}. Gün – ${formatDate(dateForAge(f.placement_date, bAge, base), { day: 'numeric', month: 'short' })}`, body: 'Piliç Dönemi Başlangıcı (yönetim sınıflandırması)', done: f.age_day >= bAge },
    ...(f.status === 'active' ? [{ key: 'now', icon: 'calendar' as IconName, fg: colors.brand.orange, bg: '#FFE2CC', title: `${f.age_day}. Gün – Bugün`, body: `Mevcut Gün${f.last_weight_g ? ` (son tartım ${fmtKg(f.last_weight_g)})` : ''} · ${fmtInt(f.alive_count)} baş`, active: true }] : []),
    ...(f.withdrawal_end_date ? [{ key: 'wd', icon: 'clock' as IconName, fg: f.withdrawal_conflict ? colors.status.danger : colors.text.secondary, bg: f.withdrawal_conflict ? colors.status.dangerSoft : colors.surface.tertiary,
      title: `${flockAgeDay(f.placement_date, f.withdrawal_end_date, base)}. Gün – ${formatDate(f.withdrawal_end_date, { day: 'numeric', month: 'short' })}`, body: `İlaç bekleme süresi sonu${f.withdrawal_conflict ? ' · kesim planıyla çakışıyor' : ''}`, done: f.withdrawal_end_date < today }] : []),
    { key: 'slaughter', icon: 'flag', fg: colors.brand.orange, bg: colors.brand.orangeSoft,
      title: sAge != null ? `${sAge}. Gün – ${formatDate(f.expected_slaughter_date, { day: 'numeric', month: 'short', year: 'numeric' })}` : 'Kesim planı yok',
      body: f.status !== 'active' ? `Dönem tamamlandı (${formatDate(f.completed_at)})` : sAge != null ? `Planlanan Kesim · ${f.days_to_slaughter! >= 0 ? `${f.days_to_slaughter} gün kaldı` : 'tarih geçti'}` : 'Kesim tarihi belirlenmedi', done: f.status !== 'active' },
  ] as Step[]).sort((a, b) => parseInt(a.title, 10) - parseInt(b.title, 10));

  const setSlaughter = async (d: string) => {
    setError(null);
    const { error: e } = await dataClient.from('flocks').update({ expected_slaughter_date: d } as never).eq('id', f.flock_id);
    if (e) return setError(errorMessage(e));
    invalidateOperational(qc); void q.refetch();
  };

  return (
    <Screen title="Sürü Takvimi" back>
      <SelectCard title={`${f.name} · ${f.house_name}`} onPress={() => setPick('flock')} />
      <View>
        {steps.map((s, i) => (
          <View key={s.key} style={{ flexDirection: 'row', gap: spacing.md }}>
            <View style={{ alignItems: 'center', width: 50 }}>
              <View style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: s.bg, alignItems: 'center', justifyContent: 'center', marginTop: 6 }}>
                <Icon name={s.icon} color={s.fg} size={24} strokeWidth={2.2} />
              </View>
              {i < steps.length - 1 ? <View style={{ flex: 1, width: 2, backgroundColor: colors.border.strong, marginVertical: 2 }} /> : null}
            </View>
            <View style={{ flex: 1, paddingVertical: 10, paddingHorizontal: spacing.md, marginBottom: spacing.sm, borderRadius: radius.card, backgroundColor: s.active ? colors.brand.orangeSoft : 'transparent' }}>
              <Text variant="cardTitle" style={{ fontFamily: fontFamily.bold }}>{s.title}</Text>
              <Text variant="body" color={s.active ? colors.text.primary : colors.text.secondary}>{s.body}</Text>
            </View>
          </View>
        ))}
      </View>
      {f.status === 'active' && role !== 'worker' ? <Button title="Kesim Planını Değiştir" icon="calendar" variant="secondary" onPress={() => setPick('date')} /> : null}
      {error ? <Notice tone="danger">{error}</Notice> : null}
      <Text variant="caption" muted>Zaman çizelgesi dönemin gerçek giriş tarihinden ve planlanan kesim tarihinden hesaplanır. Gün standardı: giriş günü = {base}. gün.</Text>
      <View style={{ alignItems: 'flex-end', opacity: 0.12, marginTop: -10 }} pointerEvents="none"><RoosterMark width={150} /></View>
      <SelectSheet visible={pick === 'flock'} title="Sürü seçin" value={flockId} onClose={() => setPick(null)} onSelect={setFlockId}
        options={(active.data ?? []).map((x) => ({ value: x.flock_id, label: `${x.house_name} · ${x.name}`, sub: `${x.age_day}. gün` }))} />
      <DatePickerSheet visible={pick === 'date'} title="Planlanan kesim tarihi" value={f.expected_slaughter_date ?? addDays(f.placement_date, 45)} min={today} max={addDays(f.placement_date, 120)}
        onSelect={(d) => void setSlaughter(d)} onClose={() => setPick(null)} dayLabel={(d) => `${flockAgeDay(f.placement_date, d, base)}.g`} />
    </Screen>
  );
}
