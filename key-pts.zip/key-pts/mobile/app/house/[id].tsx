// Kümes Detayı — referans: lacivert başlık, sürü/yaş şeridi, 3'lü özet, Günlük Özet / Sürü Grafiği / Kayıt Geçmişi
import { router, useLocalSearchParams } from 'expo-router';
import { nav, routes, type ModuleKind, type SingleEntryKind } from '../../src/navigation/nav';
import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, RefreshControl, View } from 'react-native';
import { useActiveOrg, useActivity, useAlertSettings, useEntries, useFlockDaily, useFlockHistory, useHouses, useProfileNames, useWeightTargets } from '../../src/api/queries';
import { ListCard, ListRow, StatBox } from '../../src/components/cards';
import { BarChart, TrendChart } from '../../src/components/charts/TrendChart';
import { Button, Card, Divider, EmptyState, ErrorState, Loading, NotFoundScreen, Notice, Pill, Row, Screen, SectionHeader, SelectSheet, StickyFooter, Text, UnderlineTabs } from '../../src/components/ui';
import { addDays, flockPhase } from '../../src/domain/calculations';
import type { FlockDay, FlockOverview } from '../../src/domain/types';
import { formatDate, formatShortDate, formatTime, localDate } from '../../src/lib/dates';
import { errorMessage } from '../../src/lib/errors';
import { fmtInt, fmtKg, fmtNum, fmtPct } from '../../src/lib/format';
import { colors, spacing } from '../../src/theme';

type Tab = 'summary' | 'chart' | 'history';

export default function HouseDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const houses = useHouses();
  const house = houses.data?.find((h) => h.id === id);
  const history = useFlockHistory(id ?? null);
  const { role } = useActiveOrg();
  const [flockId, setFlockId] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('summary');
  const [pick, setPick] = useState(false);
  useEffect(() => { if (!flockId && history.data?.length) setFlockId((history.data.find((f) => f.status === 'active') ?? history.data[0]).flock_id); }, [history.data, flockId]);
  const flock = history.data?.find((f) => f.flock_id === flockId) ?? null;
  const daily = useFlockDaily(flockId);
  const refresh = () => { void history.refetch(); void daily.refetch(); };

  if (!houses.isLoading && !house) return <NotFoundScreen title="Kümes" message="Bu kümes bulunamadı. Silinmiş veya adres hatalı olabilir." backTo={routes.houses()} backLabel="Kümeslere Dön" />;
  if (history.isLoading || houses.isLoading) return <Screen title={house?.name ?? 'Kümes'} back><Loading /></Screen>;
  if (history.error) return <Screen title={house?.name ?? 'Kümes'} back><ErrorState message={errorMessage(history.error)} onRetry={refresh} /></Screen>;
  if (!flock) {
    return (
      <Screen title={house?.name ?? 'Kümes'} back>
        <EmptyState icon="bird" title="Bu kümeste üretim dönemi yok" body={`Kapasite: ${fmtInt(house?.capacity)} baş. Civciv girişiyle yeni dönem başlatın.`}
          action={role !== 'worker' ? <Button title="Yeni Sürü Başlat" icon="plus" onPress={() => nav.push(routes.newFlock(id))} /> : undefined} />
      </Screen>
    );
  }
  const phase = flockPhase(flock.age_day, flock.chick_phase_days, flock.age_base);
  const active = flock.status === 'active';

  return (
    <Screen title={flock.house_name} back
      refreshControl={<RefreshControl refreshing={daily.isRefetching} onRefresh={refresh} tintColor={colors.brand.orange} />}
      footer={active ? <StickyFooter><Button title="Günlük Kayıt Ekle" icon="plus" onPress={() => nav.push(routes.dailyRecord(flock.house_id))} /></StickyFooter> : undefined}>
      <Pressable onPress={() => (history.data!.length > 1 ? setPick(true) : undefined)} accessibilityRole="button" accessibilityLabel="Üretim dönemi seçimi"
        style={{ backgroundColor: colors.surface.tertiary, borderRadius: 10, paddingVertical: 9, paddingHorizontal: 12 }}>
        <Row justify="center" gap={10}>
          <Text variant="bodyStrong">{flock.name}</Text>
          <Text muted>|</Text>
          <Text variant="bodyStrong">Yaş: {flock.age_day}. gün</Text>
          {history.data!.length > 1 ? <Text variant="caption" color={colors.text.link}>▾</Text> : null}
        </Row>
        <Row justify="center" gap={6} style={{ marginTop: 4 }}>
          <Pill label={phase === 'chick' ? 'Civciv dönemi' : 'Piliç dönemi'} tone={phase === 'chick' ? 'info' : 'orange'} />
          {!active ? <Pill label="Arşiv · tamamlandı" /> : flock.days_to_slaughter != null ? <Pill label={flock.days_to_slaughter >= 0 ? `Kesime ${flock.days_to_slaughter} gün` : 'Kesim tarihi geçti'} tone={flock.days_to_slaughter <= 3 ? 'warning' : 'neutral'} /> : null}
        </Row>
      </Pressable>

      <Row gap={spacing.sm}>
        <StatBox label="Başlangıç" value={fmtInt(flock.initial_count)} />
        <StatBox label="Toplam Ölüm" value={fmtInt(flock.total_deaths)} sub={`(${fmtPct(flock.cumulative_mortality_pct)})`} tone="danger" />
        <StatBox label={active ? 'Kalan' : 'Kayıtlı kalan'} value={fmtInt(flock.alive_count)} tone="success" />
      </Row>

      {flock.withdrawal_conflict && active && <Notice tone="danger" icon="medication">{`İlaç bekleme süresi (${formatDate(flock.withdrawal_end_date)}) planlanan kesim tarihiyle (${formatDate(flock.expected_slaughter_date)}) çakışıyor. Veterinerinize danışın.`}</Notice>}

      <UnderlineTabs value={tab} onChange={setTab} options={[{ value: 'summary', label: 'Günlük Özet' }, { value: 'chart', label: 'Sürü Grafiği' }, { value: 'history', label: 'Kayıt Geçmişi' }]} />

      {daily.isLoading ? <Loading /> : daily.error ? <ErrorState message={errorMessage(daily.error)} onRetry={refresh} /> : (
        <>
          {tab === 'summary' && <DailySummary flock={flock} days={daily.data ?? []} role={role} />}
          {tab === 'chart' && <FlockCharts flock={flock} days={daily.data ?? []} />}
          {tab === 'history' && <RecordHistory flock={flock} />}
        </>
      )}
      <SelectSheet visible={pick} title="Üretim dönemi" value={flockId} onClose={() => setPick(false)} onSelect={setFlockId}
        options={history.data!.map((f) => ({ value: f.flock_id, label: `${f.cycle_no}. dönem · ${f.name}`, sub: `${formatShortDate(f.placement_date)} – ${f.status === 'active' ? 'devam ediyor' : formatShortDate(f.completed_at)}` }))} />
    </Screen>
  );
}

function DailySummary({ flock, days, role }: { flock: FlockOverview; days: FlockDay[]; role: string | null }) {
  const last = days[days.length - 1]?.day ?? localDate();
  const [day, setDay] = useState(last);
  useEffect(() => setDay(last), [last]);
  const d = days.find((x) => x.day === day);
  const isToday = day === localDate();
  const weights = useEntries<{ id: string; entry_date: string; created_at: string; avg_weight_g: number }>('weight_measurements', flock.flock_id);
  const temps = useEntries<{ id: string; entry_date: string; measured_at: string; temperature_c: number }>('temperature_measurements', flock.flock_id, 'measured_at');
  const lw = weights.data?.find((w) => w.entry_date <= day);
  const lt = temps.data?.find((t) => t.entry_date <= day);
  const when = (date: string, iso: string) => `${date === localDate() ? 'Bugün' : formatShortDate(date)} ${formatTime(iso)}`;
  const go = (kind: string) => nav.push(routes.module(kind as ModuleKind, flock.flock_id));
  const m = colors.module;
  const canPrev = day > flock.placement_date, canNext = day < last;

  return (
    <>
      <Row justify="space-between">
        <Text variant="section">{isToday ? 'Bugünün Kayıtları' : formatDate(day, { day: 'numeric', month: 'long' })} ({d?.age_day ?? '—'}. Gün)</Text>
        <Row gap={4}>
          <Pressable disabled={!canPrev} onPress={() => setDay(addDays(day, -1))} hitSlop={8} accessibilityLabel="Önceki gün" style={{ padding: 6 }}><Text variant="section" color={canPrev ? colors.brand.navy : colors.border.strong}>‹</Text></Pressable>
          <Pressable disabled={!canNext} onPress={() => setDay(addDays(day, 1))} hitSlop={8} accessibilityLabel="Sonraki gün" style={{ padding: 6 }}><Text variant="section" color={canNext ? colors.brand.navy : colors.border.strong}>›</Text></Pressable>
        </Row>
      </Row>
      <ListCard>
        <ListRow icon="heart" fg={m.mortality.fg} bg={m.mortality.bg} title="Günlük Ölüm" subtitle={d?.mortality_recorded ? `Kümülatif ${fmtInt(d.cumulative_deaths)} · günlük ${fmtPct(d.daily_mortality_pct, 3)}` : 'Kayıt girilmedi (sıfır sayılmaz)'}
          value={d?.mortality_recorded ? `${fmtInt(d.deaths)} baş` : 'Kayıt yok'} onPress={() => go('mortality')} />
        {flock.coal_tracking ? <ListRow icon="coal" fg={m.coal.fg} bg={m.coal.bg} title="Kömür Kullanımı" subtitle={d?.coal_kg != null ? `${fmtNum(d.coal_kg, 0)} kg` : undefined}
          value={d?.coal_bags != null ? `${fmtNum(d.coal_bags, 1)} torba` : 'Kayıt yok'} onPress={() => go('coal')} /> : null}
        <ListRow icon="medication" fg={m.medication.fg} bg={m.medication.bg} title="Uygulanan İlaçlar" value={d?.med_count ? `${d.med_count} adet` : 'Kayıt yok'} onPress={() => go('medication')} />
        <ListRow icon="weight" fg={m.weight.fg} bg={m.weight.bg} title="Ort. Canlı Ağırlık" subtitle={lw ? `Son tartım: ${when(lw.entry_date, lw.created_at)} · örneklem` : undefined}
          value={lw ? fmtKg(lw.avg_weight_g) : 'Kayıt yok'} onPress={() => go('weight')} />
        <ListRow icon="temperature" fg={m.temperature.fg} bg={m.temperature.bg} title="Kümes İçi Sıcaklık" subtitle={lt ? `Son ölçüm: ${when(lt.entry_date, lt.measured_at)} · manuel` : undefined}
          value={lt ? `${fmtNum(lt.temperature_c, 1)} °C` : 'Kayıt yok'} onPress={() => go('temperature')} />
        <ListRow icon="note" fg={m.note.fg} bg={m.note.bg} title="Günlük Notlar" value={d?.note_count ? `${d.note_count} not` : 'Kayıt yok'} onPress={() => go('note')} />
      </ListCard>
      <SectionHeader title="Sürü Yönetimi" />
      <ListCard>
        <ListRow icon="calendar" fg={m.timeline.fg} bg={m.timeline.bg} title="Sürü Takvimi" subtitle="Giriş, piliç dönemi, mevcut gün, kesim planı" onPress={() => nav.push(routes.timeline(flock.flock_id))} />
        <ListRow icon="mortality" fg={m.mortality.fg} bg={m.mortality.bg} title="Ölüm Takvimi" subtitle="Takvim, tablo ve grafik" onPress={() => go('mortality')} />
        {flock.status === 'active' && role !== 'worker' ? <ListRow icon="flag" fg={colors.brand.navy} bg={colors.surface.tertiary} title="Dönemi Tamamla" subtitle="Kesim/sevk bilgileri ve arşiv" onPress={() => nav.push(routes.completeFlock(flock.flock_id))} /> : null}
      </ListCard>
    </>
  );
}

function FlockCharts({ flock, days }: { flock: FlockOverview; days: FlockDay[] }) {
  const th = useAlertSettings(flock.farm_id);
  const wt = useWeightTargets(flock.farm_id);
  const labels = days.map((d) => String(d.age_day));
  const target = useMemo(() => {
    const pts = wt.data ?? []; if (!pts.length) return null;
    return days.map((d) => {
      const lo = [...pts].reverse().find((p) => p.age_day <= d.age_day), hi = pts.find((p) => p.age_day >= d.age_day);
      if (!lo || !hi) return null; if (lo.age_day === hi.age_day) return Number(lo.target_g);
      return Number(lo.target_g) + ((Number(hi.target_g) - Number(lo.target_g)) * (d.age_day - lo.age_day)) / (hi.age_day - lo.age_day);
    });
  }, [wt.data, days]);
  return (
    <>
      <Card style={{ gap: 8 }}>
        <Text variant="cardTitle">Günlük Ölüm Oranı (%)</Text>
        <TrendChart labels={labels} series={[{ name: 'Günlük ölüm %', values: days.map((d) => (d.daily_mortality_pct == null ? null : Number(d.daily_mortality_pct))) }]}
          format={(n) => `%${fmtNum(n, 2)}`} tooltip={(i, v) => [`%${fmtNum(v, 3)}`, `${days[i].age_day}. gün · ${days[i].deaths} baş`]} />
      </Card>
      <Card style={{ gap: 8 }}>
        <Text variant="cardTitle">Günlük Ölüm (baş)</Text>
        <BarChart labels={labels} values={days.map((d) => d.deaths)} tone={(v, i) => {
          const p = (v / (days[i].start_of_day_alive || 1)) * 100; const t = th.data;
          return t && p >= t.daily_mortality_critical_pct ? 'danger' : t && p >= t.daily_mortality_warn_pct ? 'warning' : null;
        }} />
      </Card>
      <Card style={{ gap: 8 }}>
        <Text variant="cardTitle">Ağırlık Gelişimi (g)</Text>
        <TrendChart labels={labels} format={(n) => fmtInt(n)} series={[
          { name: 'Ölçülen (örneklem)', values: days.map((d) => (d.avg_weight_g == null ? null : Number(d.avg_weight_g))), color: colors.module.weight.fg, connectGaps: true },
          ...(target ? [{ name: 'Hedef eğri', values: target, dashed: true, color: colors.text.muted, connectGaps: true }] : []),
        ]} tooltip={(i, v) => [`${fmtInt(v)} g`, `${days[i].age_day}. gün`]} />
        <Text variant="caption" muted>Noktalar yalnızca gerçek tartım günleridir; aradaki günlere değer üretilmez.{target ? ' Kesikli çizgi çiftliğin tanımladığı hedef eğridir.' : ''}</Text>
      </Card>
    </>
  );
}

const KIND: Record<string, [string, string]> = { mortality: ['Ölüm', 'baş'], coal: ['Kömür', 'torba'], medication: ['İlaç', ''], weight: ['Tartım', 'g'], temperature: ['Sıcaklık', '°C'], note: ['Not', ''], movement: ['Sürü hareketi', 'baş'] };
function RecordHistory({ flock }: { flock: FlockOverview }) {
  const act = useActivity({ orgId: flock.org_id, flockId: flock.flock_id, limit: 100 });
  const names = useProfileNames();
  if (act.isLoading) return <Loading />;
  if (!act.data?.length) return <EmptyState title="Bu dönemde henüz kayıt yok" />;
  return (
    <Card padded={false}>
      {act.data.map((a, i) => (
        <View key={a.kind + a.id}>
          {i > 0 && <Divider inset={spacing.lg} />}
          <View style={{ paddingHorizontal: spacing.lg, paddingVertical: 10 }}>
            <Row justify="space-between">
              <Text variant="bodyStrong">{KIND[a.kind][0]}{a.value != null ? ` · ${fmtNum(a.value, 2)} ${KIND[a.kind][1]}` : ''}</Text>
              <Text variant="caption" muted>{formatShortDate(a.entry_date)}</Text>
            </Row>
            {a.label || a.note ? <Text variant="label" muted numberOfLines={2}>{[a.label, a.note].filter(Boolean).join(' — ')}</Text> : null}
            <Text variant="caption" muted>{names.get(a.created_by) ?? 'Kullanıcı'} · gönderim {formatTime(a.created_at)}{a.version > 1 ? ' · düzeltildi' : ''}</Text>
          </View>
        </View>
      ))}
      <View style={{ padding: spacing.md }}><Button title="Düzeltme geçmişi" variant="secondary" compact onPress={() => nav.push(routes.activity(flock.flock_id))} /></View>
    </Card>
  );
}

