import { useQueryClient } from '@tanstack/react-query';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { useFarm } from '../../src/api/queries';
import { Button, Card, Notice, PillTabs, Screen, StickyFooter, Text, TextField } from '../../src/components/ui';
import type { HeatingType } from '../../src/domain/types';
import { errorMessage } from '../../src/lib/errors';
import { dataClient } from '../../src/lib/data';

export default function NewHouse() {
  const qc = useQueryClient();
  const farm = useFarm();
  const [name, setName] = useState('');
  const [cap, setCap] = useState('');
  const [heat, setHeat] = useState<HeatingType>('coal');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const save = async () => {
    const c = parseInt(cap, 10);
    if (!name.trim()) return setError('Kümes adını girin.');
    if (!c || c <= 0 || c > 1_000_000) return setError('Geçerli bir kapasite girin.');
    setBusy(true); setError(null);
    const { error: e } = await dataClient.from('houses').insert({ farm_id: farm.data!.id, org_id: farm.data!.org_id, name: name.trim(), capacity: c, heating_type: heat } as never);
    setBusy(false);
    if (e) return setError(e.message.includes('houses_farm_id_name_key') ? 'Bu isimde bir kümes zaten var.' : errorMessage(e));
    void qc.invalidateQueries({ queryKey: ['houses'] });
    router.back();
  };
  return (
    <Screen title="Kümes Ekle" back footer={<StickyFooter><Button title="Kaydet" icon="check" loading={busy} onPress={save} /></StickyFooter>}>
      <Card style={{ gap: 14 }}>
        <TextField label="Kümes adı / numarası" value={name} onChangeText={setName} placeholder="Kümes 4" />
        <TextField label="Civciv kapasitesi" value={cap} onChangeText={(s) => setCap(s.replace(/\D/g, ''))} keyboardType="number-pad" suffix="baş" />
        <Text variant="label" muted>Isıtma türü</Text>
        <PillTabs value={heat} onChange={setHeat} options={[{ value: 'coal', label: 'Kömür' }, { value: 'gas', label: 'Gaz' }, { value: 'electric', label: 'Elektrik' }, { value: 'other', label: 'Diğer' }]} />
      </Card>
      <Notice>Kapasite kümesin fiziksel sınırıdır; yerleştirilen civciv sayısı her dönem başında ayrıca girilir.</Notice>
      {error && <Notice tone="danger">{error}</Notice>}
    </Screen>
  );
}
