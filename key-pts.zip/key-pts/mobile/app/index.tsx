// Splash ekranı: lacivert zemin, kurumsal logo ve slogan. Yönlendirmeyi AuthGate yapar.
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useRef } from 'react';
import { ActivityIndicator, Animated, View } from 'react-native';
import { LogoFull } from '../src/components/brand/Logo';
import { Text } from '../src/components/ui';
import { colors } from '../src/theme';

export default function Splash() {
  const a = useRef(new Animated.Value(0)).current;
  useEffect(() => { Animated.timing(a, { toValue: 1, duration: 500, useNativeDriver: true }).start(); }, [a]);
  return (
    <LinearGradient colors={[colors.brand.navySoft, colors.brand.navy, colors.brand.navyDeep]} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <StatusBar style="light" />
      <Animated.View style={{ opacity: a, transform: [{ scale: a.interpolate({ inputRange: [0, 1], outputRange: [0.96, 1] }) }] }}>
        <LogoFull size={1.05} />
      </Animated.View>
      <View style={{ position: 'absolute', bottom: 64, alignItems: 'center', gap: 14 }}>
        <ActivityIndicator color={colors.brand.orange} />
        <Text variant="label" color="#AFC0D0">Kümesinizin nabzı, avucunuzda.</Text>
      </View>
    </LinearGradient>
  );
}
