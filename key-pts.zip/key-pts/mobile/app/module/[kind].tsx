// Modül ekranları: Ölüm Takvimi · Kömür Tüketimi · İlaç Kayıtları · Tartım ve Büyüme · Sıcaklık ve Ortam · Günlük Notlar
import { router, useLocalSearchParams } from 'expo-router';
import { nav, routes, type ModuleKind, type SingleEntryKind } from '../../src/navigation/nav';
import React, { useMemo, useState } from 'react';
import { RefreshControl, View } from 'react-native';
import { useActiveOrg, useAlertSettings, useEntries, useFlock, useFlockDaily, useProfileNames, useTemperatureTargets, useWeightTargets } from '../../src/api/queries';
import { MortalityCalendar } from '../../src/components/cards/MortalityCalendar';
import { StatBox } from '../../src/components/cards';
import { BarChart, TrendChart } from '../../src/components/charts/TrendChart';
import { Button, Card, Divider, EmptyState, Loading, Notice, PillTabs, Row, Screen, SectionHeader, StickyFooter, Text } from '../../src/components/ui';
import type { EntryKind, FlockDay, FlockOverview } from '../../src/domain/types';
import { EditEntrySheet, type EditTarget } from '../../src/features/EditEntrySheet';
import { METHOD_TR, UNIT_TR } from '../../src/features/medications/labels';
import { coalReport, mortalityReport, temperatureReport, weeklyCoal, weightReport } from '../../src/features/reportBuilders';
import { formatDate, formatDateTime, formatShortDate, formatTime } from '../../src/lib/dates';
import { shareCsv } from '../../src/lib/export';
import { fmtGram, fmtInt, fmtKg, fmtNum, fmtPct } from '../../src/lib/format';
import { useUserId } from '../../src/stores/session';
import { colors, spacing } from '../../src/theme';

const TITLE: Record<string, string> = { mortality: 'Ölüm Takvimi', coal: 'Kömür Tüketimi', medication: 'İlaç Kayıtları', weight: 'Tartım ve Büyüme', temperature: 'Sıcaklık ve Ortam', note: 'Günlük Notlar' };
const CAUSE_TR: Record<string, string> = { unknown: 'Belirsiz', weak_chick: 'Zayıf civciv', respiratory: 'Solunum', digestive: 'Sindirim', leg_problem: 'Bacak problemi', heat_stress: 'Sıcak stresi', cold_stress: 'Soğuk stresi', crushing: 'Ezilme', predator: 'Yırtıcı', other: 'Diğer' };

export default function ModuleScreen() {
  const { kind, flockId } = useLocalSearchParams<{ kind: string; flockId: string }>();
  const flock = useFlock(flockId ?? null);
  const daily = useFlockDaily(flockId ?? null);
  const f = flock.data;
  const k = (kind ?? 'note') as EntryKind;
  const singleKind = k === 'note' || k === 'temperature' || k === 'medication' ? k : null;
  return (
    <Screen title={TITLE[k] ?? 'Kayıtlar'} back
      refreshControl={<RefreshControl refreshing={daily.isRefetching} onRefresh={() => { void daily.refetch(); void flock.refetch(); }} tintColor={colors.brand.orange} />}
      footer={f?.status === 'active' ? <StickyFooter><Button title={singleKind ? `${TITLE[k].split(' ')[0]} Kaydı Ekle` : 'Günlük Kayıt Ekle'} icon="plus"
        onPress={() => (singleKind ? nav.push(routes.entry(k as SingleEntryKind, f.house_id)) : nav.push(routes.dailyRecord(f.house_id)))} /></StickyFooter> : undefined}>
      {!f || daily.isLoading ? <Loading /> : (
        <>
          <Card style={{ paddingVertical: 10 }}><Row justify="center" gap={10}><Text variant="bodyStrong">{f.house_name}</Text><Text muted>|</Text><Text variant="bodyStrong">{f.name}</Text><Text muted>|</Text><Text variant="bodyStrong">{f.age_day}. gün</Text></Row></Card>
          {k === 'mortality' && <Mortality f={f} days={daily.data ?? []} />}
          {k === 'coal' && <Coal f={f} days={daily.data ?? []} />}
          {k === 'medication' && <Medication f={f} />}
          {k === 'weight' && <Weight f={f} days={daily.data ?? []} />}
          {k === 'temperature' && <Temperature f={f} days={daily.data ?? []} />}
          {k === 'note' && <Notes f={f} />}
        </>
      )}
    </Screen>
  );
}

type Base = { id: string; created_by: string; created_at: string; version: number; entry_date: string };
function Entries<T extends Base>({ f, rows, render, edit }: { f: FlockOverview; rows?: T[]; render: (r: T) => React.ReactNode; edit?: (r: T) => EditTarget }) {
  const names = useProfileNames(); const uid = useUserId(); const { role } = useActiveOrg();
  const [t, setT] = useState<EditTarget | null>(null);
  if (!rows?.length) return <EmptyState title="Kayıt yok" body="Bu dönem için henüz kayıt girilmedi." />;
  const manage = role === 'owner' || role === 'manager';
  return (
    <Card padded={false}>
      {rows.map((r, i) => (
        <View key={r.id}>
          {i > 0 && <Divider inset={spacing.lg} />}
          <Row style={{ paddingHorizontal: spacing.lg, paddingVertical: 10 }} align="flex-start">
            <View style={{ flex: 1, gap: 2 }}>
              {render(r)}
              <Text variant="caption" muted>{formatShortDate(r.entry_date)} · {names.get(r.created_by) ?? 'Kullanıcı'} · {formatTime(r.created_at)}{r.version > 1 ? ' · düzeltildi' : ''}</Text>
            </View>
            {edit && f.status === 'active' && (r.created_by === uid || manage) ? <Button title="Düzelt" variant="ghost" compact onPress={() => setT(edit(r))} /> : null}
          </Row>
        </View>
      ))}
      <EditEntrySheet target={t} onClose={() => setT(null)} canDelete={manage} />
    </Card>
  );
}

function Mortality({ f, days }: { f: FlockOverview; days: FlockDay[] }) {
  const th = useAlertSettings(f.farm_id);
  const [view, setView] = useState<'calendar' | 'table' | 'chart'>('calendar');
  const [metric, setMetric] = useState<'daily' | 'cum' | 'pct' | 'cumPct'>('daily');
  const rows = useEntries<Base & { count: number; cause: string | null; note: string | null }>('mortality_entries', f.flock_id);
  const missing = days.filter((d) => !d.mortality_recorded).length;
  const labels = days.map((d) => String(d.age_day));
  const series = days.map((d) => (metric === 'daily' ? d.deaths : metric === 'cum' ? d.cumulative_deaths : metric === 'pct' ? d.daily_mortality_pct : d.cumulative_mortality_pct)).map((v) => (v == null ? null : Number(v)));
  const pct = metric === 'pct' || metric === 'cumPct';
  return (
    <>
      <Row gap={spacing.sm}>
        <StatBox label="Toplam ölüm" value={fmtInt(f.total_deaths)} sub={fmtPct(f.cumulative_mortality_pct)} tone="danger" />
        <StatBox label="Bugün" value={f.today_mortality_recorded ? fmtInt(f.today_deaths) : 'Kayıt yok'} />
        <StatBox label="Eksik gün" value={fmtInt(missing)} tone={missing ? 'danger' : 'success'} />
      </Row>
      <PillTabs value={view} onChange={setView} options={[{ value: 'calendar', label: 'Takvim' }, { value: 'table', label: 'Tablo' }, { value: 'chart', label: 'Grafik' }]} />
      {view === 'calendar' && <Card><MortalityCalendar days={days} thresholds={th.data} /></Card>}
      {view === 'table' && (
        <Card padded={false}>
          <Row style={{ paddingHorizontal: spacing.lg, paddingVertical: 8, backgroundColor: colors.surface.tertiary }}>
            {['Gün', 'Tarih', 'Ölüm', 'Günlük %', 'Kümülatif'].map((h, i) => <Text key={h} variant="caption" muted style={{ flex: i === 1 ? 1.4 : 1, textAlign: i > 1 ? 'right' : 'left' }}>{h}</Text>)}
          </Row>
          {[...days].reverse().map((d) => (
            <Row key={d.day} style={{ paddingHorizontal: spacing.lg, paddingVertical: 8, borderTopWidth: 1, borderTopColor: colors.border.subtle }}>
              <Text variant="label" style={{ flex: 1 }}>{d.age_day}.</Text>
              <Text variant="label" muted style={{ flex: 1.4 }}>{formatShortDate(d.day)}</Text>
              <Text variant="bodyStrong" style={{ flex: 1, textAlign: 'right' }} color={d.mortality_recorded ? undefined : colors.status.warning}>{d.mortality_recorded ? fmtInt(d.deaths) : 'yok'}</Text>
              <Text variant="label" style={{ flex: 1, textAlign: 'right' }}>{fmtPct(d.daily_mortality_pct, 3)}</Text>
              <Text variant="label" style={{ flex: 1, textAlign: 'right' }}>{fmtInt(d.cumulative_deaths)}</Text>
            </Row>
          ))}
        </Card>
      )}
      {view === 'chart' && (
        <Card style={{ gap: spacing.md }}>
          <PillTabs value={metric} onChange={setMetric} options={[{ value: 'daily', label: 'Günlük' }, { value: 'cum', label: 'Kümülatif' }, { value: 'pct', label: 'Günlük %' }, { value: 'cumPct', label: 'Küm. %' }]} />
          {metric === 'daily' ? <BarChart labels={labels} values={series} /> : <TrendChart labels={labels} series={[{ name: 'Ölüm', values: series }]} format={(n) => (pct ? `%${fmtNum(n, 2)}` : fmtInt(n))} tooltip={(i, v) => [pct ? `%${fmtNum(v, 3)}` : fmtInt(v), `${days[i].age_day}. gün`]} />}
        </Card>
      )}
      <Notice>Günlük % = günlük ölüm ÷ gün başı mevcut × 100. Kümülatif % = toplam ölüm ÷ (başlangıç + ek girişler) × 100. Kayıt girilmemiş günler sıfır sayılmaz.</Notice>
      <SectionHeader title="Kayıtlar" action="CSV" onAction={() => { const r = mortalityReport(days); void shareCsv(`${f.house_name}-olum`, r.headers, r.rows); }} />
      <Entries f={f} rows={rows.data} render={(r) => <Text variant="bodyStrong">{fmtInt(r.count)} baş{r.cause ? ` · ${CAUSE_TR[r.cause]}` : ''}{r.note ? ` — ${r.note}` : ''}</Text>}
        edit={(r) => ({ kind: 'mortality', id: r.id, version: r.version, field: 'count', label: `${fmtInt(r.count)} ölüm`, value: String(r.count), integer: true })} />
    </>
  );
}

function Coal({ f, days }: { f: FlockOverview; days: FlockDay[] }) {
  const rows = useEntries<Base & { bag_count: number; bag_weight_kg: number; total_kg: number; coal_type: string | null; unit_price: number | null }>('coal_entries', f.flock_id);
  const [unit, setUnit] = useState<'bags' | 'kg'>('bags');
  const weeks = weeklyCoal(days);
  const bags = days.reduce((s, d) => s + Number(d.coal_bags ?? 0), 0);
  const kg = days.reduce((s, d) => s + Number(d.coal_kg ?? 0), 0);
  const priced = rows.data?.filter((e) => e.unit_price != null) ?? [];
  const cost = priced.reduce((s, e) => s + Number(e.unit_price) * Number(e.bag_count), 0);
  return (
    <>
      <Row gap={spacing.sm}>
        <StatBox label="Bugün" value={f.today_coal_bags == null ? 'Kayıt yok' : `${fmtNum(f.today_coal_bags, 1)} torba`} />
        <StatBox label="Dönem (torba)" value={fmtNum(bags, 1)} />
        <StatBox label="Dönem (kg)" value={fmtNum(kg, 0)} />
      </Row>
      <PillTabs value={unit} onChange={setUnit} options={[{ value: 'bags', label: 'Torba' }, { value: 'kg', label: 'Kilogram' }]} />
      <Card><BarChart labels={days.map((d) => String(d.age_day))} values={days.map((d) => (unit === 'bags' ? (d.coal_bags == null ? null : Number(d.coal_bags)) : d.coal_kg == null ? null : Number(d.coal_kg)))} /></Card>
      <SectionHeader title="Haftalık tüketim" action="CSV" onAction={() => { const r = coalReport(days); void shareCsv(`${f.house_name}-komur`, r.headers, r.rows); }} />
      <Card padded={false}>
        {weeks.map((w, i) => (
          <View key={w.week}>{i > 0 && <Divider inset={spacing.lg} />}
            <Row style={{ paddingHorizontal: spacing.lg, paddingVertical: 10 }} justify="space-between">
              <Text variant="bodyStrong">{w.week}. hafta</Text><Text variant="label">{fmtNum(w.bags, 1)} torba · {fmtNum(w.kg, 0)} kg</Text><Text variant="caption" muted>{w.daysRecorded}/{w.days} gün kayıtlı</Text>
            </Row>
          </View>
        ))}
      </Card>
      {priced.length ? <Notice>{`Birim fiyat girilen ${priced.length} kayda göre maliyet: ${fmtNum(cost, 2)} ₺ (fiyatsız kayıtlar hariç).`}</Notice> : null}
      <Notice>Kilogram her kaydın kendi torba ağırlığıyla hesaplanır; farklı torba ağırlıkları karışmaz.</Notice>
      <SectionHeader title="Kayıtlar" />
      <Entries f={f} rows={rows.data} render={(r) => <Text variant="bodyStrong">{fmtNum(r.bag_count, 1)} torba × {fmtNum(r.bag_weight_kg, 1)} kg = {fmtNum(r.total_kg, 1)} kg</Text>}
        edit={(r) => ({ kind: 'coal', id: r.id, version: r.version, field: 'bag_count', label: `${fmtNum(r.bag_count, 1)} torba`, value: String(r.bag_count).replace('.', ',') })} />
    </>
  );
}

function Medication({ f }: { f: FlockOverview }) {
  const rows = useEntries<Base & { product_name: string; amount: number; unit: string; method: string | null; vet_instruction_ref: string | null; withdrawal_days: number; withdrawal_end_date: string; note: string | null }>('medication_applications', f.flock_id);
  return (
    <>
      <Notice>KEY PTS ilaç, doz veya tedavi önermez. Uygulamalar yetkili veterinerin talimatına göre kayıt altına alınır.</Notice>
      {f.withdrawal_conflict ? <Notice tone="danger">{`Bekleme süresi ${formatDate(f.withdrawal_end_date)} tarihinde bitiyor; planlanan kesim ${formatDate(f.expected_slaughter_date)}. Veterinerinize danışın.`}</Notice> : null}
      <Entries f={f} rows={rows.data} render={(r) => {
        const conflict = !!(f.expected_slaughter_date && r.withdrawal_days > 0 && r.withdrawal_end_date >= f.expected_slaughter_date);
        return (
          <View style={{ gap: 2 }}>
            <Text variant="bodyStrong">{r.product_name} · {fmtNum(r.amount, 3)} {UNIT_TR[r.unit] ?? r.unit}</Text>
            <Text variant="caption" muted>{[r.method && METHOD_TR[r.method], r.vet_instruction_ref && `Talimat: ${r.vet_instruction_ref}`].filter(Boolean).join(' · ') || 'Yöntem belirtilmedi'}</Text>
            {r.withdrawal_days > 0 ? <Text variant="caption" color={conflict ? colors.status.danger : colors.text.secondary}>Bekleme {r.withdrawal_days} gün → {formatShortDate(r.withdrawal_end_date)}{conflict ? ' · kesim planıyla çakışıyor' : ''}</Text> : null}
          </View>
        );
      }} />
    </>
  );
}

function Weight({ f, days }: { f: FlockOverview; days: FlockDay[] }) {
  const { gains, headers, rows: table } = weightReport(days);
  const wt = useWeightTargets(f.farm_id);
  const target = useMemo(() => (wt.data?.length ? days.map((d) => { const t = wt.data!.find((x) => x.age_day === d.age_day); return t ? Number(t.target_g) : null; }) : null), [wt.data, days]);
  const last = gains[gains.length - 1];
  return (
    <>
      <Row gap={spacing.sm}>
        <StatBox label="Son ortalama" value={last ? fmtKg(last.avgG) : '—'} />
        <StatBox label="Son ölçüm" value={last ? formatShortDate(last.date) : '—'} />
        <StatBox label="Örneklem" value={last?.sample ? fmtInt(last.sample) : '—'} />
      </Row>
      <Notice>Tartım örneklem üzerinden yapılır; sürünün tamamının ölçülmüş ağırlığı değildir. Ölçüm yapılmayan günlere değer yazılmaz.</Notice>
      <Card>
        <TrendChart labels={days.map((d) => String(d.age_day))} format={(n) => fmtInt(n)} tooltip={(i, v) => [`${fmtInt(v)} g`, `${days[i].age_day}. gün`]} series={[
          { name: 'Ölçülen (örneklem)', values: days.map((d) => (d.avg_weight_g == null ? null : Number(d.avg_weight_g))), color: colors.module.weight.fg, connectGaps: true },
          ...(target ? [{ name: 'Hedef (çiftlik planı)', values: target, dashed: true, color: colors.text.muted, connectGaps: true }] : []),
        ]} />
      </Card>
      <SectionHeader title="Ölçümler" action="CSV" onAction={() => void shareCsv(`${f.house_name}-tartim`, headers, table)} />
      <Card padded={false}>
        {!gains.length ? <View style={{ padding: spacing.lg }}><Text muted>Henüz tartım yok.</Text></View> : [...gains].reverse().map((g, i) => (
          <View key={g.date}>{i > 0 && <Divider inset={spacing.lg} />}
            <Row style={{ paddingHorizontal: spacing.lg, paddingVertical: 10 }} justify="space-between">
              <View><Text variant="bodyStrong">{fmtGram(g.avgG)}</Text><Text variant="caption" muted>{formatShortDate(g.date)} · {fmtInt(g.sample)} örnek</Text></View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text variant="label" color={g.gainSincePrevG != null && g.gainSincePrevG < 0 ? colors.status.danger : colors.status.success}>{g.gainSincePrevG == null ? 'İlk ölçüm' : `${g.gainSincePrevG >= 0 ? '+' : ''}${fmtInt(g.gainSincePrevG)} g`}</Text>
                <Text variant="caption" muted>{g.dailyGainG == null ? '' : `${fmtNum(g.dailyGainG, 1)} g/gün`}</Text>
              </View>
            </Row>
          </View>
        ))}
      </Card>
    </>
  );
}

function Temperature({ f, days }: { f: FlockOverview; days: FlockDay[] }) {
  const targets = useTemperatureTargets(f.farm_id);
  const rows = useEntries<Base & { measured_at: string; temperature_c: number; humidity_pct: number | null }>('temperature_measurements', f.flock_id, 'measured_at');
  const tgt = (age: number) => targets.data?.find((x) => age >= x.day_from && age <= x.day_to);
  const recent = days.slice(-14);
  return (
    <>
      <Notice>Sıcaklıklar manuel girilir. Sensör bağlı değildir; canlı ölçüm gösterilmez.</Notice>
      <Card>
        <TrendChart labels={recent.map((d) => String(d.age_day))} minZero={false} format={(n) => fmtNum(n, 0)} tooltip={(i, v) => [`${fmtNum(v, 1)} °C`, `${recent[i].age_day}. gün ort.`]} series={[
          { name: 'Günlük ortalama', values: recent.map((d) => (d.temp_avg == null ? null : Number(d.temp_avg))), color: colors.status.danger },
          { name: 'Hedef min', values: recent.map((d) => tgt(d.age_day)?.min_c ?? null), dashed: true, color: colors.text.muted },
          { name: 'Hedef maks', values: recent.map((d) => tgt(d.age_day)?.max_c ?? null), dashed: true, color: colors.text.muted },
        ]} />
        {!targets.data?.length ? <Text variant="caption" muted>Hedef aralık tanımlı değil (Ayarlar → Bildirim Ayarları → Uyarı eşikleri).</Text> : null}
      </Card>
      <SectionHeader title="Ölçümler" action="CSV" onAction={() => { const r = temperatureReport(days); void shareCsv(`${f.house_name}-sicaklik`, r.headers, r.rows); }} />
      <Entries f={f} rows={rows.data} render={(r) => {
        const age = days.find((d) => d.day === r.entry_date)?.age_day ?? 0; const t = tgt(age);
        const out = t && (r.temperature_c < t.min_c || r.temperature_c > t.max_c);
        return <Text variant="bodyStrong" color={out ? colors.status.danger : undefined}>{fmtNum(r.temperature_c, 1)} °C{r.humidity_pct != null ? ` · %${fmtNum(r.humidity_pct, 0)} nem` : ''} · {formatDateTime(r.measured_at)}{out ? ` · hedef dışı (${t!.min_c}–${t!.max_c})` : ''}</Text>;
      }} />
    </>
  );
}

function Notes({ f }: { f: FlockOverview }) {
  const rows = useEntries<Base & { body: string; photo_path: string | null }>('daily_notes', f.flock_id);
  return <Entries f={f} rows={rows.data} render={(r) => <Text>{r.body}{r.photo_path ? ' · fotoğraf' : ''}</Text>}
    edit={(r) => ({ kind: 'note', id: r.id, version: r.version, field: 'body', label: 'Not', value: r.body })} />;
}
