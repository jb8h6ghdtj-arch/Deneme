import { useQueryClient } from '@tanstack/react-query';
import { router } from 'expo-router';
import { nav, routes, type ModuleKind, type SingleEntryKind } from '../src/navigation/nav';
import React from 'react';
import { RefreshControl, View } from 'react-native';
import { useNotifications } from '../src/api/queries';
import { Icon } from '../src/components/Icon';
import { Button, Card, EmptyState, Loading, Row, Screen, Text } from '../src/components/ui';
import { formatDateTime } from '../src/lib/dates';
import { dataClient } from '../src/lib/data';
import { colors } from '../src/theme';

export default function Notifications() {
  const qc = useQueryClient();
  const q = useNotifications();
  const mark = async (ids: string[]) => { if (!ids.length) return; await dataClient.from('notifications').update({ read_at: new Date().toISOString() } as never).in('id', ids); void qc.invalidateQueries({ queryKey: ['notifications'] }); };
  const unread = q.data?.filter((n) => !n.read_at).map((n) => n.id) ?? [];
  return (
    <Screen title="Bildirimler" back refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => { void q.refetch(); }} tintColor={colors.brand.orange} />}>
      {unread.length > 0 && <Button title="Tümünü okundu say" variant="secondary" compact onPress={() => void mark(unread)} />}
      {q.isLoading ? <Loading /> : !q.data?.length ? <EmptyState icon="bell" title="Bildiriminiz yok" /> : q.data.map((n) => {
        const fg = n.severity === 'critical' ? colors.status.danger : n.severity === 'warning' ? colors.status.warning : colors.status.info;
        const bg = n.severity === 'critical' ? colors.status.dangerSoft : n.severity === 'warning' ? colors.status.warningSoft : colors.status.infoSoft;
        return (
          <Card key={n.id} onPress={() => { void mark([n.id]); if (n.house_id) nav.push(routes.house(n.house_id)); }} style={{ opacity: n.read_at ? 0.75 : 1 }}>
            <Row gap={12} align="flex-start">
              <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: bg, alignItems: 'center', justifyContent: 'center' }}><Icon name={n.kind.includes('temperature') ? 'temperature' : n.kind.includes('withdrawal') ? 'medication' : n.kind.includes('slaughter') ? 'flag' : n.kind.includes('missing') ? 'clock' : 'mortality'} color={fg} size={18} /></View>
              <View style={{ flex: 1, gap: 2 }}>
                <Row justify="space-between"><Text variant="bodyStrong" style={{ flex: 1 }}>{n.title}</Text>{!n.read_at ? <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: colors.brand.orange }} /> : null}</Row>
                <Text variant="label" muted>{n.body}</Text>
                <Text variant="caption" muted>{formatDateTime(n.created_at)}</Text>
              </View>
            </Row>
          </Card>
        );
      })}
    </Screen>
  );
}
