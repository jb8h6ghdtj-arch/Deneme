// İlk Kurulum karşılama ekranı
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyPTSLogoOnDark } from '../../src/components/brand/Logo';
import { Icon } from '../../src/components/Icon';
import { Button, Row, Text } from '../../src/components/ui';
import { useLayout } from '../../src/hooks/useLayout';
import { nav } from '../../src/navigation/nav';
import { colors, spacing } from '../../src/theme';

const POINTS = ['Kümes bazlı takip ve kapasite', 'Günlük ölüm, kömür, ilaç, tartım ve sıcaklık', 'Sürü takvimi, grafikler ve raporlar', 'İnternet gerekmez — veriler bu cihazda saklanır'];

export default function Welcome() {
  const insets = useSafeAreaInsets();
  const { width } = useLayout();
  return (
    <LinearGradient colors={[colors.brand.navySoft, colors.brand.navy, colors.brand.navyDeep]} style={{ flex: 1 }}>
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={{ flexGrow: 1, paddingTop: insets.top + 40, paddingBottom: insets.bottom + 24, paddingHorizontal: 24, gap: spacing.xl, maxWidth: 520, width: '100%', alignSelf: 'center' }}>
        <View style={{ alignItems: 'center' }}><KeyPTSLogoOnDark width={Math.min(220, width * 0.55)} /></View>
        <Text variant="display" color="#fff" style={{ textAlign: 'center' }}>Broiler Çiftlikleri için Akıllı Takip Sistemi</Text>
        <View style={{ gap: spacing.md }}>
          {POINTS.map((p) => (
            <Row key={p} gap={spacing.md} align="flex-start">
              <View style={{ width: 22, height: 22, borderRadius: 5, backgroundColor: colors.brand.orange, alignItems: 'center', justifyContent: 'center', marginTop: 1 }}><Icon name="check" color="#fff" size={15} strokeWidth={3} /></View>
              <Text color="#E8EDF3" style={{ flex: 1 }}>{p}</Text>
            </Row>
          ))}
        </View>
        <View style={{ flex: 1 }} />
        <Button title="Kuruluma Başla" pill onPress={() => nav.push('/onboarding/setup')} />
        <Text variant="caption" color="#AFC0D0" style={{ textAlign: 'center' }}>Kümesinizin nabzı, avucunuzda.</Text>
      </ScrollView>
    </LinearGradient>
  );
}
