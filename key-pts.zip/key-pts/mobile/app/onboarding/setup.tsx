// İlk Kurulum sihirbazı: Hesap → Başlangıç → Çiftlik → Kümesler (kapasite) → Isıtma ve gün standardı → Özet
import { useQueryClient } from '@tanstack/react-query';
import React, { useMemo, useState } from 'react';
import { Pressable, View } from 'react-native';
import { z } from 'zod';
import { Icon } from '../../src/components/Icon';
import { Button, Card, Notice, PillTabs, Row, Screen, Stepper, StickyFooter, Text, TextField } from '../../src/components/ui';
import type { HeatingType } from '../../src/domain/types';
import { dataClient } from '../../src/lib/data';
import { errorMessage } from '../../src/lib/errors';
import { fmtInt, parseDecimal } from '../../src/lib/format';
import { useSession } from '../../src/stores/session';
import { colors, radius, spacing } from '../../src/theme';

const HEAT: { value: HeatingType; label: string }[] = [{ value: 'coal', label: 'Kömür' }, { value: 'gas', label: 'Gaz' }, { value: 'electric', label: 'Elektrik' }, { value: 'other', label: 'Diğer' }];
interface H { name: string; capacity: string; heating: HeatingType }
type Step = 'account' | 'start' | 'farm' | 'houses' | 'heating' | 'review';
const TITLES: Record<Step, string> = { account: 'Hesap Oluştur', start: 'Nasıl başlayalım?', farm: 'Çiftlik Oluştur', houses: 'Kümes Ekle', heating: 'Isıtma ve Gün Standardı', review: 'Özet' };

export default function Setup() {
  const qc = useQueryClient();
  const session = useSession((s) => s.session);
  // Adım listesi ekran açılırken sabitlenir: hesap oluşturulunca oturum açılır ama adımlar kaymaz
  const [steps] = useState<Step[]>(() => (session ? ['start', 'farm', 'houses', 'heating', 'review'] : ['account', 'start', 'farm', 'houses', 'heating', 'review']));
  const [i, setI] = useState(0);
  const step = steps[Math.min(i, steps.length - 1)];
  const [acc, setAcc] = useState({ name: '', user: '', pw: '', pw2: '', phone: '' });
  const [farm, setFarm] = useState({ name: '', location: '' });
  const [houses, setHouses] = useState<H[]>([1, 2, 3].map((n) => ({ name: `Kümes ${n}`, capacity: '', heating: 'coal' })));
  const [bagKg, setBagKg] = useState('25');
  const [ageBase, setAgeBase] = useState<'0' | '1'>('0');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const total = useMemo(() => houses.reduce((s, h) => s + (parseInt(h.capacity, 10) || 0), 0), [houses]);

  const validate = (): string | null => {
    if (step === 'account') {
      if (acc.name.trim().length < 2) return 'Adınızı ve soyadınızı girin.';
      if (!/^[a-z0-9._-]{3,32}$/i.test(acc.user.trim())) return 'Kullanıcı adı 3–32 karakter olmalı (harf, rakam, nokta, tire).';
      if (acc.pw.length < 6) return 'Şifre en az 6 karakter olmalı.';
      if (acc.pw !== acc.pw2) return 'Şifreler eşleşmiyor.';
    }
    if (step === 'farm' && farm.name.trim().length < 2) return 'Çiftlik adını girin.';
    if (step === 'houses') {
      for (const h of houses) if (!z.object({ n: z.string().trim().min(1), c: z.number().int().positive().max(1_000_000) }).safeParse({ n: h.name, c: parseInt(h.capacity, 10) }).success) return `“${h.name || 'Adsız kümes'}” için ad ve geçerli kapasite girin.`;
      if (new Set(houses.map((h) => h.name.trim().toLocaleLowerCase('tr'))).size !== houses.length) return 'Kümes adları birbirinden farklı olmalı.';
    }
    if (step === 'heating' && houses.some((h) => h.heating === 'coal')) { const k = parseDecimal(bagKg); if (!k || k <= 0 || k > 100) return 'Torba ağırlığı 0–100 kg arasında olmalı.'; }
    return null;
  };

  const next = async () => {
    const v = validate(); if (v) return setError(v);
    setError(null);
    if (step === 'account') {
      setBusy(true);
      const { error: e } = await dataClient.auth.signUp({ email: acc.user.trim(), password: acc.pw, options: { data: { full_name: acc.name.trim(), phone: acc.phone.trim() || undefined } } });
      setBusy(false);
      if (e) return setError(errorMessage(e));
    }
    if (step === 'review') {
      setBusy(true);
      const { error: e } = await dataClient.rpc('create_organization_with_farm', {
        p_org_name: farm.name.trim(),
        p_farm: { name: farm.name.trim(), location_text: farm.location.trim() || null, contact_name: acc.name.trim() || null, contact_phone: acc.phone.trim() || null,
          default_heating: houses[0].heating, default_coal_bag_kg: parseDecimal(bagKg) ?? 25, age_base: Number(ageBase) },
        p_houses: houses.map((h) => ({ name: h.name.trim(), capacity: parseInt(h.capacity, 10), heating_type: h.heating })),
      });
      setBusy(false);
      if (e) return setError(errorMessage(e));
      await qc.invalidateQueries();
      return; // AuthGate ana sayfaya yönlendirir
    }
    setI(i + 1);
  };

  const loadSample = async () => {
    setBusy(true); setError(null);
    const { error: e } = await dataClient.rpc('load_sample_data');
    setBusy(false);
    if (e) return setError(errorMessage(e));
    await qc.invalidateQueries();
  };

  return (
    <Screen title={TITLES[step]} back={i > 0 ? () => setI(i - 1) : true}
      footer={step === 'start' ? undefined : <StickyFooter><Button title={step === 'review' ? 'Kurulumu Tamamla' : 'Devam'} icon={step === 'review' ? 'check' : undefined} loading={busy} onPress={next} /></StickyFooter>}>
      <Row gap={6}>{steps.map((s, k) => <View key={s} style={{ flex: 1, height: 4, borderRadius: radius.pill, backgroundColor: k <= i ? colors.brand.orange : colors.border.default }} />)}</Row>

      {step === 'account' && (
        <Card style={{ gap: spacing.md }}>
          <Text muted>Bu hesap yalnızca bu telefonda tutulur. Şifreniz şifrelenmiş (özet) olarak saklanır.</Text>
          <TextField label="Ad soyad" value={acc.name} onChangeText={(x) => setAcc({ ...acc, name: x })} autoCapitalize="words" />
          <TextField label="Kullanıcı adı" value={acc.user} onChangeText={(x) => setAcc({ ...acc, user: x })} autoCapitalize="none" autoCorrect={false} hint="Giriş ekranında kullanılır" />
          <TextField label="Şifre" value={acc.pw} onChangeText={(x) => setAcc({ ...acc, pw: x })} secureTextEntry />
          <TextField label="Şifre (tekrar)" value={acc.pw2} onChangeText={(x) => setAcc({ ...acc, pw2: x })} secureTextEntry />
          <TextField label="Telefon (isteğe bağlı)" value={acc.phone} onChangeText={(x) => setAcc({ ...acc, phone: x })} keyboardType="phone-pad" />
        </Card>
      )}

      {step === 'start' && (
        <>
          {[{ t: 'Kendi çiftliğimi tanımlayacağım', d: 'Kümeslerinizi ve kapasitelerini girerek boş bir çiftlikle başlayın.', icon: 'farm' as const, on: () => setI(i + 1) },
            { t: 'Örnek verilerle incele', d: '3 kümes, 120.000 civciv ve 23 günlük örnek dönemle uygulamayı keşfedin. Örnek veriler etiketlenir ve Ayarlar’dan tamamen silinebilir.', icon: 'chart' as const, on: loadSample }].map((o) => (
            <Pressable key={o.t} onPress={o.on} disabled={busy} accessibilityRole="button" style={({ pressed }) => ({ opacity: pressed ? 0.9 : 1 })}>
              <Card>
                <Row gap={spacing.md} align="flex-start">
                  <View style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: colors.brand.orangeSoft, alignItems: 'center', justifyContent: 'center' }}><Icon name={o.icon} color={colors.brand.orangeDark} /></View>
                  <View style={{ flex: 1, gap: 4 }}><Text variant="cardTitle">{o.t}</Text><Text muted>{o.d}</Text></View>
                  <Icon name="chevronRight" color={colors.text.secondary} />
                </Row>
              </Card>
            </Pressable>
          ))}
        </>
      )}

      {step === 'farm' && (
        <Card style={{ gap: spacing.md }}>
          <TextField label="Çiftlik adı" value={farm.name} onChangeText={(x) => setFarm({ ...farm, name: x })} placeholder="KEY Broiler Çiftliği" hint="Şifre yenilemede doğrulama için de kullanılır." />
          <TextField label="Konum (isteğe bağlı)" value={farm.location} onChangeText={(x) => setFarm({ ...farm, location: x })} placeholder="İl / İlçe" />
        </Card>
      )}

      {step === 'houses' && (
        <>
          <Card><Row justify="space-between" wrap><Text variant="bodyStrong">Kümes sayısı</Text><Row gap={12}><Text variant="kpi">{houses.length}</Text>
            <Stepper value={houses.length} min={1} max={50} onChange={(n) => setHouses(Array.from({ length: n }, (_, k) => houses[k] ?? { name: `Kümes ${k + 1}`, capacity: '', heating: houses[0].heating }))} /></Row></Row></Card>
          {houses.map((h, k) => (
            <Card key={k} style={{ gap: spacing.md }}>
              <TextField label="Kümes adı / numarası" value={h.name} onChangeText={(v) => setHouses(houses.map((x, j) => (j === k ? { ...x, name: v } : x)))} />
              <TextField label="Civciv kapasitesi" value={h.capacity} keyboardType="number-pad" suffix="baş" placeholder="40000" onChangeText={(v) => setHouses(houses.map((x, j) => (j === k ? { ...x, capacity: v.replace(/\D/g, '') } : x)))} />
            </Card>
          ))}
          <Card><Row justify="space-between" wrap><Text variant="bodyStrong">Toplam çiftlik kapasitesi</Text><Text variant="kpi">{fmtInt(total)} baş</Text></Row></Card>
          <Notice>Kapasite kümesin fiziksel sınırıdır. Her dönemde yerleştirilen gerçek civciv sayısı dönem başlatılırken ayrıca girilir.</Notice>
        </>
      )}

      {step === 'heating' && (
        <>
          {houses.map((h, k) => (
            <Card key={k} style={{ gap: 8 }}>
              <Text variant="cardTitle">{h.name}</Text>
              <PillTabs options={HEAT} value={h.heating} onChange={(v) => setHouses(houses.map((x, j) => (j === k ? { ...x, heating: v } : x)))} />
            </Card>
          ))}
          {houses.some((h) => h.heating === 'coal') && <Card><TextField label="Standart kömür torbası ağırlığı" value={bagKg} onChangeText={setBagKg} keyboardType="decimal-pad" suffix="kg" hint="Her kayıtta değiştirilebilir; farklı torba ağırlıkları ayrı hesaplanır." /></Card>}
          <Card style={{ gap: 8 }}>
            <Text variant="cardTitle">Gün numaralandırma</Text>
            <PillTabs options={[{ value: '0', label: 'Giriş günü = 0. Gün' }, { value: '1', label: 'Giriş günü = 1. Gün' }]} value={ageBase} onChange={setAgeBase} />
            <Text variant="caption" muted>Bütün ekranlar, raporlar ve uyarılar bu tek standardı kullanır.</Text>
          </Card>
        </>
      )}

      {step === 'review' && (
        <Card style={{ gap: 10 }}>
          <Text variant="section">{farm.name}</Text>
          {farm.location ? <Text muted>{farm.location}</Text> : null}
          {houses.map((h) => <Row key={h.name} justify="space-between" wrap><Text style={{ flexShrink: 1 }}>{h.name} · {HEAT.find((x) => x.value === h.heating)?.label}</Text><Text variant="bodyStrong">{fmtInt(parseInt(h.capacity, 10))} baş</Text></Row>)}
          <Row justify="space-between" wrap><Text variant="bodyStrong">Toplam kapasite</Text><Text variant="cardTitle">{fmtInt(total)} baş</Text></Row>
          <Text variant="caption" muted>Gün standardı: giriş günü {ageBase}. gün</Text>
        </Card>
      )}
      {error && <Notice tone="danger">{error}</Notice>}
    </Screen>
  );
}
