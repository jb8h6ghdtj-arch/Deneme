// Günlük Kayıt Ekle — referans ekran 4.
// Bağlam güvenliği: kümes rota parametresinden (houseId) gelir, dönem (flockId) veri katmanından doğrulanır.
// Form verisi kalıcı taslakta tutulur (kullanıcı|çiftlik|kümes|dönem|tarih): İlaç Seç'e gidip dönmek, uygulamayı
// arka plana atmak veya kapatmak veri kaybettirmez. Kaydedilmemiş değişiklikle çıkışta uyarı gösterilir.
import { router, useLocalSearchParams, useNavigation, usePreventRemove } from 'expo-router';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, View } from 'react-native';
import { useSaveDailyRecord, type DailyPart } from '../../src/api/mutations';
import { useActiveFlocks, useFarm } from '../../src/api/queries';
import { Icon } from '../../src/components/Icon';
import { Button, Card, ConfirmDialog, DatePickerSheet, FramedField, IconBadge, InputRow, Loading, NotFoundScreen, Notice, Screen, SelectSheet, StickyFooter, Text, TextField, Toast } from '../../src/components/ui';
import { averageWeightGrams, coalTotalKg, flockAgeDay, LIMITS } from '../../src/domain/calculations';
import { formatDate, istanbulLocalToIso, localDate } from '../../src/lib/dates';
import { errorMessage } from '../../src/lib/errors';
import { fmtGram, fmtInt, fmtNum, parseDecimal } from '../../src/lib/format';
import { newId } from '../../src/lib/uuid';
import { nav, routes } from '../../src/navigation/nav';
import { draftKey, emptyDraft, isDirty, useDrafts, type DailyDraft } from '../../src/stores/drafts';
import { useUserId } from '../../src/stores/session';
import { colors, fontFamily, spacing } from '../../src/theme';

const nowHHMM = () => new Intl.DateTimeFormat('tr-TR', { timeZone: 'Europe/Istanbul', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date());

export default function DailyRecordScreen() {
  const { houseId } = useLocalSearchParams<{ houseId: string }>();
  const flocks = useActiveFlocks();
  const farm = useFarm();
  const uid = useUserId();
  const flock = flocks.data?.find((f) => f.house_id === houseId) ?? null;
  if (flocks.isLoading || farm.isLoading) return <Screen title="Günlük Kayıt Ekle" back><Loading /></Screen>;
  if (!flock || !farm.data || !uid) {
    return <NotFoundScreen title="Günlük Kayıt Ekle" message="Bu kümes bulunamadı veya aktif bir üretim dönemi yok. Kayıt yalnızca aktif döneme girilebilir." backTo={routes.recordTab()} backLabel="Kümes Seçimine Dön" />;
  }
  // key: kümes/dönem değişince form tamamen yeniden kurulur → önceki kümenin verisi taşınmaz
  return <DailyRecordForm key={`${flock.house_id}|${flock.flock_id}`} flock={flock} farmId={farm.data.id} userId={uid} defaultBagKg={farm.data.default_coal_bag_kg} allFlocks={flocks.data ?? []} />;
}

type FlockLite = NonNullable<ReturnType<typeof useActiveFlocks>['data']>[number];

function DailyRecordForm({ flock, farmId, userId, defaultBagKg, allFlocks }: { flock: FlockLite; farmId: string; userId: string; defaultBagKg: number; allFlocks: FlockLite[] }) {
  const navigation = useNavigation();
  const save = useSaveDailyRecord();
  const today = localDate();
  const [date, setDate] = useState(today);
  const key = draftKey({ userId, farmId, houseId: flock.house_id, flockId: flock.flock_id, date });
  const draft = useDrafts((s) => s.drafts[key]);
  const { put, patch, remove } = useDrafts.getState();
  useEffect(() => { if (!useDrafts.getState().get(key)) put(key, emptyDraft({ userId, farmId, houseId: flock.house_id, flockId: flock.flock_id, date }, nowHHMM())); }, [key]); // eslint-disable-line react-hooks/exhaustive-deps
  const d: DailyDraft = draft ?? emptyDraft({ userId, farmId, houseId: flock.house_id, flockId: flock.flock_id, date }, nowHHMM());
  const set = (p: Partial<DailyDraft>) => patch(key, p);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<{ m: string; t: 'success' | 'warning' | 'danger' } | null>(null);
  const [sheet, setSheet] = useState<'house' | 'date' | 'bag' | null>(null);
  type NavAction = Parameters<typeof navigation.dispatch>[0];
  const [leaveAction, setLeaveAction] = useState<NavAction | null>(null);
  const [allowLeave, setAllowLeave] = useState(false);
  const proceed = useRef<NavAction | (() => void) | null>(null);
  const hideToast = useCallback(() => setToast(null), []);

  // Kaydedilmemiş değişiklik varken geri tuşu / iOS kaydırma / geri butonu → uyarı
  usePreventRemove(isDirty(draft) && !allowLeave, ({ data }) => setLeaveAction(data.action));
  // Engel kalktıktan SONRA (yeniden çizimde) bekleyen geçişi uygula
  useEffect(() => {
    if (!allowLeave || !proceed.current) return;
    const p = proceed.current; proceed.current = null;
    if (typeof p === 'function') p(); else navigation.dispatch(p);
  }, [allowLeave, navigation]);
  const leaveWith = (p: NavAction | (() => void)) => { proceed.current = p; setAllowLeave(true); };

  const effBagKg = d.bagKg ?? String(defaultBagKg).replace('.', ',');
  const age = flockAgeDay(flock.placement_date, date, flock.age_base);
  const wPreview = useMemo(() => { const v = parseDecimal(d.weight); return v ? averageWeightGrams(v, d.wUnit, 'average', 1) : null; }, [d.weight, d.wUnit]);
  const m = colors.module;

  const build = (): DailyPart[] | null => {
    const e: Record<string, string> = {};
    const parts: DailyPart[] = [];
    const ids = { ...d.ids };
    const idFor = (k: string) => (ids[k] ??= newId());
    const H = flock.house_name;
    if (d.deaths.trim() !== '') {
      const n = Number(d.deaths);
      if (!Number.isInteger(n) || n < 0) e.deaths = 'Tam sayı girin (ölüm yoksa 0)';
      else if (n > flock.alive_count) e.deaths = `Mevcut hayvan sayısını (${fmtInt(flock.alive_count)} baş) aşamaz`;
      else parts.push({ kind: 'mortality', clientId: idFor('mortality'), fields: { count: n, note: d.note.trim() || null }, label: `${H}: ${n} baş ölüm` });
    }
    if (flock.coal_tracking && d.bags.trim() !== '') {
      const b = parseDecimal(d.bags), kg = parseDecimal(effBagKg);
      if (b == null || b < 0 || b > LIMITS.bagsMax) e.bags = 'Geçerli torba sayısı girin';
      else if (!kg || kg <= 0 || kg > LIMITS.bagKgMax) e.bags = 'Torba ağırlığı 0–100 kg olmalı';
      else parts.push({ kind: 'coal', clientId: idFor('coal'), fields: { bag_count: b, bag_weight_kg: kg }, label: `${H}: ${fmtNum(b, 1)} torba kömür` });
    }
    d.meds.forEach((x) => {
      const a = parseDecimal(x.amount);
      if (!a || a <= 0) e.meds = `${x.name} için uygulanan miktarı girin (İlaç Seç ekranında)`;
      else parts.push({ kind: 'medication', clientId: idFor(`med-${x.productId}`), label: `${H}: ${x.name}`,
        fields: { product_id: x.productId, amount: a, unit: x.unit, method: x.method, vet_instruction_ref: x.vetRef.trim() || null, withdrawal_days: x.withdrawalDays } });
    });
    if (d.weight.trim() !== '') {
      const s = parseInt(d.sample, 10);
      if (wPreview == null) e.weight = 'Geçerli ağırlık girin';
      else if (wPreview < LIMITS.weightGramsMin || wPreview > LIMITS.weightGramsMax) e.weight = `${fmtGram(wPreview)} mantıksız görünüyor; birimi (kg / g) kontrol edin`;
      else if (!s || s < 1 || s > 10000) e.sample = 'Tartılan hayvan sayısını girin';
      else parts.push({ kind: 'weight', clientId: idFor('weight'), label: `${H}: tartım ${fmtGram(wPreview)}`, fields: { sample_count: s, input_mode: 'average', input_value: parseDecimal(d.weight), input_unit: d.wUnit } });
    }
    if (d.temp.trim() !== '') {
      const t = parseDecimal(d.temp);
      if (t == null || t < LIMITS.tempMin || t > LIMITS.tempMax) e.temp = `${LIMITS.tempMin} ile ${LIMITS.tempMax} °C arasında olmalı`;
      else if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(d.time)) e.temp = 'Saat SS:DD biçiminde olmalı';
      else {
        const at = istanbulLocalToIso(date, d.time);
        if (new Date(at).getTime() > Date.now() + 5 * 60_000) e.temp = 'İleri saat girilemez';
        else parts.push({ kind: 'temperature', clientId: idFor('temperature'), fields: { temperature_c: t, measured_at: at }, label: `${H}: ${fmtNum(t, 1)} °C` });
      }
    }
    if (d.note.trim() && d.deaths.trim() === '') parts.push({ kind: 'note', clientId: idFor('note'), fields: { body: d.note.trim() }, label: `${H}: not` });
    set({ ids }); // işlem kimlikleri taslağa yazılır: tekrar basışta aynı kimlikler kullanılır
    setErrors(e);
    if (Object.keys(e).length) return null;
    if (!parts.length) { setToast({ m: 'Kaydedilecek bir değer girin.', t: 'warning' }); return null; }
    return parts;
  };

  const submit = async () => {
    if (busy) return; // çift gönderim yok
    const parts = build(); if (!parts) return;
    setBusy(true);
    const r = await save({ flockId: flock.flock_id, entryDate: date }, parts);
    setBusy(false);
    if (!r.ok) return setToast({ m: errorMessage(r.error), t: 'danger' });
    remove(key);
    setToast({ m: r.duplicate ? 'Bu kayıt zaten kaydedilmişti.' : `✓ Başarıyla kaydedildi (${parts.length} kayıt)`, t: r.duplicate ? 'warning' : 'success' });
    setTimeout(() => leaveWith(() => nav.back(routes.house(flock.house_id))), 900);
  };

  const switchHouse = (newHouse: string) => {
    if (newHouse === flock.house_id) return;
    // Mevcut kümenin taslağı kendi anahtarında kalır; yeni kümenin formu kendi taslağıyla açılır
    router.setParams({ houseId: newHouse });
  };

  return (
    <Screen title="Günlük Kayıt Ekle" back footer={<StickyFooter><Button title="Kaydet" icon="check" loading={busy} onPress={submit} /></StickyFooter>}>
      <Card style={{ gap: spacing.md }}>
        <FramedField label="Kümes" value={flock.house_name} sub={flock.name} onPress={() => setSheet('house')} />
        <FramedField label="Tarih" value={formatDate(date, { day: 'numeric', month: 'short', year: 'numeric' })} sub={`(Sürü Yaşı: ${age}. gün)`} trailing="calendar" onPress={() => setSheet('date')} />
      </Card>

      <Card style={{ gap: spacing.md }}>
        <InputRow icon="heart" fg={m.mortality.fg} bg={m.mortality.bg} label="Günlük Ölüm (baş)" value={d.deaths} onChangeText={(s) => set({ deaths: s.replace(/\D/g, '') })} keyboardType="number-pad" error={errors.deaths} />
        <Text variant="caption" muted style={{ marginTop: -6, marginLeft: 52 }}>Ölüm yoksa 0 girin; boş bırakılan gün “kayıt yok” sayılır.</Text>
        {flock.coal_tracking ? (
          <>
            <InputRow icon="coal" fg={m.coal.fg} bg={m.coal.bg} label="Kömür Kullanımı (torba)" value={d.bags} onChangeText={(s) => set({ bags: s })} error={errors.bags} />
            <Pressable onPress={() => setSheet('bag')} hitSlop={6} accessibilityRole="button" accessibilityLabel="Torba ağırlığını değiştir" style={{ marginTop: -6, marginLeft: 52 }}>
              <Text variant="caption" muted>Torba: <Text variant="caption" color={colors.text.link}>{effBagKg} kg (değiştir)</Text>{parseDecimal(d.bags) ? ` · toplam ${fmtNum(coalTotalKg(parseDecimal(d.bags) ?? 0, parseDecimal(effBagKg) ?? 0), 1)} kg` : ''}</Text>
            </Pressable>
          </>
        ) : null}

        <Pressable onPress={() => nav.push(routes.medicationPicker({ houseId: flock.house_id, flockId: flock.flock_id, date }))} accessibilityRole="button" accessibilityLabel="Kullanılan ilaçlar"
          style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: spacing.md, padding: spacing.md, borderRadius: 10, borderWidth: 1, borderColor: errors.meds ? colors.status.danger : colors.border.default, backgroundColor: pressed ? colors.surface.secondary : colors.surface.primary })}>
          <IconBadge name="medication" fg={m.medication.fg} bg={m.medication.bg} />
          <View style={{ flex: 1 }}>
            <Text variant="body" style={{ fontFamily: fontFamily.medium, fontSize: 14 }}>Kullanılan İlaçlar</Text>
            <Text variant="bodyStrong">{d.meds.length ? `${d.meds.length} ilaç seçildi` : 'Seçilmedi'}</Text>
          </View>
          <Icon name="chevronRight" color={colors.text.secondary} />
        </Pressable>
        {errors.meds ? <Text variant="caption" color={colors.status.danger}>{errors.meds}</Text> : null}

        <InputRow icon="weight" fg={m.weight.fg} bg={m.weight.bg} label={`Ort. Canlı Ağırlık (${d.wUnit})`} value={d.weight} onChangeText={(s) => set({ weight: s })} error={errors.weight} />
        <Pressable onPress={() => set({ wUnit: d.wUnit === 'kg' ? 'g' : 'kg' })} hitSlop={6} accessibilityRole="button" accessibilityLabel="Ağırlık birimini değiştir" style={{ marginTop: -6, marginLeft: 52 }}>
          <Text variant="caption" muted>Birim: <Text variant="caption" color={colors.text.link}>{d.wUnit === 'kg' ? 'kilogram → grama geç' : 'gram → kilograma geç'}</Text></Text>
        </Pressable>
        {d.weight.trim() !== '' ? (
          <View style={{ marginLeft: 52, gap: 4 }}>
            <InputRow icon="users" fg={m.weight.fg} bg={m.weight.bg} label="Tartılan örnek sayısı" value={d.sample} onChangeText={(s) => set({ sample: s.replace(/\D/g, '') })} keyboardType="number-pad" error={errors.sample} />
            <Text variant="caption" muted>Örneklem ortalaması{wPreview ? ` = ${fmtGram(wPreview)}` : ''}; sürünün tamamının ölçümü değildir.</Text>
          </View>
        ) : null}

        <InputRow icon="temperature" fg={m.temperature.fg} bg={m.temperature.bg} label="Kümes İçi Sıcaklık (°C)" value={d.temp} onChangeText={(s) => set({ temp: s })} error={errors.temp} />
        {d.temp.trim() ? <View style={{ marginLeft: 52 }}><InputRow icon="clock" fg={m.note.fg} bg={m.note.bg} label="Ölçüm saati" value={d.time} onChangeText={(s) => set({ time: s })} keyboardType="numbers-and-punctuation" /></View> : null}
      </Card>

      <TextField label="Açıklama (opsiyonel)" value={d.note} onChangeText={(s) => set({ note: s })} multiline placeholder="Özel bir durum yok." maxLength={1000} />
      {isDirty(draft) ? <Notice icon="info">Girdiğiniz değerler taslak olarak bu cihazda saklanıyor; Kaydet'e basana kadar kayıt oluşmaz.</Notice> : null}
      <Button title="Tekil kayıt (ölüm nedeni, nem, fotoğraf…)" variant="ghost" compact onPress={() => nav.push(routes.entry('mortality', flock.house_id))} />

      <SelectSheet visible={sheet === 'house'} title="Kümes seçin" value={flock.house_id} onClose={() => setSheet(null)} onSelect={switchHouse}
        options={allFlocks.map((f) => ({ value: f.house_id, label: f.house_name, sub: `${f.name} · ${f.age_day}. gün · ${fmtInt(f.alive_count)} baş` }))} />
      <DatePickerSheet visible={sheet === 'date'} value={date} min={flock.placement_date} max={today} onSelect={setDate} onClose={() => setSheet(null)} dayLabel={(x) => `${flockAgeDay(flock.placement_date, x, flock.age_base)}.g`} />
      <SelectSheet visible={sheet === 'bag'} title="Torba ağırlığı" value={effBagKg} onClose={() => setSheet(null)} onSelect={(v) => set({ bagKg: v })}
        options={[...new Set([String(defaultBagKg).replace('.', ','), '20', '25', '30', '40', '50'])].map((v) => ({ value: v, label: `${v} kg`, sub: v === String(defaultBagKg).replace('.', ',') ? 'Çiftlik varsayılanı' : undefined }))} />
      <ConfirmDialog visible={!!leaveAction} title="Kaydedilmemiş değişiklikleriniz var" message="Çıkmak istiyor musunuz?" onDismiss={() => setLeaveAction(null)}
        actions={[
          { label: 'Düzenlemeye Devam Et', variant: 'primary', onPress: () => setLeaveAction(null) },
          { label: 'Taslağı Sakla', onPress: () => { const a = leaveAction; setLeaveAction(null); if (a) leaveWith(a); } },
          { label: 'Değişiklikleri Sil', variant: 'danger', onPress: () => { const a = leaveAction; setLeaveAction(null); remove(key); if (a) leaveWith(a); } },
        ]} />
      <Toast message={toast?.m ?? null} tone={toast?.t} onHide={hideToast} />
    </Screen>
  );
}
