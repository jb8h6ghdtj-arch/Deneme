// İlaç Ekle / Seç — referans ekran 5: arama, onay kutulu liste, "Seçilen İlaçlar" paneli, Onayla.
// Kategoriler ürün adının yerine geçmez; işletmenin kataloğundaki gerçek ürünler seçilir.
import { useLocalSearchParams } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Pressable, View } from 'react-native';
import { useActiveFlocks, useActiveOrg, useFarm, useMedicationProducts } from '../../src/api/queries';
import { Button, Card, Checkbox, Divider, EmptyState, Loading, NotFoundScreen, Notice, PillTabs, Row, Screen, SearchField, StickyFooter, Text, TextField } from '../../src/components/ui';
import { MED_METHODS, MED_UNITS } from '../../src/domain/types';
import { CATEGORY_TR, METHOD_TR, UNIT_TR } from '../../src/features/medications/labels';
import { nav, routes } from '../../src/navigation/nav';
import { draftKey, emptyDraft, useDrafts, type DraftMedication } from '../../src/stores/drafts';
import { useUserId } from '../../src/stores/session';
import { colors, fontFamily, radius, spacing } from '../../src/theme';

export default function MedicationPicker() {
  // Bağlam rota parametrelerinden gelir ve doğrulanır: seçim yalnızca bu kümenin/dönemin/tarihin taslağına yazılır
  const p = useLocalSearchParams<{ houseId: string; flockId: string; date: string }>();
  const flocks = useActiveFlocks();
  const farm = useFarm();
  const uid = useUserId();
  const flock = flocks.data?.find((f) => f.flock_id === p.flockId && f.house_id === p.houseId);
  if (flocks.isLoading || farm.isLoading) return <Screen title="İlaç Ekle / Seç" back><Loading /></Screen>;
  if (!flock || !farm.data || !uid || !p.date) return <NotFoundScreen title="İlaç Ekle / Seç" message="Kayıt formunun kümesi veya dönemi bulunamadı." backTo={routes.recordTab()} backLabel="Kayıt Ekle'ye Dön" />;
  return <Picker draftK={draftKey({ userId: uid, farmId: farm.data.id, houseId: flock.house_id, flockId: flock.flock_id, date: p.date })} ctx={{ userId: uid, farmId: farm.data.id, houseId: flock.house_id, flockId: flock.flock_id, date: p.date }} houseName={flock.house_name} />;
}

function Picker({ draftK, ctx, houseName }: { draftK: string; ctx: Parameters<typeof emptyDraft>[0]; houseName: string }) {
  const products = useMedicationProducts();
  const { role } = useActiveOrg();
  const initial = useDrafts.getState().get(draftK)?.meds ?? [];
  const [sel, setSel] = useState<DraftMedication[]>(initial);
  const confirm = () => {
    const st = useDrafts.getState();
    if (!st.get(draftK)) st.put(draftK, emptyDraft(ctx, '12:00'));
    st.patch(draftK, { meds: sel });
    nav.back(routes.dailyRecord(ctx.houseId));
  };
  const [q, setQ] = useState('');
  const list = useMemo(() => (products.data ?? []).filter((p) => p.is_active && (`${p.name} ${CATEGORY_TR[p.category] ?? ''} ${p.active_ingredient ?? ''}`).toLocaleLowerCase('tr').includes(q.toLocaleLowerCase('tr'))), [products.data, q]);
  const toggle = (id: string) => {
    const p = products.data!.find((x) => x.id === id)!;
    setSel(sel.some((s) => s.productId === id) ? sel.filter((s) => s.productId !== id)
      : [...sel, { productId: p.id, name: p.name, category: p.category, amount: '', unit: p.default_unit, method: p.default_method, vetRef: '', withdrawalDays: p.withdrawal_days }]);
  };
  const patch = (id: string, d: Partial<DraftMedication>) => setSel(sel.map((s) => (s.productId === id ? { ...s, ...d } : s)));

  return (
    <Screen title="İlaç Ekle / Seç" back footer={<StickyFooter><Button title="Onayla" icon="check" onPress={confirm} /></StickyFooter>}>
      <Text variant="caption" muted>{houseName} · {ctx.date.split('-').reverse().join('.')} tarihli günlük kayıt</Text>
      <SearchField value={q} onChangeText={setQ} placeholder="İlaç ara…" />
      {products.isLoading ? <Loading /> : !products.data?.length ? (
        <EmptyState icon="medication" title="İlaç listesi boş" body="Sahip veya sorumlu, Ayarlar → İlaç Listesi bölümünden işletmenin kullandığı ürünleri eklemelidir."
          action={role !== 'worker' ? <Button title="İlaç Listesine Git" variant="secondary" compact onPress={() => nav.push(routes.settings('medications'))} /> : undefined} />
      ) : (
        <Card padded={false}>
          {list.map((p, i) => {
            const s = sel.find((x) => x.productId === p.id);
            return (
              <View key={p.id}>
                {i > 0 && <Divider inset={spacing.lg} />}
                <Pressable onPress={() => toggle(p.id)} accessibilityRole="checkbox" accessibilityState={{ checked: !!s }} accessibilityLabel={`${p.name}, ${CATEGORY_TR[p.category]}`}
                  style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingHorizontal: spacing.lg, paddingVertical: 13, backgroundColor: pressed ? colors.surface.secondary : 'transparent' })}>
                  <Checkbox checked={!!s} />
                  <View style={{ flex: 1 }}>
                    <Text variant="bodyStrong" style={{ fontSize: 15 }}>{p.name} <Text variant="body" muted>({CATEGORY_TR[p.category]})</Text></Text>
                    {p.withdrawal_days ? <Text variant="caption" muted>Kesim öncesi bekleme: {p.withdrawal_days} gün</Text> : null}
                  </View>
                </Pressable>
                {s ? (
                  <View style={{ paddingHorizontal: spacing.lg, paddingBottom: spacing.md, gap: spacing.sm, marginLeft: 34 }}>
                    <Row gap={spacing.sm} align="flex-start">
                      <View style={{ flex: 1 }}><TextField label="Uygulanan miktar" value={s.amount} onChangeText={(v) => patch(p.id, { amount: v })} keyboardType="decimal-pad" /></View>
                      <View style={{ flex: 1.3, gap: 6 }}>
                        <Text variant="label" muted>Birim</Text>
                        <PillTabs value={s.unit} onChange={(v) => patch(p.id, { unit: v })} options={[...new Set([s.unit, ...MED_UNITS.slice(0, 3)])].slice(0, 3).map((u) => ({ value: u, label: UNIT_TR[u] }))} />
                      </View>
                    </Row>
                    <Row wrap gap={6}>
                      {MED_METHODS.slice(0, 4).map((mt) => (
                        <Pressable key={mt} onPress={() => patch(p.id, { method: s.method === mt ? null : mt })}
                          style={{ paddingHorizontal: 10, paddingVertical: 6, borderRadius: radius.pill, borderWidth: 1, borderColor: s.method === mt ? colors.brand.orange : colors.border.default, backgroundColor: s.method === mt ? colors.brand.orangeSoft : colors.surface.primary }}>
                          <Text variant="caption" color={s.method === mt ? colors.brand.orangeDark : colors.text.secondary}>{METHOD_TR[mt]}</Text>
                        </Pressable>
                      ))}
                    </Row>
                    <TextField label="Veteriner talimatı / reçete no (isteğe bağlı)" value={s.vetRef} onChangeText={(v) => patch(p.id, { vetRef: v })} />
                  </View>
                ) : null}
              </View>
            );
          })}
          {!list.length ? <View style={{ padding: spacing.lg }}><Text muted>“{q}” ile eşleşen ürün yok.</Text></View> : null}
        </Card>
      )}
      {sel.length > 0 && (
        <View style={{ backgroundColor: colors.status.infoSoft, borderRadius: radius.card, padding: spacing.lg, gap: 6 }}>
          <Text variant="cardTitle">Seçilen İlaçlar ({sel.length})</Text>
          {sel.map((s) => <Text key={s.productId} variant="body">•  {s.name} <Text variant="label" muted>({CATEGORY_TR[s.category]}){s.amount ? ` · ${s.amount} ${UNIT_TR[s.unit]}` : ' · miktar girilmedi'}</Text></Text>)}
        </View>
      )}
      <Notice>KEY PTS ilaç, doz veya tedavi önermez. Yalnızca veteriner talimatıyla yapılan uygulamaları kaydedin.</Notice>
      {role !== 'worker' ? <Button title="Listeye yeni ürün ekle" variant="ghost" compact onPress={() => nav.push(routes.settings('medications'))} /> : null}
      <Text variant="caption" muted style={{ textAlign: 'center', fontFamily: fontFamily.medium }}>Kategori yalnızca filtreleme içindir; kayıt ürün adıyla tutulur.</Text>
    </Screen>
  );
}
