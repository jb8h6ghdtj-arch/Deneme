// Uyarı Eşikleri ve Hedefler (yalnız çiftlik sahibi). Uygulama varsayılan sağlık hedefi dayatmaz.
import { useQueryClient } from '@tanstack/react-query';
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { useAlertSettings, useFarm, useTemperatureTargets, useWeightTargets } from '../../src/api/queries';
import { Button, Card, Divider, Loading, Notice, Row, Screen, SectionHeader, Text, TextField } from '../../src/components/ui';
import { errorMessage } from '../../src/lib/errors';
import { fmtInt, fmtNum, parseDecimal } from '../../src/lib/format';
import { dataClient } from '../../src/lib/data';
import { spacing } from '../../src/theme';

const F: [string, string, string][] = [
  ['daily_mortality_warn_pct', 'Günlük ölüm — dikkat eşiği', '%'], ['daily_mortality_critical_pct', 'Günlük ölüm — kritik eşiği', '%'],
  ['cumulative_warn_pct', 'Kümülatif ölüm — dikkat eşiği', '%'], ['cumulative_critical_pct', 'Kümülatif ölüm — kritik eşiği', '%'],
  ['missing_report_hour', 'Eksik rapor uyarı saati', ':00'], ['slaughter_reminder_days', 'Kesim hatırlatması (gün önce)', 'gün'],
];

export default function AlertSettingsScreen() {
  const qc = useQueryClient();
  const farm = useFarm();
  const s = useAlertSettings(farm.data?.id ?? null);
  const tt = useTemperatureTargets(farm.data?.id ?? null);
  const wt = useWeightTargets(farm.data?.id ?? null);
  const [v, setV] = useState<Record<string, string>>({});
  const [t, setT] = useState({ from: '', to: '', min: '', max: '' });
  const [w, setW] = useState({ age: '', g: '' });
  const [msg, setMsg] = useState<{ tone: 'success' | 'danger'; text: string } | null>(null);
  useEffect(() => { if (s.data) setV(Object.fromEntries(F.map(([k]) => [k, String((s.data as unknown as Record<string, number>)[k]).replace('.', ',')]))); }, [s.data]);
  if (s.isLoading || farm.isLoading) return <Screen title="Uyarı Eşikleri" back><Loading /></Screen>;
  const save = async () => {
    const patch: Record<string, number> = {};
    for (const [k, l] of F) { const n = parseDecimal(v[k] ?? ''); if (n == null || n < 0) return setMsg({ tone: 'danger', text: `${l}: geçerli bir sayı girin` }); patch[k] = n; }
    if (patch.daily_mortality_critical_pct < patch.daily_mortality_warn_pct || patch.cumulative_critical_pct < patch.cumulative_warn_pct) return setMsg({ tone: 'danger', text: 'Kritik eşik dikkat eşiğinden küçük olamaz.' });
    const { error } = await dataClient.from('alert_settings').update(patch as never).eq('farm_id', farm.data!.id);
    if (error) return setMsg({ tone: 'danger', text: errorMessage(error) });
    setMsg({ tone: 'success', text: 'Eşikler kaydedildi.' }); void qc.invalidateQueries({ queryKey: ['alertSettings'] });
  };
  const addT = async () => {
    const r = { day_from: parseInt(t.from, 10), day_to: parseInt(t.to, 10), min_c: parseDecimal(t.min), max_c: parseDecimal(t.max) };
    if (Number.isNaN(r.day_from) || Number.isNaN(r.day_to) || r.min_c == null || r.max_c == null || r.day_to < r.day_from || r.max_c <= r.min_c) return setMsg({ tone: 'danger', text: 'Sıcaklık aralığını kontrol edin (bitiş ≥ başlangıç, maks > min).' });
    const { error } = await dataClient.from('temperature_targets').insert({ ...r, farm_id: farm.data!.id, org_id: farm.data!.org_id } as never);
    if (error) return setMsg({ tone: 'danger', text: errorMessage(error) });
    setT({ from: '', to: '', min: '', max: '' }); void tt.refetch();
  };
  const addW = async () => {
    const r = { age_day: parseInt(w.age, 10), target_g: parseDecimal(w.g) };
    if (Number.isNaN(r.age_day) || !r.target_g) return setMsg({ tone: 'danger', text: 'Hedef ağırlık için gün ve gram girin.' });
    const { error } = await dataClient.from('weight_targets').upsert({ ...r, farm_id: farm.data!.id, org_id: farm.data!.org_id } as never, { onConflict: 'farm_id,age_day' });
    if (error) return setMsg({ tone: 'danger', text: errorMessage(error) });
    setW({ age: '', g: '' }); void wt.refetch();
  };
  return (
    <Screen title="Uyarı Eşikleri" back>
      <Notice>Durum etiketleri (Normal / Dikkat / Kritik) yalnızca bu eşiklere göre belirlenir; veteriner teşhisi değildir. Değerleri işletmenizin ve veterinerinizin planına göre girin.</Notice>
      <Card style={{ gap: spacing.md }}>
        {F.map(([k, l, u]) => <TextField key={k} label={l} value={v[k] ?? ''} onChangeText={(x) => setV({ ...v, [k]: x })} keyboardType="decimal-pad" suffix={u} />)}
        <Button title="Eşikleri Kaydet" icon="check" onPress={save} />
      </Card>
      {msg && <Notice tone={msg.tone}>{msg.text}</Notice>}
      <SectionHeader title="Hedef sıcaklık aralıkları" />
      <Card padded={false}>
        {!tt.data?.length ? <View style={{ padding: spacing.lg }}><Text muted>Tanımlı aralık yok — sıcaklık uyarısı üretilmez.</Text></View> : tt.data.map((x, i) => (
          <View key={x.id}>{i > 0 && <Divider inset={spacing.lg} />}
            <Row style={{ paddingHorizontal: spacing.lg, paddingVertical: 8 }} justify="space-between">
              <Text variant="bodyStrong">{x.day_from}–{x.day_to}. gün</Text><Text>{fmtNum(x.min_c, 1)}–{fmtNum(x.max_c, 1)} °C</Text>
              <Button title="Sil" variant="ghost" compact onPress={async () => { await dataClient.from('temperature_targets').delete().eq('id', x.id); void tt.refetch(); }} />
            </Row>
          </View>
        ))}
      </Card>
      <Card style={{ gap: spacing.sm }}>
        <Row gap={8}><View style={{ flex: 1 }}><TextField label="Gün (baş.)" value={t.from} onChangeText={(x) => setT({ ...t, from: x })} keyboardType="number-pad" /></View><View style={{ flex: 1 }}><TextField label="Gün (bitiş)" value={t.to} onChangeText={(x) => setT({ ...t, to: x })} keyboardType="number-pad" /></View></Row>
        <Row gap={8}><View style={{ flex: 1 }}><TextField label="Min °C" value={t.min} onChangeText={(x) => setT({ ...t, min: x })} keyboardType="decimal-pad" /></View><View style={{ flex: 1 }}><TextField label="Maks °C" value={t.max} onChangeText={(x) => setT({ ...t, max: x })} keyboardType="decimal-pad" /></View></Row>
        <Button title="Aralık Ekle" variant="secondary" compact onPress={addT} />
      </Card>
      <SectionHeader title="Hedef ağırlık eğrisi" />
      <Card padded={false}>
        {!wt.data?.length ? <View style={{ padding: spacing.lg }}><Text muted>Tanımlı hedef yok — grafiklerde yalnız ölçülen değerler gösterilir.</Text></View> : wt.data.map((x, i) => (
          <View key={x.id}>{i > 0 && <Divider inset={spacing.lg} />}
            <Row style={{ paddingHorizontal: spacing.lg, paddingVertical: 8 }} justify="space-between"><Text variant="bodyStrong">{x.age_day}. gün</Text><Text>{fmtInt(x.target_g)} g</Text>
              <Button title="Sil" variant="ghost" compact onPress={async () => { await dataClient.from('weight_targets').delete().eq('id', x.id); void wt.refetch(); }} /></Row>
          </View>
        ))}
      </Card>
      <Card style={{ gap: spacing.sm }}>
        <Row gap={8}><View style={{ flex: 1 }}><TextField label="Gün" value={w.age} onChangeText={(x) => setW({ ...w, age: x })} keyboardType="number-pad" /></View><View style={{ flex: 1 }}><TextField label="Hedef (g)" value={w.g} onChangeText={(x) => setW({ ...w, g: x })} keyboardType="decimal-pad" /></View></Row>
        <Button title="Hedef Ekle" variant="secondary" compact onPress={addW} />
        <Text variant="caption" muted>Genetik firmasının performans tablosu veya kendi hedefleriniz. Grafikte ölçülen değerlerden ayrı, kesikli çizgiyle gösterilir.</Text>
      </Card>
    </Screen>
  );
}
