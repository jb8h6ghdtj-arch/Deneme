// Veri Yönetimi: cihazdaki veriler, dışa aktarma (CSV/JSON), örnek veriyi silme, tümünü sıfırlama, hata günlüğü
import React, { useState } from 'react';
import { useActiveOrg, useAllFlocks } from '../../src/api/queries';
import { ListCard, ListRow } from '../../src/components/cards';
import { Button, Card, Notice, Screen, SectionHeader, Text } from '../../src/components/ui';
import { readErrorLog } from '../../src/lib/log';
import { shareCsv } from '../../src/lib/export';
import { dataClient } from '../../src/lib/data';
import { localClient } from '../../src/services/local/localClient';
import { useAppStatus } from '../../src/stores/appStatus';
import { ConfirmDialog } from '../../src/components/ui/ConfirmDialog';
import { nav } from '../../src/navigation/nav';
import { Share } from 'react-native';
import { colors } from '../../src/theme';

const TABLES: [string, string][] = [['mortality_entries', 'Ölüm kayıtları'], ['coal_entries', 'Kömür kayıtları'], ['medication_applications', 'İlaç uygulamaları'],
  ['weight_measurements', 'Tartımlar'], ['temperature_measurements', 'Sıcaklık ölçümleri'], ['daily_notes', 'Günlük notlar']];

export default function Backup() {
  const { orgId } = useActiveOrg();
  const flocks = useAllFlocks();
  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [ask, setAsk] = useState<'sample' | 'all' | null>(null);
  const sample = useAppStatus((x) => x.sample);
  const exportJson = async () => { const json = JSON.stringify(localClient.exportAll(), null, 1); await Share.share({ title: 'keypts-yedek.json', message: json }); };
  const showLog = async () => { const l = await readErrorLog(); setMsg(l.length ? l.slice(-5).map((e) => `${e.at} · ${e.where}: ${e.message}`).join('\n') : 'Hata günlüğü boş.'); };
  const exportTable = async (t: string, label: string) => {
    setBusy(t); setMsg(null);
    const { data, error } = await dataClient.from(t).select('*').eq('org_id', orgId!).is('deleted_at', null).order('entry_date');
    setBusy(null);
    if (error) return setMsg(error.message);
    const rows = (data ?? []) as Record<string, unknown>[];
    if (!rows.length) return setMsg(`${label}: dışa aktarılacak kayıt yok.`);
    const headers = Object.keys(rows[0]);
    await shareCsv(`keypts-${t}`, headers, rows.map((r) => headers.map((h) => (typeof r[h] === 'object' && r[h] !== null ? JSON.stringify(r[h]) : (r[h] as string | number | null)))));
  };
  return (
    <Screen title="Veri Yönetimi" back>
      <Card style={{ gap: 6 }}>
        <Text variant="cardTitle">Veriler bu cihazda</Text>
        <Text muted>Tüm kayıtlar yalnızca bu telefonda (yerel veritabanı) tutulur; sunucuya gönderilmez. Telefon kaybolursa veya uygulama silinirse veriler de silinir — düzenli olarak dışa aktarın.</Text>
      </Card>
      <SectionHeader title="Dışa aktar (CSV)" />
      <ListCard>
        <ListRow icon="list" fg={colors.brand.navy} title="Üretim dönemleri" subtitle={`${flocks.data?.length ?? 0} dönem`} onPress={() => void shareCsv('keypts-donemler', ['Kümes', 'Dönem', 'Durum', 'Giriş', 'Başlangıç', 'Toplam ölüm', 'Kümülatif %', 'Planlanan kesim'],
          (flocks.data ?? []).map((f) => [f.house_name, f.name, f.status, f.placement_date, f.initial_count, f.total_deaths, f.cumulative_mortality_pct, f.expected_slaughter_date]))} />
        {TABLES.map(([t, l]) => <ListRow key={t} icon="download" fg={colors.brand.navy} title={l} subtitle={busy === t ? 'Hazırlanıyor…' : undefined} onPress={() => void exportTable(t, l)} />)}
      </ListCard>
      {msg && <Notice>{msg}</Notice>}
      <Button title="Tam yedek (JSON) paylaş" icon="download" variant="secondary" onPress={() => void exportJson()} />
      <Button title="Hata günlüğünü göster" variant="secondary" onPress={() => void showLog()} />
      {sample ? <Button title="Örnek verileri sil" variant="secondary" onPress={() => setAsk('sample')} /> : null}
      <Button title="Tüm verileri sıfırla" variant="danger" onPress={() => setAsk('all')} />
      <ConfirmDialog visible={ask !== null} title={ask === 'all' ? 'Tüm veriler silinsin mi?' : 'Örnek veriler silinsin mi?'}
        message={ask === 'all' ? 'Hesap, çiftlik ve tüm kayıtlar bu cihazdan kalıcı olarak silinir. Geri alınamaz.' : 'Örnek çiftlik ve kayıtları silinir; kuruluma dönersiniz.'}
        onDismiss={() => setAsk(null)}
        actions={[{ label: 'Vazgeç', variant: 'secondary', onPress: () => setAsk(null) },
          { label: 'Sil', variant: 'danger', onPress: () => void (async () => { const a = ask; setAsk(null); if (a === 'all') { await localClient.resetAll(); nav.resetTo('/onboarding'); } else { await localClient.clearSampleData(); nav.resetTo('/onboarding'); } })() }]} />
    </Screen>
  );
}
