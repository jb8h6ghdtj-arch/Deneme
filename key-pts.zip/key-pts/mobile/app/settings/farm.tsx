// Çiftlik Bilgileri: ad, konum, iletişim, gün standardı, civciv dönemi, torba ağırlığı, kümes kapasiteleri
import { useQueryClient } from '@tanstack/react-query';
import { nav, routes, type ModuleKind, type SingleEntryKind } from '../../src/navigation/nav';
import { router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { useActiveOrg, useFarm, useHouses } from '../../src/api/queries';
import { ListCard, ListRow } from '../../src/components/cards';
import { Button, Card, Notice, PillTabs, Screen, SectionHeader, StickyFooter, TextField } from '../../src/components/ui';
import { errorMessage } from '../../src/lib/errors';
import { fmtInt, fmtNum, parseDecimal } from '../../src/lib/format';
import { dataClient } from '../../src/lib/data';
import { colors } from '../../src/theme';

export default function FarmInfo() {
  const qc = useQueryClient();
  const { role } = useActiveOrg();
  const farm = useFarm();
  const houses = useHouses();
  const owner = role === 'owner';
  const [v, setV] = useState({ name: '', location: '', contact: '', phone: '', chick: '15', bag: '25', base: '0' as '0' | '1' });
  const [msg, setMsg] = useState<{ tone: 'success' | 'danger'; text: string } | null>(null);
  useEffect(() => { const f = farm.data; if (f) setV({ name: f.name, location: f.location_text ?? '', contact: f.contact_name ?? '', phone: f.contact_phone ?? '', chick: String(f.chick_phase_days), bag: fmtNum(f.default_coal_bag_kg, 2), base: String(f.age_base) as '0' | '1' }); }, [farm.data]);
  const save = async () => {
    const chick = parseInt(v.chick, 10), bag = parseDecimal(v.bag);
    if (v.name.trim().length < 2 || !chick || chick > 60 || !bag || bag > 100) return setMsg({ tone: 'danger', text: 'Alanları kontrol edin.' });
    const { error } = await dataClient.from('farms').update({ name: v.name.trim(), location_text: v.location.trim() || null, contact_name: v.contact.trim() || null, contact_phone: v.phone.trim() || null,
      chick_phase_days: chick, default_coal_bag_kg: bag, age_base: Number(v.base) } as never).eq('id', farm.data!.id);
    if (error) return setMsg({ tone: 'danger', text: errorMessage(error) });
    setMsg({ tone: 'success', text: 'Çiftlik bilgileri kaydedildi.' }); void qc.invalidateQueries();
  };
  return (
    <Screen title="Çiftlik Bilgileri" back footer={owner ? <StickyFooter><Button title="Kaydet" icon="check" onPress={save} /></StickyFooter> : undefined}>
      <Card style={{ gap: 12 }}>
        <TextField label="Çiftlik adı" value={v.name} onChangeText={(x) => setV({ ...v, name: x })} editable={owner} />
        <TextField label="Konum" value={v.location} onChangeText={(x) => setV({ ...v, location: x })} editable={owner} />
        <TextField label="Yetkili" value={v.contact} onChangeText={(x) => setV({ ...v, contact: x })} editable={owner} />
        <TextField label="Telefon" value={v.phone} onChangeText={(x) => setV({ ...v, phone: x })} keyboardType="phone-pad" editable={owner} />
      </Card>
      <SectionHeader title="Üretim standartları" />
      <Card style={{ gap: 12 }}>
        <PillTabs value={v.base} onChange={(x) => owner && setV({ ...v, base: x })} options={[{ value: '0', label: 'Giriş günü = 0. Gün' }, { value: '1', label: 'Giriş günü = 1. Gün' }]} />
        <TextField label="Civciv dönemi (ilk kaç gün)" value={v.chick} onChangeText={(x) => setV({ ...v, chick: x })} keyboardType="number-pad" suffix="gün" hint="Bu bir yönetim sınıflandırmasıdır, veteriner teşhisi değildir." editable={owner} />
        <TextField label="Varsayılan kömür torbası" value={v.bag} onChangeText={(x) => setV({ ...v, bag: x })} keyboardType="decimal-pad" suffix="kg" editable={owner} />
      </Card>
      {msg && <Notice tone={msg.tone}>{msg.text}</Notice>}
      <SectionHeader title="Kümesler" action={owner ? 'Kümes Ekle' : undefined} onAction={() => nav.push(routes.newHouse())} />
      <ListCard>
        {(houses.data ?? []).map((h) => <ListRow key={h.id} icon="house" fg={colors.text.secondary} title={h.name} subtitle={`Kapasite ${fmtInt(h.capacity)} · ${h.coal_tracking ? 'kömür takibi açık' : 'kömür takibi kapalı'}`} onPress={() => nav.push(routes.house(h.id))} />)}
      </ListCard>
    </Screen>
  );
}
