// İlaç Listesi (işletmenin ürün kataloğu). Doz önerisi içermez.
import React, { useState } from 'react';
import { useActiveOrg, useMedicationProducts } from '../../src/api/queries';
import { Button, Card, FramedField, Notice, PillTabs, Row, Screen, SectionHeader, SelectSheet, Switch, Text, TextField } from '../../src/components/ui';
import { MED_CATEGORIES } from '../../src/domain/types';
import { errorMessage } from '../../src/lib/errors';
import { dataClient } from '../../src/lib/data';
import { CATEGORY_TR } from '../../src/features/medications/labels';
import { spacing } from '../../src/theme';

export default function MedicationCatalog() {
  const { orgId } = useActiveOrg();
  const products = useMedicationProducts();
  const [name, setName] = useState('');
  const [cat, setCat] = useState<string>('other');
  const [unit, setUnit] = useState('ml');
  const [wd, setWd] = useState('0');
  const [sheet, setSheet] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const add = async () => {
    setError(null);
    const w = parseInt(wd, 10);
    if (!name.trim()) return setError('Ürün adını girin.');
    if (Number.isNaN(w) || w < 0 || w > 365) return setError('Bekleme süresi 0–365 gün olmalı.');
    const { error: e } = await dataClient.from('medication_products').insert({ org_id: orgId, name: name.trim(), category: cat, default_unit: unit, withdrawal_days: w } as never);
    if (e) return setError(e.message.includes('org_name') ? 'Bu isimde bir ürün zaten var.' : errorMessage(e));
    setName(''); setWd('0'); void products.refetch();
  };
  return (
    <Screen title="İlaç Listesi" back>
      <Notice>Katalog yalnızca ürün adı, kategori, birim ve kesim öncesi bekleme süresini tutar. KEY PTS doz veya tedavi önermez.</Notice>
      <SectionHeader title="Yeni ürün" />
      <Card style={{ gap: spacing.md }}>
        <TextField label="Ürün adı (ticari ad)" value={name} onChangeText={setName} />
        <FramedField label="Kategori" value={CATEGORY_TR[cat]} onPress={() => setSheet(true)} />
        <Text variant="label" muted>Varsayılan birim</Text>
        <PillTabs value={unit} onChange={setUnit} options={[{ value: 'ml', label: 'ml' }, { value: 'g', label: 'g' }, { value: 'l', label: 'litre' }, { value: 'dose', label: 'doz' }]} />
        <TextField label="Kesim öncesi bekleme süresi" value={wd} onChangeText={setWd} keyboardType="number-pad" suffix="gün" hint="Ürün etiketi veya veteriner talimatındaki değeri girin." />
        {error && <Notice tone="danger">{error}</Notice>}
        <Button title="Listeye Ekle" icon="plus" onPress={add} />
      </Card>
      <SectionHeader title={`Katalog (${products.data?.length ?? 0})`} />
      {products.data?.map((p) => (
        <Card key={p.id} style={{ gap: 4 }}>
          <Row justify="space-between"><Text variant="cardTitle">{p.name}</Text><Text variant="caption" muted>{CATEGORY_TR[p.category]}</Text></Row>
          <Text variant="caption" muted>{p.withdrawal_days ? `Bekleme ${p.withdrawal_days} gün` : 'Bekleme süresi yok'} · {p.default_unit}</Text>
          <Switch label="Seçim listesinde göster" value={p.is_active} onChange={async (v) => { await dataClient.from('medication_products').update({ is_active: v } as never).eq('id', p.id); void products.refetch(); }} />
        </Card>
      ))}
      <SelectSheet visible={sheet} title="Kategori" value={cat} onClose={() => setSheet(false)} onSelect={setCat} options={MED_CATEGORIES.map((c) => ({ value: c, label: CATEGORY_TR[c] }))} />
    </Screen>
  );
}
