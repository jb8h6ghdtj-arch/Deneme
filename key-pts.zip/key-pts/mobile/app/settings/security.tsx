import React, { useState } from 'react';
import { Button, Card, Notice, Screen, SectionHeader, Text, TextField } from '../../src/components/ui';
import { errorMessage } from '../../src/lib/errors';
import { dataClient } from '../../src/lib/data';
import { useSignOut } from '../../src/features/auth/useSignOut';

export default function Security() {
  const [pw, setPw] = useState(''); const [pw2, setPw2] = useState('');
  const [msg, setMsg] = useState<{ tone: 'success' | 'danger'; text: string } | null>(null);
  const signOut = useSignOut();
  const change = async () => {
    if (pw.length < 8) return setMsg({ tone: 'danger', text: 'Şifre en az 8 karakter olmalı.' });
    if (pw !== pw2) return setMsg({ tone: 'danger', text: 'Şifreler eşleşmiyor.' });
    const { error } = await dataClient.auth.updateUser({ password: pw });
    setMsg(error ? { tone: 'danger', text: errorMessage(error) } : { tone: 'success', text: 'Şifreniz güncellendi.' });
    if (!error) { setPw(''); setPw2(''); }
  };
  return (
    <Screen title="Güvenlik" back>
      <SectionHeader title="Şifre değiştir" />
      <Card style={{ gap: 12 }}>
        <TextField label="Yeni şifre" value={pw} onChangeText={setPw} secureTextEntry />
        <TextField label="Yeni şifre (tekrar)" value={pw2} onChangeText={setPw2} secureTextEntry />
        {msg && <Notice tone={msg.tone}>{msg.text}</Notice>}
        <Button title="Şifreyi Güncelle" icon="lock" onPress={change} />
      </Card>
      <SectionHeader title="Oturum" />
      <Card style={{ gap: 8 }}>
        <Text muted>Oturum belirteci cihazın şifreli deposunda (iOS Keychain / Android Keystore) tutulur. Çıkışta cihazdaki veri önbelleği silinir; gönderilmemiş kayıtlar uyarı ile korunur.</Text>
        <Button title="Bu Cihazda Çıkış Yap" variant="danger" onPress={() => void signOut()} />
      </Card>
    </Screen>
  );
}
