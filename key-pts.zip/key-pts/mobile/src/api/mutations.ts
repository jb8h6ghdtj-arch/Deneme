// Yazma işlemleri. Her kayıt benzersiz bir işlem kimliği (client_id) taşır: aynı kayıt iki kez
// gönderilirse (çift dokunma) veri katmanı ikinci kopyayı oluşturmaz.
import { useCallback } from 'react';
import { File, Paths } from 'expo-file-system';
import { Platform } from 'react-native';
import { ENTRY_TABLE, type EntryKind } from '../domain/types';
import { dataClient } from '../lib/data';
import { newId } from '../lib/uuid';

export type SaveResult = { status: 'saved'; id: string } | { status: 'duplicate'; id: string } | { status: 'failed'; id: string; error: string };

export function useRecordEntry() {
  return useCallback(async (kind: EntryKind, ctx: { flockId: string; houseId: string; entryDate: string; clientId?: string }, fields: Record<string, unknown>): Promise<SaveResult> => {
    const clientId = ctx.clientId ?? newId();
    const { data, error } = await dataClient.rpc('save_daily_record', { parts: [{ table: ENTRY_TABLE[kind], row: { client_id: clientId, flock_id: ctx.flockId, entry_date: ctx.entryDate, recorded_at: new Date().toISOString(), ...fields } }] });
    if (error) return { status: 'failed', id: clientId, error: error.message };
    return { status: (data as { duplicate: boolean }[])[0]?.duplicate ? 'duplicate' : 'saved', id: clientId };
  }, []);
}

export interface DailyPart { kind: EntryKind; clientId: string; fields: Record<string, unknown>; label: string }
/** Günlük kayıt formu: bütün modüller tek işlemde (ya hepsi ya hiçbiri) kaydedilir. */
export function useSaveDailyRecord() {
  return useCallback(async (ctx: { flockId: string; entryDate: string }, parts: DailyPart[]) => {
    const { data, error } = await dataClient.rpc('save_daily_record', {
      parts: parts.map((p) => ({ table: ENTRY_TABLE[p.kind], row: { client_id: p.clientId, flock_id: ctx.flockId, entry_date: ctx.entryDate, recorded_at: new Date().toISOString(), ...p.fields } })),
    });
    if (error) return { ok: false as const, error: error.message };
    const dup = (data as { duplicate: boolean }[]).every((d) => d.duplicate);
    return { ok: true as const, duplicate: dup };
  }, []);
}

/** Düzeltme: sürüm kontrollü. Kayıt bu sırada başka bir ekranda değiştiyse "çakışma" döner. */
export function useEditEntry() {
  return useCallback(async (kind: EntryKind, id: string, version: number, patch: Record<string, unknown>) => {
    const { data, error } = await dataClient.from(ENTRY_TABLE[kind]).update(patch).eq('id', id).eq('version', version);
    if (error) return { status: 'failed' as const, error: error.message };
    return { status: (data as unknown[]).length ? ('saved' as const) : ('conflict' as const) };
  }, []);
}

/** Fotoğrafı uygulamanın kalıcı belge klasörüne kopyalar (cihaz içinde kalır). */
export async function storeEntryPhoto(uri: string): Promise<string> {
  if (Platform.OS === 'web') return uri;
  const dest = new File(Paths.document, `photo-${newId()}.jpg`);
  new File(uri).copy(dest);
  return dest.uri;
}
