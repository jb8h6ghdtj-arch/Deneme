// Okumalar: TanStack Query + veri katmanı (şu an cihaz içi SQLite). Her yazmadan sonra bütün sorgular yenilenir.
import { useQuery, type QueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { dataClient } from '../lib/data';
import { useSession, useUserId } from '../stores/session';
import type {
  ActivityRow, AlertSettings, AppNotification, AppRole, Farm, FlockDay, FlockOverview, House,
  MedicationProduct, Membership, TemperatureTarget, WeightTarget,
} from '../domain/types';

async function unwrap<T>(p: PromiseLike<{ data: unknown; error: { message: string } | null }>): Promise<T> {
  const { data, error } = await p;
  if (error) throw error;
  return data as T;
}

export const qk = {
  memberships: (uid: string | null) => ['memberships', uid] as const,
  farms: (org: string | null) => ['farms', org] as const,
  houses: (org: string | null) => ['houses', org] as const,
  overview: (org: string | null) => ['overview', org] as const,
  flockDaily: (flock: string | null) => ['flockDaily', flock] as const,
  activity: (filter: object) => ['activity', filter] as const,
  products: (org: string | null) => ['products', org] as const,
  alerts: (farm: string | null) => ['alertSettings', farm] as const,
  targets: (farm: string | null) => ['targets', farm] as const,
  notifications: (uid: string | null) => ['notifications', uid] as const,
  members: (org: string | null) => ['members', org] as const,
  assignments: (org: string | null) => ['assignments', org] as const,
  profiles: (org: string | null) => ['profiles', org] as const,
  flockHistory: (house: string | null) => ['flockHistory', house] as const,
};

export function useMemberships() {
  const uid = useUserId();
  return useQuery({
    queryKey: qk.memberships(uid),
    enabled: !!uid,
    queryFn: () => unwrap<Membership[]>(
      dataClient.from('organization_members').select('org_id,user_id,role,organizations(id,name)').eq('user_id', uid!),
    ),
  });
}

/** Aktif organizasyon ve kullanıcının oradaki rolü */
export function useActiveOrg(): { orgId: string | null; role: AppRole | null; orgName: string | null; loading: boolean; memberships: Membership[] } {
  const { data, isLoading } = useMemberships();
  const activeOrgId = useSession((s) => s.activeOrgId);
  const setActiveOrg = useSession((s) => s.setActiveOrg);
  const current = data?.find((m) => m.org_id === activeOrgId) ?? data?.[0] ?? null;
  useEffect(() => {
    if (current && current.org_id !== activeOrgId) setActiveOrg(current.org_id);
  }, [current, activeOrgId, setActiveOrg]);
  return { orgId: current?.org_id ?? null, role: current?.role ?? null, orgName: current?.organizations?.name ?? null, loading: isLoading, memberships: data ?? [] };
}

export function useFarm() {
  const { orgId } = useActiveOrg();
  return useQuery({
    queryKey: qk.farms(orgId),
    enabled: !!orgId,
    queryFn: async () => (await unwrap<Farm[]>(dataClient.from('farms').select('*').eq('org_id', orgId!).order('created_at')))[0] ?? null,
  });
}

export function useHouses() {
  const { orgId } = useActiveOrg();
  return useQuery({
    queryKey: qk.houses(orgId),
    enabled: !!orgId,
    queryFn: () => unwrap<House[]>(dataClient.from('houses').select('*').eq('org_id', orgId!).is('archived_at', null).order('sort_order')),
  });
}

/** Aktif dönemler — dashboard ve kümes kartları */
export function useActiveFlocks() {
  const { orgId } = useActiveOrg();
  return useQuery({
    queryKey: qk.overview(orgId),
    enabled: !!orgId,
    queryFn: () => unwrap<FlockOverview[]>(
      dataClient.from('v_flock_overview').select('*').eq('org_id', orgId!).eq('status', 'active').order('sort_order'),
    ),
  });
}

export function useFlock(flockId: string | null) {
  return useQuery({
    queryKey: ['flock', flockId],
    enabled: !!flockId,
    queryFn: () => unwrap<FlockOverview>(dataClient.from('v_flock_overview').select('*').eq('flock_id', flockId!).single()),
  });
}

export function useFlockHistory(houseId: string | null) {
  return useQuery({
    queryKey: qk.flockHistory(houseId),
    enabled: !!houseId,
    queryFn: () => unwrap<FlockOverview[]>(
      dataClient.from('v_flock_overview').select('*').eq('house_id', houseId!).order('cycle_no', { ascending: false }),
    ),
  });
}

export function useFlockDaily(flockId: string | null) {
  return useQuery({
    queryKey: qk.flockDaily(flockId),
    enabled: !!flockId,
    queryFn: () => unwrap<FlockDay[]>(dataClient.from('v_flock_daily').select('*').eq('flock_id', flockId!).order('day')),
  });
}

/** Birden fazla dönemin günlük verisi (raporlar, karşılaştırma) */
export function useFlocksDaily(flockIds: string[], from?: string) {
  return useQuery({
    queryKey: ['flocksDaily', flockIds, from],
    enabled: flockIds.length > 0,
    queryFn: () => {
      let q = dataClient.from('v_flock_daily').select('*').in('flock_id', flockIds).order('day');
      if (from) q = q.gte('day', from);
      return unwrap<FlockDay[]>(q);
    },
  });
}

export function useActivity(filter: { orgId: string | null; flockId?: string; kind?: string; limit?: number }) {
  return useQuery({
    queryKey: qk.activity(filter),
    enabled: !!filter.orgId,
    queryFn: () => {
      let q = dataClient.from('v_activity').select('*').eq('org_id', filter.orgId!).order('created_at', { ascending: false }).limit(filter.limit ?? 100);
      if (filter.flockId) q = q.eq('flock_id', filter.flockId);
      if (filter.kind) q = q.eq('kind', filter.kind);
      return unwrap<ActivityRow[]>(q);
    },
  });
}

export function useEntries<T>(table: string, flockId: string | null, order = 'entry_date') {
  return useQuery({
    queryKey: ['entries', table, flockId],
    enabled: !!flockId,
    queryFn: () => unwrap<T[]>(
      dataClient.from(table).select('*').eq('flock_id', flockId!).is('deleted_at', null)
        .order(order, { ascending: false }).order('created_at', { ascending: false }),
    ),
  });
}

export function useMedicationProducts() {
  const { orgId } = useActiveOrg();
  return useQuery({
    queryKey: qk.products(orgId),
    enabled: !!orgId,
    queryFn: () => unwrap<MedicationProduct[]>(dataClient.from('medication_products').select('*').eq('org_id', orgId!).order('name')),
  });
}

export function useAlertSettings(farmId: string | null) {
  return useQuery({
    queryKey: qk.alerts(farmId),
    enabled: !!farmId,
    queryFn: () => unwrap<AlertSettings | null>(dataClient.from('alert_settings').select('*').eq('farm_id', farmId!).maybeSingle()),
  });
}

export function useTemperatureTargets(farmId: string | null) {
  return useQuery({
    queryKey: qk.targets(farmId),
    enabled: !!farmId,
    queryFn: () => unwrap<TemperatureTarget[]>(dataClient.from('temperature_targets').select('*').eq('farm_id', farmId!).order('day_from')),
  });
}

export function useNotifications() {
  const uid = useUserId();
  return useQuery({
    queryKey: qk.notifications(uid),
    enabled: !!uid,
    queryFn: () => unwrap<AppNotification[]>(
      dataClient.from('notifications').select('*').eq('user_id', uid!).order('created_at', { ascending: false }).limit(100),
    ),
  });
}

export interface MemberRow { id: string; user_id: string; role: AppRole; profiles?: { full_name: string | null; phone: string | null } | null }
export function useMembers() {
  const { orgId } = useActiveOrg();
  return useQuery({
    queryKey: qk.members(orgId),
    enabled: !!orgId,
    queryFn: async () => {
      const members = await unwrap<{ id: string; user_id: string; role: AppRole }[]>(
        dataClient.from('organization_members').select('id,user_id,role').eq('org_id', orgId!),
      );
      const profiles = await unwrap<{ id: string; full_name: string | null; phone: string | null }[]>(
        dataClient.from('profiles').select('id,full_name,phone').in('id', members.map((m) => m.user_id)),
      );
      return members.map<MemberRow>((m) => ({ ...m, profiles: profiles.find((p) => p.id === m.user_id) ?? null }));
    },
  });
}

/** Kullanıcı kimliği → ad (işlem geçmişinde "kaydeden" alanı) */
export function useProfileNames() {
  const { data } = useMembers();
  const map = new Map<string, string>();
  data?.forEach((m) => map.set(m.user_id, m.profiles?.full_name || 'Kullanıcı'));
  return map;
}

export function invalidateOperational(qc: QueryClient) {
  ['overview', 'flockDaily', 'flock', 'flocksDaily', 'entries', 'activity', 'flockHistory', 'allFlocks'].forEach((k) => void qc.invalidateQueries({ queryKey: [k] }));
}

export function useWeightTargets(farmId: string | null) {
  return useQuery({
    queryKey: ['weightTargets', farmId],
    enabled: !!farmId,
    queryFn: () => unwrap<WeightTarget[]>(dataClient.from('weight_targets').select('*').eq('farm_id', farmId!).order('age_day')),
  });
}

/** Tüm dönemler (aktif + arşiv) — Sürü Yönetimi, rapor sürü seçici */
export function useAllFlocks() {
  const { orgId } = useActiveOrg();
  return useQuery({
    queryKey: ['allFlocks', orgId],
    enabled: !!orgId,
    queryFn: () => unwrap<FlockOverview[]>(dataClient.from('v_flock_overview').select('*').eq('org_id', orgId!).order('placement_date', { ascending: false })),
  });
}
