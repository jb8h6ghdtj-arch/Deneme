// Lucide (ISC lisansı) tabanlı tutarlı çizgisel ikon sistemi. Tek tek içe aktarılır (paket boyutu).
import React from 'react';
import ArrowLeft from 'lucide-react-native/icons/arrow-left';
import Bell from 'lucide-react-native/icons/bell';
import Bird from 'lucide-react-native/icons/bird';
import Building from 'lucide-react-native/icons/building';
import CalendarDays from 'lucide-react-native/icons/calendar-days';
import ChartColumn from 'lucide-react-native/icons/chart-column';
import Check from 'lucide-react-native/icons/check';
import ChevronDown from 'lucide-react-native/icons/chevron-down';
import ChevronRight from 'lucide-react-native/icons/chevron-right';
import CircleCheck from 'lucide-react-native/icons/circle-check';
import Clock from 'lucide-react-native/icons/clock';
import CloudOff from 'lucide-react-native/icons/cloud-off';
import CloudUpload from 'lucide-react-native/icons/cloud-upload';
import Database from 'lucide-react-native/icons/database';
import Download from 'lucide-react-native/icons/download';
import Eye from 'lucide-react-native/icons/eye';
import EyeOff from 'lucide-react-native/icons/eye-off';
import FileText from 'lucide-react-native/icons/file-text';
import Flag from 'lucide-react-native/icons/flag';
import Flame from 'lucide-react-native/icons/flame';
import Heart from 'lucide-react-native/icons/heart';
import HeartPulse from 'lucide-react-native/icons/heart-pulse';
import House from 'lucide-react-native/icons/house';
import Info from 'lucide-react-native/icons/info';
import KeyRound from 'lucide-react-native/icons/key-round';
import ListChecks from 'lucide-react-native/icons/list-checks';
import Lock from 'lucide-react-native/icons/lock';
import LogOut from 'lucide-react-native/icons/log-out';
import Mail from 'lucide-react-native/icons/mail';
import Pill from 'lucide-react-native/icons/pill';
import PillBottle from 'lucide-react-native/icons/pill-bottle';
import Plus from 'lucide-react-native/icons/plus';
import RefreshCw from 'lucide-react-native/icons/refresh-cw';
import RotateCcw from 'lucide-react-native/icons/rotate-ccw';
import Scale from 'lucide-react-native/icons/scale';
import Search from 'lucide-react-native/icons/search';
import Settings from 'lucide-react-native/icons/settings';
import ShieldCheck from 'lucide-react-native/icons/shield-check';
import StickyNote from 'lucide-react-native/icons/sticky-note';
import Thermometer from 'lucide-react-native/icons/thermometer';
import User from 'lucide-react-native/icons/user';
import UserRound from 'lucide-react-native/icons/user-round';
import Users from 'lucide-react-native/icons/users';
import Warehouse from 'lucide-react-native/icons/warehouse';
import Activity from 'lucide-react-native/icons/activity';

const MAP = {
  back: ArrowLeft, bell: Bell, bird: Bird, farm: Building, calendar: CalendarDays, chart: ChartColumn, check: Check,
  chevronDown: ChevronDown, chevronRight: ChevronRight, success: CircleCheck, clock: Clock, offline: CloudOff,
  upload: CloudUpload, backup: Database, download: Download, eye: Eye, eyeOff: EyeOff, file: FileText, flag: Flag,
  coal: Flame, heart: Heart, mortality: HeartPulse, home: House, info: Info, key: KeyRound, list: ListChecks,
  lock: Lock, logout: LogOut, mail: Mail, medication: PillBottle, pill: Pill, plus: Plus, refresh: RefreshCw,
  history: RotateCcw, weight: Scale, search: Search, settings: Settings, security: ShieldCheck, note: StickyNote,
  temperature: Thermometer, user: User, profile: UserRound, users: Users, house: Warehouse, trend: Activity,
} as const;

export type IconName = keyof typeof MAP;

export function Icon({ name, size = 20, color = '#172536', strokeWidth = 2 }: { name: IconName; size?: number; color?: string; strokeWidth?: number }) {
  const C = MAP[name] as React.ComponentType<{ size?: number; color?: string; strokeWidth?: number }>;
  return <C size={size} color={color} strokeWidth={strokeWidth} />;
}
