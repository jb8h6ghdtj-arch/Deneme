import React from 'react';
import { View } from 'react-native';
import { useAppStatus } from '../../stores/appStatus';
import { colors, fontFamily } from '../../theme';
import { Text } from '../ui/primitives';

/** Örnek veriler yüklüyken her başlıkta görünür; örnek veri gerçek kayıt gibi sunulmaz. */
export function DemoBadge() {
  const sample = useAppStatus((s) => s.sample);
  if (!sample) return null;
  return (
    <View style={{ paddingHorizontal: 7, paddingVertical: 2, borderRadius: 6, backgroundColor: colors.brand.orange }} accessibilityLabel="Örnek veri">
      <Text allowFontScaling={false} style={{ fontFamily: fontFamily.bold, fontSize: 10, letterSpacing: 0.6 }} color="#fff">ÖRNEK</Text>
    </View>
  );
}
