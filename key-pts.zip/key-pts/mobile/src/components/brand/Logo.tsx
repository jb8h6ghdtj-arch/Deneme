// KEY PTS marka bileşenleri — horoz başı + klasik kasa anahtarı.
// Geometri assets/branding/build_logo.py ile birebir aynıdır. Bütün ekranlar YALNIZCA bu bileşenleri kullanır.
// En-boy oranı her zaman korunur: genişlik verilir, yükseklik viewBox oranından hesaplanır.
import React from 'react';
import { View } from 'react-native';
import Svg, { Circle, Defs, G, LinearGradient, Path, Stop } from 'react-native-svg';
import { colors, fontFamily } from '../../theme';
import { Text } from '../ui/primitives';

const C = { navy: colors.brand.navy, orange: '#F07D1E', orangeD: colors.brand.orangeDark, gold: colors.brand.gold, red: colors.brand.red };

interface SymbolProps {
  width?: number;
  /** Koyu zeminde halka beyaz olur */
  onDark?: boolean;
  /** compact: kısa anahtar gövdesi (uygulama ikonu, başlık) */
  compact?: boolean;
  /** Tek renk (beyaz) sürüm */
  mono?: boolean;
}

/** Sembol: halka horoz başını çevreler, gaga anahtar gövdesine bağlanır, gövde ucunda kasa dişleri. */
export function KeyPTSLogoSymbol({ width = 120, onDark, compact, mono }: SymbolProps) {
  const end = compact ? 180 : 228;
  const vbW = compact ? 184 : 240;
  const height = (width * 134) / vbW;
  const id = React.useId().replace(/[^a-zA-Z0-9]/g, '');
  const ring = mono || onDark ? '#FFFFFF' : C.navy;
  const f = (c: string) => (mono ? '#FFFFFF' : c);
  const b0 = end - 34;
  return (
    <Svg width={width} height={height} viewBox={`0 -6 ${vbW} 134`} accessibilityLabel="KEY PTS">
      <Defs>
        <LinearGradient id={`sh${id}`} x1="0" y1="0" x2="1" y2="0"><Stop offset="0" stopColor={C.gold} /><Stop offset="0.35" stopColor={C.orange} /><Stop offset="1" stopColor={C.orangeD} /></LinearGradient>
        <LinearGradient id={`cb${id}`} x1="0" y1="0" x2="0" y2="1"><Stop offset="0" stopColor="#F26A2E" /><Stop offset="1" stopColor={C.red} /></LinearGradient>
        <LinearGradient id={`fe${id}`} x1="0" y1="1" x2="1" y2="0"><Stop offset="0" stopColor={C.orangeD} /><Stop offset="1" stopColor={C.gold} /></LinearGradient>
      </Defs>
      <Path d={`M104 58 H ${end - 6} a 6 6 0 0 1 0 12 H 104 Z`} fill={mono ? '#FFFFFF' : `url(#sh${id})`} />
      <Path d={`M${b0} 70 H ${end} V 98 a 4 4 0 0 1 -4 4 H ${b0 + 24} V 90 H ${b0 + 16} V 102 H ${b0 + 8} V 94 H ${b0} Z`} fill={f(C.orangeD)} />
      <Circle cx={62} cy={66} r={47} fill="none" stroke={ring} strokeWidth={11} />
      <Path d="M27 92 C 18 76, 19 56, 29 40 C 27 58, 31 78, 47 96 C 40 99, 32 98, 27 92 Z" fill={mono ? '#FFFFFF' : `url(#fe${id})`} />
      <Path d="M44 32 C 38 20, 47 9, 56 16 C 58 5, 72 3, 74 14 C 81 7, 93 13, 88 25 C 95 27, 95 36, 86 38 L 47 40 Z" fill={mono ? '#FFFFFF' : `url(#cb${id})`} />
      <Path d="M42 48 C 47 34, 79 31, 88 49 C 93 59, 93 73, 87 83 C 80 95, 63 100, 52 95 C 41 88, 37 64, 42 48 Z"
        fill={mono ? 'none' : '#FFFFFF'} stroke={mono ? '#FFFFFF' : undefined} strokeWidth={mono ? 6 : 0} />
      <Path d="M88 54 L 110 64 L 88 74 Z" fill={f(C.gold)} />
      <Path d="M77 80 C 87 82, 89 94, 81 101 C 73 98, 71 87, 77 80 Z" fill={f(C.red)} />
      {!mono ? <G><Circle cx={71} cy={58} r={5} fill={C.navy} /><Circle cx={72.6} cy={56.4} r={1.6} fill="#FFFFFF" /></G> : null}
    </Svg>
  );
}

function Wordmark({ size, onDark, subtitle = true }: { size: number; onDark: boolean; subtitle?: boolean }) {
  return (
    <View style={{ alignItems: 'center' }}>
      {/* Gerçek metin bileşeni (görsele gömülü yazı yok); Inter ExtraBold Italic */}
      <Text allowFontScaling={false} style={{ fontFamily: fontFamily.brandItalic, fontSize: size, lineHeight: size * 1.12, letterSpacing: -0.02 * size }}>
        <Text allowFontScaling={false} style={{ fontFamily: fontFamily.brandItalic, fontSize: size }} color={onDark ? '#FFFFFF' : C.navy}>KEY </Text>
        <Text allowFontScaling={false} style={{ fontFamily: fontFamily.brandItalic, fontSize: size }} color={C.orange}>PTS</Text>
      </Text>
      {subtitle ? <Text allowFontScaling={false} style={{ fontFamily: fontFamily.medium, fontSize: size * 0.33, marginTop: -size * 0.02 }} color={onDark ? '#DCE3EA' : '#4A5563'}>Poultry Tracking System</Text> : null}
    </View>
  );
}

/** Tam kurumsal logo (dikey): giriş ve açılış ekranı. width: sembol genişliği */
export function KeyPTSLogoFull({ width = 220, onDark = true }: { width?: number; onDark?: boolean }) {
  const size = width * 0.3;
  return (
    <View style={{ alignItems: 'center' }} accessibilityRole="image" accessibilityLabel="KEY PTS — Poultry Tracking System">
      <KeyPTSLogoSymbol width={width} onDark={onDark} />
      <View style={{ marginTop: size * 0.18 }}><Wordmark size={size} onDark={onDark} /></View>
    </View>
  );
}
export const KeyPTSLogoOnDark = (p: { width?: number }) => <KeyPTSLogoFull {...p} onDark />;
export const KeyPTSLogoOnLight = (p: { width?: number }) => <KeyPTSLogoFull {...p} onDark={false} />;

/** Kompakt yatay logo: üst menüler. height: satır yüksekliği */
export function KeyPTSLogoCompact({ height = 30, onDark = true }: { height?: number; onDark?: boolean }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: height * 0.25 }} accessibilityRole="image" accessibilityLabel="KEY PTS">
      <KeyPTSLogoSymbol width={height * 1.45} compact onDark={onDark} />
      <Text allowFontScaling={false} style={{ fontFamily: fontFamily.brandItalic, fontSize: height * 0.62, letterSpacing: -0.2 }}>
        <Text allowFontScaling={false} style={{ fontFamily: fontFamily.brandItalic, fontSize: height * 0.62 }} color={onDark ? '#FFFFFF' : C.navy}>KEY </Text>
        <Text allowFontScaling={false} style={{ fontFamily: fontFamily.brandItalic, fontSize: height * 0.62 }} color={C.orange}>PTS</Text>
      </Text>
    </View>
  );
}

// Geriye dönük adlar (eski ekranlar) — yeni kodda KeyPTSLogo* kullanın
export const LogoFull = ({ size = 1, dark = true }: { size?: number; dark?: boolean }) => <KeyPTSLogoFull width={200 * size} onDark={dark} />;
export const LogoHeader = () => <KeyPTSLogoCompact />;
export const RoosterMark = ({ width = 120 }: { width?: number }) => <KeyPTSLogoSymbol width={width} compact />;
