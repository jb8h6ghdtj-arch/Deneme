// Giriş ekranının alt bölümü: perspektifli kümes içi sahnesi (vektör, lisans gerektirmez).
// Lisanslı gerçek bir fotoğraf kullanmak için: <PoultryHouseScene photo={require('../../../assets/images/login-hero.jpg')} />
import { LinearGradient } from 'expo-linear-gradient';
import React, { useMemo, useState } from 'react';
import { Image, View, type ImageSourcePropType } from 'react-native';
import Svg, { Circle, Defs, Ellipse, G, Line, LinearGradient as SvgLG, Path, RadialGradient, Rect, Stop } from 'react-native-svg';
import { colors } from '../../theme';

function rnd(seed: number) { return () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }; }

export function PoultryHouseScene({ height = 300, photo }: { height?: number; photo?: ImageSourcePropType }) {
  const [w, setW] = useState(0);
  const H = height;
  const scene = useMemo(() => {
    if (!w) return null;
    const r = rnd(7);
    const vx = w * 0.56, vy = H * 0.34; // kaçış noktası
    const floorY = H * 0.5;
    const lights: React.ReactNode[] = [];
    // tavan ışık sıraları
    [-0.9, -0.35, 0.25, 0.85].forEach((lane, li) => {
      for (let i = 0; i < 12; i++) {
        const t = Math.pow(i / 12, 1.7);
        const x = vx + (lane * w * 0.9) * (1 - t);
        const y = vy - (H * 0.34) * (1 - t);
        const s = 1 + (1 - t) * 4.5;
        lights.push(<G key={`l${li}-${i}`}><Circle cx={x} cy={y} r={s * 2.6} fill="url(#glow)" /><Ellipse cx={x} cy={y} rx={s * 1.6} ry={s * 0.7} fill="#FFF3D6" /></G>);
      }
    });
    // tavan kirişleri
    const beams: React.ReactNode[] = [];
    for (let i = 0; i < 10; i++) {
      const t = Math.pow(i / 10, 1.6);
      const y = vy - H * 0.34 * (1 - t);
      beams.push(<Line key={`b${i}`} x1={vx - w * 1.2 * (1 - t)} y1={y + 6 * (1 - t)} x2={vx + w * 1.2 * (1 - t)} y2={y + 6 * (1 - t)} stroke="#3A4C63" strokeWidth={0.6 + (1 - t) * 1.4} opacity={0.7} />);
    }
    // direkler
    for (let i = 0; i < 6; i++) {
      const t = Math.pow(i / 6, 1.6);
      [-1, 1].forEach((side) => {
        const x = vx + side * w * 0.55 * (1 - t);
        beams.push(<Line key={`p${i}${side}`} x1={x} y1={vy - H * 0.2 * (1 - t)} x2={x} y2={floorY + H * 0.5 * (1 - t)} stroke="#4C5D72" strokeWidth={0.8 + (1 - t) * 2.5} opacity={0.6} />);
      });
    }
    // piliçler (zemin, perspektifle küçülen beyaz/krem noktalar) ve sarı yemlikler
    const birds: React.ReactNode[] = [];
    for (let i = 0; i < 900; i++) {
      const t = Math.pow(r(), 0.55);            // 0 uzak, 1 yakın
      const y = floorY + (H - floorY) * t;
      const spread = 0.15 + t * 1.6;
      const x = vx + (r() - 0.5) * w * spread;
      const s = 0.8 + t * 6;
      const shade = 225 + Math.round(r() * 30);
      birds.push(<Ellipse key={`c${i}`} cx={x} cy={y} rx={s * 1.25} ry={s * 0.8} fill={`rgb(${shade},${shade - 8},${shade - 22})`} opacity={0.95} />);
    }
    const feeders: React.ReactNode[] = [];
    [-0.42, 0.05, 0.5].forEach((lane, li) => {
      for (let i = 0; i < 9; i++) {
        const t = Math.pow((i + 1) / 9, 1.2);
        const y = floorY + (H - floorY) * t;
        const x = vx + lane * w * (0.15 + t * 1.6);
        const s = 1.5 + t * 9;
        feeders.push(<G key={`f${li}-${i}`}><Line x1={x} y1={y - s * 4} x2={x} y2={y - s * 0.8} stroke="#8C7A3C" strokeWidth={Math.max(0.5, s * 0.12)} /><Ellipse cx={x} cy={y} rx={s * 1.8} ry={s * 0.6} fill="#F2B705" /><Ellipse cx={x} cy={y - s * 0.3} rx={s * 1.1} ry={s * 0.35} fill="#D79C00" /></G>);
      }
    });
    return { lights, beams, birds, feeders, vx, vy, floorY };
  }, [w, H]);

  return (
    <View style={{ height: H, overflow: 'hidden' }} onLayout={(e) => setW(e.nativeEvent.layout.width)} accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
      {photo ? <Image source={photo} style={{ width: '100%', height: '100%' }} resizeMode="cover" /> : scene && (
        <Svg width={w} height={H}>
          <Defs>
            <SvgLG id="ceil" x1="0" y1="0" x2="0" y2="1"><Stop offset="0" stopColor="#0E1E33" /><Stop offset="1" stopColor="#2A3A50" /></SvgLG>
            <SvgLG id="floor" x1="0" y1="0" x2="0" y2="1"><Stop offset="0" stopColor="#6C6250" /><Stop offset="1" stopColor="#B9A98A" /></SvgLG>
            <RadialGradient id="glow" cx="50%" cy="50%" r="50%"><Stop offset="0" stopColor="#FFE6A8" stopOpacity="0.55" /><Stop offset="1" stopColor="#FFE6A8" stopOpacity="0" /></RadialGradient>
            <RadialGradient id="haze" cx="56%" cy="45%" r="60%"><Stop offset="0" stopColor="#F4D9A0" stopOpacity="0.35" /><Stop offset="1" stopColor="#F4D9A0" stopOpacity="0" /></RadialGradient>
          </Defs>
          <Rect width={w} height={scene.floorY} fill="url(#ceil)" />
          <Path d={`M0 ${scene.floorY} L${w} ${scene.floorY} L${w} ${H} L0 ${H} Z`} fill="url(#floor)" />
          {scene.beams}{scene.lights}{scene.birds}{scene.feeders}
          <Rect width={w} height={H} fill="url(#haze)" />
        </Svg>
      )}
      {/* Üstteki içerik okunabilir kalsın diye lacivert geçiş */}
      <LinearGradient colors={[colors.brand.navyDeep, 'rgba(11,29,51,0.55)', 'rgba(11,29,51,0.05)']} locations={[0, 0.35, 1]} style={{ position: 'absolute', left: 0, right: 0, top: 0, height: H * 0.6 }} />
    </View>
  );
}
