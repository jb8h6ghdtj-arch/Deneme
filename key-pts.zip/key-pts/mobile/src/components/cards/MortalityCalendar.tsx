// Ölüm takvimi: her günün altında ölüm sayısı; eşik aşımları renk + metinle ayrılır. Kayıt yok ≠ 0.
import React, { useMemo, useState } from 'react';
import { Pressable, View } from 'react-native';
import { addDays } from '../../domain/calculations';
import type { AlertSettings, FlockDay } from '../../domain/types';
import { formatDate } from '../../lib/dates';
import { fmtPct } from '../../lib/format';
import { colors, fontFamily, radius, spacing } from '../../theme';
import { Icon } from '../Icon';
import { Row, Text } from '../ui/primitives';

const WEEK = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];

export function MortalityCalendar({ days, thresholds, onSelect }: { days: FlockDay[]; thresholds: AlertSettings | null | undefined; onSelect?: (d: FlockDay) => void }) {
  const by = useMemo(() => new Map(days.map((d) => [d.day, d])), [days]);
  const last = days[days.length - 1]?.day ?? new Date().toISOString().slice(0, 10);
  const [month, setMonth] = useState(last.slice(0, 7));
  const first = `${month}-01`;
  const dow = (new Date(`${first}T12:00:00Z`).getUTCDay() + 6) % 7;
  const dim = new Date(Date.UTC(Number(month.slice(0, 4)), Number(month.slice(5, 7)), 0)).getUTCDate();
  const cells: (string | null)[] = [...Array(dow).fill(null), ...Array.from({ length: dim }, (_, i) => addDays(first, i))];
  const shift = (m: number) => { const d = new Date(`${first}T12:00:00Z`); d.setUTCMonth(d.getUTCMonth() + m); setMonth(d.toISOString().slice(0, 7)); };
  const tone = (d: FlockDay) => {
    const p = d.daily_mortality_pct;
    if (p == null || !thresholds) return { bg: colors.surface.tertiary, fg: colors.text.primary };
    if (p >= thresholds.daily_mortality_critical_pct) return { bg: colors.status.danger, fg: '#fff' };
    if (p >= thresholds.daily_mortality_warn_pct) return { bg: colors.status.warningSoft, fg: colors.status.warning };
    return { bg: colors.status.successSoft, fg: colors.text.primary };
  };
  return (
    <View style={{ gap: spacing.sm }}>
      <Row justify="space-between">
        <Pressable onPress={() => shift(-1)} hitSlop={10} accessibilityLabel="Önceki ay"><Icon name="back" color={colors.brand.navy} /></Pressable>
        <Text variant="cardTitle">{formatDate(first, { month: 'long', year: 'numeric' })}</Text>
        <Pressable onPress={() => shift(1)} hitSlop={10} accessibilityLabel="Sonraki ay"><Icon name="chevronRight" color={colors.brand.navy} /></Pressable>
      </Row>
      <View style={{ flexDirection: 'row' }}>{WEEK.map((w) => <Text key={w} variant="caption" muted style={{ flex: 1, textAlign: 'center' }}>{w}</Text>)}</View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        {cells.map((iso, i) => {
          const d = iso ? by.get(iso) : undefined;
          const t = d?.mortality_recorded ? tone(d) : null;
          return (
            <View key={i} style={{ width: `${100 / 7}%`, aspectRatio: 0.86, padding: 2 }}>
              {iso ? (
                <Pressable disabled={!d} onPress={() => d && onSelect?.(d)} accessibilityLabel={d ? `${formatDate(iso)}, ${d.age_day}. gün: ${d.mortality_recorded ? `${d.deaths} ölüm` : 'kayıt yok'}` : formatDate(iso)}
                  style={{ flex: 1, borderRadius: radius.sm, alignItems: 'center', justifyContent: 'center', backgroundColor: t ? t.bg : 'transparent',
                    borderWidth: d && !d.mortality_recorded ? 1.2 : 0, borderStyle: 'dashed', borderColor: colors.status.warning, opacity: d ? 1 : 0.35 }}>
                  <Text style={{ fontSize: 10, fontFamily: fontFamily.medium }} color={t ? t.fg : colors.text.muted}>{Number(iso.slice(8))}</Text>
                  {d ? <Text style={{ fontSize: 13, fontFamily: fontFamily.bold }} color={t ? t.fg : colors.status.warning}>{d.mortality_recorded ? d.deaths : '–'}</Text> : null}
                  {d ? <Text style={{ fontSize: 8.5, fontFamily: fontFamily.medium }} color={t ? t.fg : colors.text.muted}>{d.age_day}.g</Text> : null}
                </Pressable>
              ) : null}
            </View>
          );
        })}
      </View>
      <Row wrap gap={spacing.md}>
        {[[colors.status.successSoft, 'Normal'], [colors.status.warningSoft, `Dikkat ≥ ${fmtPct(thresholds?.daily_mortality_warn_pct, 3)}`], [colors.status.danger, `Kritik ≥ ${fmtPct(thresholds?.daily_mortality_critical_pct, 3)}`]].map(([c, l]) => (
          <Row key={l} gap={6}><View style={{ width: 12, height: 12, borderRadius: 3, backgroundColor: c }} /><Text variant="caption" muted>{l}</Text></Row>
        ))}
        <Row gap={6}><View style={{ width: 12, height: 12, borderRadius: 3, borderWidth: 1.2, borderStyle: 'dashed', borderColor: colors.status.warning }} /><Text variant="caption" muted>Kayıt yok</Text></Row>
      </Row>
    </View>
  );
}
