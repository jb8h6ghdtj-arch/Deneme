import React from 'react';
import { Pressable, View, type StyleProp, type ViewStyle } from 'react-native';
import { colors, fontFamily, radius, shadows, spacing } from '../../theme';
import { Icon, type IconName } from '../Icon';
import { useLayout } from '../../hooks/useLayout';
import { Card, Divider, IconBadge, Pill, Row, Text, type PillTone } from '../ui/primitives';

/** Dashboard KPI kartı: solda ikon, etiket, büyük değer, alt açıklama */
export function KpiTile({ icon, fg, label, value, sub, subTone, style }: {
  icon: IconName; fg: string; label: string; value: string; sub?: string; subTone?: 'danger' | 'muted' | 'warning'; style?: StyleProp<ViewStyle>;
}) {
  // Dar ekran veya büyük sistem yazısında KPI kartları tek sütuna geçer; değerler asla kırpılmaz
  const basis = useLayout().singleColumn ? '100%' : '47%';
  const subColor = subTone === 'danger' ? colors.status.danger : subTone === 'warning' ? colors.status.warning : colors.text.secondary;
  return (
    <Card style={[{ flexBasis: basis, flexGrow: 1, paddingVertical: 12, paddingHorizontal: 12 }, style]}>
      <Row gap={10} align="flex-start">
        <View style={{ paddingTop: 4 }}><Icon name={icon} color={fg} size={26} strokeWidth={2.2} /></View>
        <View style={{ flex: 1, gap: 2 }}>
          <Text variant="label" muted numberOfLines={2}>{label}</Text>
          <Text variant="kpi">{value}</Text>
          {sub ? <Text variant="caption" color={subColor}>{sub}</Text> : null}
        </View>
      </Row>
    </Card>
  );
}

/** Raporlar ekranındaki açık tonlu KPI kutusu */
export function TintedKpi({ icon, fg, bg, label, value, sub }: { icon: IconName; fg: string; bg: string; label: string; value: string; sub?: string }) {
  const basis = useLayout().singleColumn ? '100%' : '47%';
  return (
    <View style={{ flexBasis: basis, flexGrow: 1, backgroundColor: bg, borderRadius: radius.card, padding: 12, minHeight: 74 }}>
      <Row gap={10} align="flex-start">
        <View style={{ paddingTop: 4 }}><Icon name={icon} color={fg} size={24} /></View>
        <View style={{ flex: 1 }}>
          <Text variant="caption" color={colors.text.primary}>{label}</Text>
          <Text variant="kpi">{value}</Text>
          {sub ? <Text variant="caption" muted>{sub}</Text> : null}
        </View>
      </Row>
    </View>
  );
}

/** Kümes detayındaki üç sütunlu kompakt özet kutusu */
export function StatBox({ label, value, sub, tone = 'neutral' }: { label: string; value: string; sub?: string; tone?: 'neutral' | 'danger' | 'success' }) {
  const bg = tone === 'danger' ? colors.status.dangerSoft : tone === 'success' ? colors.status.successSoft : colors.surface.tertiary;
  const fg = tone === 'danger' ? colors.status.danger : tone === 'success' ? colors.status.success : colors.text.primary;
  return (
    <View style={{ flex: 1, backgroundColor: bg, borderRadius: radius.input, paddingVertical: 10, paddingHorizontal: 6, alignItems: 'center' }}>
      <Text variant="caption" muted>{label}</Text>
      <Text variant="kpi" color={fg}>{value}</Text>
      {sub ? <Text variant="caption" color={fg}>{sub}</Text> : null}
    </View>
  );
}

/** Ayarlar / kümes detayı satırı: ikon + başlık + alt açıklama + değer + ok */
export function ListRow({ icon, fg, bg, title, subtitle, value, onPress, danger, badge }: {
  icon: IconName; fg?: string; bg?: string; title: string; subtitle?: string; value?: string; onPress?: () => void; danger?: boolean; badge?: React.ReactNode;
}) {
  return (
    <Pressable onPress={onPress} disabled={!onPress} accessibilityRole={onPress ? 'button' : undefined}
      style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingVertical: 12, paddingHorizontal: spacing.lg, minHeight: 56, backgroundColor: pressed ? colors.surface.secondary : 'transparent' })}>
      {bg ? <IconBadge name={icon} fg={fg ?? colors.brand.navy} bg={bg} size={36} iconSize={19} /> : <View style={{ width: 32, alignItems: 'center' }}><Icon name={icon} color={danger ? colors.status.danger : fg ?? colors.brand.navy} size={24} /></View>}
      <View style={{ flex: 1 }}>
        <Text variant="bodyStrong" color={danger ? colors.status.danger : undefined}>{title}</Text>
        {subtitle ? <Text variant="caption" muted numberOfLines={2}>{subtitle}</Text> : null}
      </View>
      {badge}
      {value ? <Text variant="bodyStrong" style={{ fontFamily: fontFamily.bold }}>{value}</Text> : null}
      {onPress && !danger ? <Icon name="chevronRight" color={colors.text.secondary} size={18} /> : null}
    </Pressable>
  );
}

export function ListCard({ children }: { children: React.ReactNode }) {
  const items = React.Children.toArray(children).filter(Boolean);
  return (
    <View style={{ backgroundColor: colors.surface.primary, borderRadius: radius.card, borderWidth: 1, borderColor: colors.border.subtle, overflow: 'hidden', ...shadows.card }}>
      {items.map((ch, i) => <View key={i}>{i > 0 ? <Divider inset={spacing.lg} /> : null}{ch}</View>)}
    </View>
  );
}

export function StatusPill({ status }: { status: 'normal' | 'attention' | 'critical' | 'unknown' }) {
  const m: Record<string, [string, PillTone]> = { normal: ['Normal', 'success'], attention: ['Dikkat', 'warning'], critical: ['Kritik', 'danger'], unknown: ['Kayıt yok', 'neutral'] };
  return <Pill label={m[status][0]} tone={m[status][1]} />;
}
