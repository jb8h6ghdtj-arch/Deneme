// Referanstaki "Günlük Ölüm Trendi" dili: ince çizgi, yumuşak alan dolgusu, dokununca veri balonu.
// Eksik değer (null) çizgide boşluk olarak kalır; ölçümsüz güne değer çizilmez. Kesikli seri = hedef/tahmin.
import React, { useMemo, useState } from 'react';
import { View, type GestureResponderEvent, type LayoutChangeEvent } from 'react-native';
import Svg, { Circle, Defs, G, Line, LinearGradient, Path, Rect, Stop, Text as SvgText } from 'react-native-svg';
import { colors, fontFamily, radius } from '../../theme';
import { Row, Text } from '../ui/primitives';

/** connectGaps: yalnız gerçek ölçüm noktalarını birleştirir (ara günlere nokta/değer üretilmez) */
export interface ChartSeries { name: string; values: (number | null)[]; color?: string; dashed?: boolean; area?: boolean; connectGaps?: boolean }

function niceMax(v: number) {
  if (v <= 0) return 1;
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  const n = v / p;
  return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 4 ? 4 : n <= 8 ? 8 : 10) * p;
}

const PALETTE = [colors.status.danger, colors.status.info, colors.brand.orange, '#7B4FC9', colors.status.success];

export function TrendChart({ labels, series, height = 200, format = (n) => String(Math.round(n)), tooltip, minZero = true, xLabelEvery }: {
  labels: string[]; series: ChartSeries[]; height?: number; format?: (n: number) => string;
  tooltip?: (i: number, v: number, s: ChartSeries) => [string, string?]; minZero?: boolean; xLabelEvery?: number;
}) {
  const [w, setW] = useState(0);
  const [active, setActive] = useState<number | null>(null);
  const pad = { l: 40, r: 12, t: 14, b: 24 };
  const all = series.flatMap((s) => s.values.filter((v): v is number => v != null));
  const { min, max } = useMemo(() => {
    if (!all.length) return { min: 0, max: 1 };
    const lo = minZero ? 0 : Math.min(...all) * 0.95;
    return { min: lo, max: niceMax(Math.max(...all) * 1.08) };
  }, [all, minZero]);
  if (!all.length) return <Text muted variant="label">Grafik için henüz kayıtlı veri yok.</Text>;
  const iw = Math.max(1, w - pad.l - pad.r);
  const ih = height - pad.t - pad.b;
  const n = Math.max(1, labels.length - 1);
  const x = (i: number) => pad.l + (i / n) * iw;
  const y = (v: number) => pad.t + ih - ((v - min) / (max - min || 1)) * ih;
  const every = xLabelEvery ?? Math.max(1, Math.ceil(labels.length / 8));
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => min + f * (max - min));

  const segs = (vals: (number | null)[], connect?: boolean) => {
    if (connect) { const pts = vals.map((v, i) => ({ i, v })).filter((p): p is { i: number; v: number } => p.v != null); return pts.length ? [pts] : []; }
    const out: { i: number; v: number }[][] = [];
    let cur: { i: number; v: number }[] = [];
    vals.forEach((v, i) => { if (v == null) { if (cur.length) out.push(cur); cur = []; } else cur.push({ i, v }); });
    if (cur.length) out.push(cur);
    return out;
  };

  const pick = (e: GestureResponderEvent) => {
    const lx = e.nativeEvent.locationX;
    const i = Math.round(((lx - pad.l) / iw) * n);
    if (i >= 0 && i < labels.length) setActive(i);
  };
  const primary = series[0];
  const av = active != null ? primary.values[active] : null;

  return (
    <View onLayout={(e: LayoutChangeEvent) => setW(e.nativeEvent.layout.width)}
      onStartShouldSetResponder={() => true} onResponderGrant={pick} onResponderMove={pick} onResponderRelease={() => setTimeout(() => setActive(null), 1800)}
      accessible accessibilityLabel={`Grafik: ${series.map((s) => s.name).join(', ')}`}>
      {w > 0 && (
        <Svg width={w} height={height}>
          <Defs>
            {series.map((s, si) => (
              <LinearGradient key={si} id={`ar${si}`} x1="0" y1="0" x2="0" y2="1">
                <Stop offset="0" stopColor={s.color ?? PALETTE[si % PALETTE.length]} stopOpacity={0.22} />
                <Stop offset="1" stopColor={s.color ?? PALETTE[si % PALETTE.length]} stopOpacity={0} />
              </LinearGradient>
            ))}
          </Defs>
          {ticks.map((t, i) => (
            <G key={i}>
              <Line x1={pad.l} x2={w - pad.r} y1={y(t)} y2={y(t)} stroke={colors.border.subtle} strokeWidth={1} />
              <SvgText x={pad.l - 6} y={y(t) + 3.5} fontSize={10} fontFamily={fontFamily.medium} fill={colors.text.secondary} textAnchor="end">{format(t)}</SvgText>
            </G>
          ))}
          {labels.map((l, i) => (i % every === 0 || i === labels.length - 1) && (
            <SvgText key={i} x={x(i)} y={height - 6} fontSize={10} fontFamily={fontFamily.medium} fill={colors.text.secondary} textAnchor="middle">{l}</SvgText>
          ))}
          {series.map((s, si) => {
            const c = s.color ?? PALETTE[si % PALETTE.length];
            return segs(s.values, s.connectGaps).map((seg, k) => {
              const d = seg.map((p, j) => `${j ? 'L' : 'M'}${x(p.i).toFixed(1)},${y(p.v).toFixed(1)}`).join(' ');
              const area = `${d} L${x(seg[seg.length - 1].i).toFixed(1)},${y(min)} L${x(seg[0].i).toFixed(1)},${y(min)} Z`;
              return (
                <G key={`${si}-${k}`}>
                  {(s.area ?? si === 0) && !s.dashed ? <Path d={area} fill={`url(#ar${si})`} /> : null}
                  <Path d={d} stroke={c} strokeWidth={2} fill="none" strokeLinejoin="round" strokeDasharray={s.dashed ? '5 4' : undefined} />
                  {!s.dashed && seg.length < 60 ? seg.map((p) => <Circle key={p.i} cx={x(p.i)} cy={y(p.v)} r={2.6} fill={c} />) : null}
                </G>
              );
            });
          })}
          {active != null && av != null && (() => {
            const [t1, t2] = tooltip ? tooltip(active, av, primary) : [format(av), labels[active]];
            const bx = Math.min(Math.max(x(active) - 36, pad.l), w - pad.r - 72);
            const by = Math.max(y(av) - 50, 0);
            return (
              <G>
                <Line x1={x(active)} x2={x(active)} y1={pad.t} y2={pad.t + ih} stroke={colors.status.danger} strokeDasharray="3 3" strokeWidth={1} />
                <Circle cx={x(active)} cy={y(av)} r={4.5} fill="#fff" stroke={primary.color ?? PALETTE[0]} strokeWidth={2} />
                <Rect x={bx} y={by} width={72} height={t2 ? 38 : 24} rx={6} fill="#B32439" />
                <SvgText x={bx + 36} y={by + 15} fontSize={12} fontFamily={fontFamily.bold} fill="#fff" textAnchor="middle">{t1}</SvgText>
                {t2 ? <SvgText x={bx + 36} y={by + 30} fontSize={9.5} fontFamily={fontFamily.medium} fill="#FFDCDF" textAnchor="middle">{t2}</SvgText> : null}
              </G>
            );
          })()}
        </Svg>
      )}
      {series.length > 1 && (
        <Row wrap gap={12} style={{ marginTop: 6 }}>
          {series.map((s, si) => (
            <Row key={s.name} gap={6}>
              <View style={{ width: 14, height: 3, borderRadius: 2, backgroundColor: s.color ?? PALETTE[si % PALETTE.length], opacity: s.dashed ? 0.6 : 1 }} />
              <Text variant="caption" muted>{s.name}</Text>
            </Row>
          ))}
        </Row>
      )}
    </View>
  );
}

export function BarChart({ labels, values, height = 160, format = (n) => String(Math.round(n)), tone }: {
  labels: string[]; values: (number | null)[]; height?: number; format?: (n: number) => string; tone?: (v: number, i: number) => 'warning' | 'danger' | null;
}) {
  const [w, setW] = useState(0);
  const pad = { l: 36, r: 6, t: 8, b: 22 };
  const nums = values.filter((v): v is number => v != null);
  if (!nums.length) return <Text muted variant="label">Grafik için henüz kayıtlı veri yok.</Text>;
  const max = niceMax(Math.max(...nums) * 1.05);
  const iw = Math.max(1, w - pad.l - pad.r); const ih = height - pad.t - pad.b; const bw = iw / values.length;
  const every = Math.max(1, Math.ceil(labels.length / 8));
  return (
    <View onLayout={(e) => setW(e.nativeEvent.layout.width)}>
      {w > 0 && (
        <Svg width={w} height={height}>
          {[0, 0.5, 1].map((f) => (
            <G key={f}>
              <Line x1={pad.l} x2={w - pad.r} y1={pad.t + ih * (1 - f)} y2={pad.t + ih * (1 - f)} stroke={colors.border.subtle} />
              <SvgText x={pad.l - 6} y={pad.t + ih * (1 - f) + 3.5} fontSize={10} fontFamily={fontFamily.medium} fill={colors.text.secondary} textAnchor="end">{format(max * f)}</SvgText>
            </G>
          ))}
          {values.map((v, i) => {
            const bx = pad.l + i * bw + bw * 0.18;
            if (v == null) return <Rect key={i} x={bx} y={pad.t + ih - 2} width={bw * 0.64} height={2} fill={colors.border.strong} />;
            const h = (v / max) * ih; const t = tone?.(v, i);
            return <Rect key={i} x={bx} y={pad.t + ih - h} width={bw * 0.64} height={Math.max(h, 1)} rx={Math.min(3, bw * 0.2)}
              fill={t === 'danger' ? colors.status.danger : t === 'warning' ? colors.status.warning : colors.brand.navy} />;
          })}
          {labels.map((l, i) => i % every === 0 && (
            <SvgText key={i} x={pad.l + i * bw + bw / 2} y={height - 6} fontSize={10} fontFamily={fontFamily.medium} fill={colors.text.secondary} textAnchor="middle">{l}</SvgText>
          ))}
        </Svg>
      )}
      <Text variant="caption" muted style={{ marginTop: 4 }}>Gri çizgi: o gün kayıt girilmedi (sıfır değildir).</Text>
    </View>
  );
}

export const chartCardStyle = { borderRadius: radius.card };
