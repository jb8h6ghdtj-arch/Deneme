// Referanstaki ekran iskeleti: lacivert başlık + üstüne binen yuvarlak köşeli içerik yüzeyi.
import { router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { useLayout } from '../../hooks/useLayout';
import { KeyboardAvoidingView, Platform, ScrollView, View, type RefreshControlProps } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, layout, radius, spacing } from '../../theme';
import { DemoBadge } from '../brand/DemoBadge';
import { IconButton } from '../ui/buttons';
import { Row, Text } from '../ui/primitives';

export function NavyHeader({ title, back, right, children, left, extraBottom = 0 }: {
  title?: string; back?: boolean | (() => void); right?: React.ReactNode; left?: React.ReactNode; children?: React.ReactNode; extraBottom?: number;
}) {
  const insets = useSafeAreaInsets();
  return (
    <View style={{ backgroundColor: colors.brand.navy, paddingTop: insets.top, paddingBottom: layout.headerBottom + extraBottom, paddingHorizontal: layout.screenX - 4 }}>
      <StatusBar style="light" />
      <Row style={{ height: 52 }} justify="space-between">
        <View style={{ minWidth: 40 }}>
          {back ? <IconButton name="back" label="Geri" onPress={typeof back === 'function' ? back : () => (router.canGoBack() ? router.back() : router.replace('/(tabs)'))} /> : left}
        </View>
        {title ? <Text variant="title" color="#fff" numberOfLines={1} style={{ flex: 1, textAlign: 'center' }} accessibilityRole="header">{title}</Text> : <View style={{ flex: 1 }} />}
        <Row style={{ minWidth: 40 }} justify="flex-end" gap={4}><DemoBadge />{right}</Row>
      </Row>
      {children}
    </View>
  );
}

export function Screen({ title, back, right, left, header, overlap, footer, children, refreshControl, scroll = true, extraBottom }: {
  title?: string; back?: boolean | (() => void); right?: React.ReactNode; left?: React.ReactNode;
  header?: React.ReactNode;      // başlık içinde ek içerik (ör. "Merhaba, Çiftlik Genel Durumu")
  overlap?: React.ReactNode;     // başlık ile yüzeyin sınırına binen öğe (ör. aktif sürü seçici)
  footer?: React.ReactNode;      // altta sabit eylem alanı
  children: React.ReactNode; refreshControl?: React.ReactElement<RefreshControlProps>; scroll?: boolean; extraBottom?: number;
}) {
  const L = useLayout();
  // Tablet/geniş ekranda içerik ortalanır ve okunabilir genişlikte kalır
  const body = <View style={{ width: '100%', maxWidth: L.wide ? L.contentMaxWidth : undefined, alignSelf: 'center', padding: L.compact ? 12 : layout.screenX, paddingTop: overlap ? spacing.md : layout.screenX, gap: spacing.lg, paddingBottom: spacing['3xl'] }}>{children}</View>;
  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.brand.navy }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <NavyHeader title={title} back={back} right={right} left={left} extraBottom={extraBottom ?? (overlap ? 46 : 0)}>{header}</NavyHeader>
      <View style={{ flex: 1, marginTop: -layout.sheetOverlap, backgroundColor: colors.surface.secondary, borderTopLeftRadius: radius.panel, borderTopRightRadius: radius.panel, overflow: overlap ? 'visible' : 'hidden' }}>
        {overlap ? <View style={{ marginTop: -46, paddingHorizontal: layout.screenX, zIndex: 2 }}>{overlap}</View> : null}
        {scroll ? <ScrollView keyboardShouldPersistTaps="handled" refreshControl={refreshControl} showsVerticalScrollIndicator={false}>{body}</ScrollView> : <View style={{ flex: 1 }}>{body}</View>}
        {footer}
      </View>
    </KeyboardAvoidingView>
  );
}
