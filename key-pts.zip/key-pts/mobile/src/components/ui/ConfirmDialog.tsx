// Platformdan bağımsız onay penceresi (Android geri hareketi, iOS ve web'de aynı davranış).
import React from 'react';
import { Modal, Pressable, View } from 'react-native';
import { colors, radius, spacing } from '../../theme';
import { Button } from './buttons';
import { Text } from './primitives';

export interface DialogAction { label: string; onPress: () => void; variant?: 'primary' | 'secondary' | 'danger' | 'ghost' }

export function ConfirmDialog({ visible, title, message, actions, onDismiss }: { visible: boolean; title: string; message?: string; actions: DialogAction[]; onDismiss: () => void }) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onDismiss} statusBarTranslucent>
      <View style={{ flex: 1, backgroundColor: colors.overlay, justifyContent: 'center', padding: spacing['2xl'] }}>
        <Pressable style={{ position: 'absolute', inset: 0 } as never} onPress={onDismiss} accessibilityLabel="Kapat" />
        <View accessibilityRole="alert" style={{ backgroundColor: colors.surface.primary, borderRadius: radius.panel, padding: spacing.xl, gap: spacing.md, maxWidth: 420, width: '100%', alignSelf: 'center' }}>
          <Text variant="section">{title}</Text>
          {message ? <Text muted>{message}</Text> : null}
          <View style={{ gap: spacing.sm, marginTop: spacing.sm }}>
            {actions.map((a) => <Button key={a.label} title={a.label} variant={a.variant ?? 'secondary'} compact onPress={a.onPress} />)}
          </View>
        </View>
      </View>
    </Modal>
  );
}
