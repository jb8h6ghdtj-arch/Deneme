// Silinmiş / erişilemeyen kayda gidildiğinde güvenli hata ekranı
import React from 'react';
import { nav, routes } from '../../navigation/nav';
import { Screen } from '../layout/Screen';
import { Button } from './buttons';
import { EmptyState } from './feedback';

export function NotFoundScreen({ title = 'Kayıt Bulunamadı', message = 'Aradığınız kayıt silinmiş veya artık mevcut değil.', backTo = routes.home(), backLabel = 'Ana Sayfaya Dön' }: {
  title?: string; message?: string; backTo?: ReturnType<typeof routes.home>; backLabel?: string;
}) {
  return (
    <Screen title={title} back={() => nav.back(backTo)}>
      <EmptyState icon="info" title={title} body={message} action={<Button title={backLabel} variant="secondary" compact onPress={() => nav.resetTo(backTo)} />} />
    </Screen>
  );
}
