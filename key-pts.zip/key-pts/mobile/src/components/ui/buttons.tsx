import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import React from 'react';
import { ActivityIndicator, Platform, Pressable, View, type StyleProp, type ViewStyle } from 'react-native';
import { colors, layout, radius, shadows, spacing } from '../../theme';
import { Icon, type IconName } from '../Icon';
import { Text } from './primitives';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'outlineLight';

export function Button({ title, onPress, variant = 'primary', icon, loading, disabled, style, compact, pill }: {
  title: string; onPress?: () => void; variant?: Variant; icon?: IconName; loading?: boolean; disabled?: boolean;
  style?: StyleProp<ViewStyle>; compact?: boolean; pill?: boolean;
}) {
  const off = disabled || loading;
  const fg = variant === 'primary' || variant === 'danger' ? '#FFFFFF' : variant === 'secondary' ? colors.brand.navy : variant === 'outlineLight' ? '#FFFFFF' : colors.brand.orangeDark;
  const height = compact ? 42 : layout.button;
  const content = (
    <View style={{ height, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm, paddingHorizontal: spacing.lg }}>
      {loading ? <ActivityIndicator color={fg} /> : icon ? <Icon name={icon} color={fg} size={20} strokeWidth={2.4} /> : null}
      <Text variant="button" color={fg}>{title}</Text>
    </View>
  );
  return (
    <Pressable
      accessibilityRole="button" accessibilityState={{ disabled: !!off, busy: !!loading }} disabled={off}
      onPress={() => { if (Platform.OS !== 'web') void Haptics.selectionAsync().catch(() => {}); onPress?.(); }}
      style={({ pressed }) => [{ borderRadius: pill ? radius.pill : radius.button, opacity: off ? 0.55 : pressed ? 0.9 : 1, overflow: 'hidden' },
        variant === 'primary' && shadows.button,
        variant === 'secondary' && { backgroundColor: '#E9EDF5', borderWidth: 1, borderColor: colors.border.strong },
        variant === 'danger' && { backgroundColor: colors.status.danger },
        variant === 'outlineLight' && { borderWidth: 1, borderColor: 'rgba(255,255,255,0.35)' },
        style]}
    >
      {variant === 'primary'
        ? <LinearGradient colors={[colors.brand.orangeLight, colors.brand.orangeDark]} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }}>{content}</LinearGradient>
        : content}
    </Pressable>
  );
}

export function IconButton({ name, onPress, color = '#fff', label, size = 22 }: { name: IconName; onPress?: () => void; color?: string; label: string; size?: number }) {
  return (
    <Pressable onPress={onPress} hitSlop={10} accessibilityRole="button" accessibilityLabel={label}
      style={({ pressed }) => ({ width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
      <Icon name={name} color={color} size={size} />
    </Pressable>
  );
}

/** Ekran altında sabit duran eylem alanı (klavye açıkken de görünür kalır) */
export function StickyFooter({ children }: { children: React.ReactNode }) {
  return (
    <View style={{ paddingHorizontal: layout.screenX, paddingTop: spacing.md, paddingBottom: spacing.md, backgroundColor: colors.surface.secondary,
      borderTopWidth: 1, borderTopColor: colors.border.subtle }}>{children}</View>
  );
}
