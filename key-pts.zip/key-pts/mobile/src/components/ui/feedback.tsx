import React, { useEffect, useRef } from 'react';
import { ActivityIndicator, Animated, View } from 'react-native';
import { colors, radius, shadows, spacing } from '../../theme';
import { Icon, type IconName } from '../Icon';
import { Button } from './buttons';
import { Row, Text } from './primitives';

export function Loading({ label = 'Yükleniyor…' }: { label?: string }) {
  return (
    <View style={{ padding: spacing['3xl'], alignItems: 'center', gap: spacing.md }} accessibilityLiveRegion="polite">
      <ActivityIndicator color={colors.brand.orange} size="large" />
      <Text muted>{label}</Text>
    </View>
  );
}

export function EmptyState({ icon = 'info', title, body, action }: { icon?: IconName; title: string; body?: string; action?: React.ReactNode }) {
  return (
    <View style={{ padding: spacing['2xl'], alignItems: 'center', gap: spacing.md, borderRadius: radius.card, borderWidth: 1, borderStyle: 'dashed', borderColor: colors.border.strong, backgroundColor: colors.surface.primary }}>
      <View style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: colors.surface.tertiary, alignItems: 'center', justifyContent: 'center' }}>
        <Icon name={icon} color={colors.text.secondary} />
      </View>
      <Text variant="cardTitle" style={{ textAlign: 'center' }}>{title}</Text>
      {body ? <Text muted style={{ textAlign: 'center' }}>{body}</Text> : null}
      {action}
    </View>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <View style={{ padding: spacing.lg, borderRadius: radius.card, backgroundColor: colors.status.dangerSoft, gap: spacing.md }} accessibilityRole="alert">
      <Row><Icon name="info" color={colors.status.danger} /><Text variant="bodyStrong" color={colors.status.danger}>Bir sorun oluştu</Text></Row>
      <Text>{message}</Text>
      {onRetry ? <Button title="Tekrar dene" variant="secondary" compact onPress={onRetry} /> : null}
    </View>
  );
}

export function Notice({ tone = 'info', children, icon }: { tone?: 'info' | 'warning' | 'danger' | 'success' | 'orange'; children: React.ReactNode; icon?: IconName }) {
  const m = {
    info: [colors.status.info, colors.status.infoSoft], warning: [colors.status.warning, colors.status.warningSoft],
    danger: [colors.status.danger, colors.status.dangerSoft], success: [colors.status.success, colors.status.successSoft],
    orange: [colors.brand.orangeDark, colors.brand.orangeSoft],
  }[tone];
  return (
    <View style={{ flexDirection: 'row', gap: spacing.sm, padding: spacing.md, borderRadius: radius.input, backgroundColor: m[1] }}>
      <Icon name={icon ?? (tone === 'success' ? 'success' : 'info')} color={m[0]} size={18} />
      <View style={{ flex: 1 }}>{typeof children === 'string' ? <Text variant="label" color={colors.text.primary}>{children}</Text> : children}</View>
    </View>
  );
}

export function Toast({ message, tone = 'success', onHide }: { message: string | null; tone?: 'success' | 'warning' | 'danger'; onHide: () => void }) {
  const a = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!message) return;
    Animated.spring(a, { toValue: 1, useNativeDriver: true }).start();
    const t = setTimeout(() => Animated.timing(a, { toValue: 0, duration: 180, useNativeDriver: true }).start(onHide), 2600);
    return () => clearTimeout(t);
  }, [message, a, onHide]);
  if (!message) return null;
  const bg = tone === 'success' ? colors.status.success : tone === 'warning' ? colors.brand.navy : colors.status.danger;
  return (
    <Animated.View pointerEvents="none" accessibilityLiveRegion="polite" style={{ position: 'absolute', left: 16, right: 16, bottom: 96, padding: spacing.lg, borderRadius: radius.card, backgroundColor: bg, opacity: a, transform: [{ translateY: a.interpolate({ inputRange: [0, 1], outputRange: [24, 0] }) }], ...shadows.raised }}>
      <Text variant="bodyStrong" color="#fff">{message}</Text>
    </Animated.View>
  );
}
