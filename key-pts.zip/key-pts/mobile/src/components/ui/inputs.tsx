import React, { forwardRef, useMemo, useState } from 'react';
import { FlatList, Modal, Pressable, ScrollView, TextInput, View, type TextInputProps } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { addDays } from '../../domain/calculations';
import { formatDate } from '../../lib/dates';
import { colors, fontFamily, radius, spacing, typography } from '../../theme';
import { Icon, type IconName } from '../Icon';
import { Checkbox, Divider, IconBadge, Row, Text } from './primitives';
import { Button } from './buttons';

const fieldBox = (focus: boolean, error?: string) => ({
  borderWidth: 1, borderRadius: radius.input, backgroundColor: colors.surface.primary,
  borderColor: error ? colors.status.danger : focus ? colors.brand.orange : colors.border.default,
});

export const TextField = forwardRef<React.ComponentRef<typeof TextInput>, TextInputProps & { label?: string; error?: string; hint?: string; suffix?: string; icon?: IconName }>(
  function TextField({ label, error, hint, suffix, icon, style, multiline, ...rest }, ref) {
    const [focus, setFocus] = useState(false);
    return (
      <View style={{ gap: 6 }}>
        {label ? <Text variant="label" muted>{label}</Text> : null}
        <View style={[fieldBox(focus, error), { flexDirection: 'row', alignItems: multiline ? 'flex-start' : 'center', paddingHorizontal: spacing.md, gap: spacing.sm }]}>
          {icon ? <Icon name={icon} color={colors.text.muted} size={18} /> : null}
          <TextInput ref={ref} placeholderTextColor={colors.text.muted} multiline={multiline}
            onFocus={(e) => { setFocus(true); rest.onFocus?.(e); }} onBlur={(e) => { setFocus(false); rest.onBlur?.(e); }}
            style={[{ flex: 1, minHeight: multiline ? 84 : 46, paddingVertical: multiline ? 12 : 0, color: colors.text.primary, fontFamily: fontFamily.regular, fontSize: 15, textAlignVertical: multiline ? 'top' : 'center' }, style]}
            maxFontSizeMultiplier={1.4} {...rest} />
          {suffix ? <Text variant="label" muted>{suffix}</Text> : null}
        </View>
        {error ? <Text variant="caption" color={colors.status.danger}>{error}</Text> : hint ? <Text variant="caption" muted>{hint}</Text> : null}
      </View>
    );
  });

/** Referanstaki çerçeveli alan: üstte küçük etiket, içinde değer (Kümes, Tarih) */
export function FramedField({ label, value, sub, onPress, trailing = 'chevronDown', disabled }: {
  label: string; value: string; sub?: string; onPress?: () => void; trailing?: IconName; disabled?: boolean;
}) {
  return (
    <View style={{ gap: 4 }}>
      <Text variant="label" style={{ fontFamily: fontFamily.semibold }}>{label}</Text>
      <Pressable onPress={onPress} disabled={disabled} accessibilityRole="button" accessibilityLabel={`${label}: ${value}`}
        style={({ pressed }) => [fieldBox(false), { minHeight: 46, paddingHorizontal: spacing.md, flexDirection: 'row', alignItems: 'center', opacity: pressed ? 0.8 : 1 }]}>
        <Text variant="bodyStrong" style={{ flex: 1, fontFamily: fontFamily.medium }} numberOfLines={1}>
          {value}{sub ? <Text variant="label" muted>{`  ${sub}`}</Text> : null}
        </Text>
        <Icon name={trailing} color={colors.text.secondary} size={18} />
      </Pressable>
    </View>
  );
}

/** Beyaz kart görünümlü seçim kutusu (Aktif Sürü seçici, rapor sürü filtresi) */
export function SelectCard({ title, sub, onPress, elevated }: { title: string; sub?: string; onPress?: () => void; elevated?: boolean }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={title}
      style={({ pressed }) => [{
        backgroundColor: elevated ? colors.surface.primary : colors.surface.primary, borderRadius: radius.input, borderWidth: 1,
        borderColor: colors.border.default, paddingHorizontal: spacing.lg, paddingVertical: sub ? 10 : 12, flexDirection: 'row', alignItems: 'center', opacity: pressed ? 0.9 : 1,
      }, elevated && { shadowColor: '#000', shadowOpacity: 0.12, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 4 }]}>
      <View style={{ flex: 1 }}>
        <Text variant="bodyStrong" numberOfLines={1}>{title}</Text>
        {sub ? <Text variant="caption" muted numberOfLines={1}>{sub}</Text> : null}
      </View>
      <Icon name="chevronDown" color={colors.text.primary} size={18} />
    </Pressable>
  );
}

export interface Option<T extends string> { value: T; label: string; sub?: string }

/** Alttan açılan seçim listesi */
export function SelectSheet<T extends string>({ visible, title, options, value, onSelect, onClose, multi, values }: {
  visible: boolean; title: string; options: Option<T>[]; value?: T | null; onSelect: (v: T) => void; onClose: () => void; multi?: boolean; values?: T[];
}) {
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={{ flex: 1, backgroundColor: colors.overlay }} onPress={onClose} accessibilityLabel="Kapat" />
      <View style={{ backgroundColor: colors.surface.primary, borderTopLeftRadius: radius.panel, borderTopRightRadius: radius.panel, paddingBottom: insets.bottom + spacing.md, maxHeight: '70%' }}>
        <View style={{ alignItems: 'center', paddingTop: 8 }}><View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border.default }} /></View>
        <Text variant="section" style={{ padding: spacing.lg }}>{title}</Text>
        <FlatList data={options} keyExtractor={(o) => o.value} ItemSeparatorComponent={() => <Divider inset={spacing.lg} />}
          renderItem={({ item }) => {
            const on = multi ? values?.includes(item.value) : item.value === value;
            return (
              <Pressable onPress={() => { onSelect(item.value); if (!multi) onClose(); }} style={({ pressed }) => ({ paddingHorizontal: spacing.lg, paddingVertical: 14, backgroundColor: pressed ? colors.surface.secondary : 'transparent' })}>
                <Row justify="space-between">
                  <View style={{ flex: 1 }}>
                    <Text variant="bodyStrong" color={on ? colors.brand.orangeDark : undefined}>{item.label}</Text>
                    {item.sub ? <Text variant="caption" muted>{item.sub}</Text> : null}
                  </View>
                  {multi ? <Checkbox checked={!!on} /> : on ? <Icon name="check" color={colors.brand.orange} /> : null}
                </Row>
              </Pressable>
            );
          }} />
        {multi ? <View style={{ padding: spacing.lg }}><Button title="Tamam" onPress={onClose} /></View> : null}
      </View>
    </Modal>
  );
}

const WEEK = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];
/** Takvimden tarih seçimi. Aralık dışı günler pasif (ileri tarih ve giriş öncesi engellenir). */
export function DatePickerSheet({ visible, value, min, max, onSelect, onClose, title = 'Tarih seçin', dayLabel }: {
  visible: boolean; value: string; min?: string; max?: string; onSelect: (d: string) => void; onClose: () => void; title?: string; dayLabel?: (d: string) => string | null;
}) {
  const insets = useSafeAreaInsets();
  const [month, setMonth] = useState(value.slice(0, 7));
  React.useEffect(() => { if (visible) setMonth(value.slice(0, 7)); }, [visible, value]);
  const first = `${month}-01`;
  const startDow = (new Date(`${first}T12:00:00Z`).getUTCDay() + 6) % 7;
  const dim = new Date(Date.UTC(Number(month.slice(0, 4)), Number(month.slice(5, 7)), 0)).getUTCDate();
  const cells = useMemo(() => [...Array(startDow).fill(null), ...Array.from({ length: dim }, (_, i) => addDays(first, i))] as (string | null)[], [first, startDow, dim]);
  const shift = (m: number) => { const d = new Date(`${first}T12:00:00Z`); d.setUTCMonth(d.getUTCMonth() + m); setMonth(d.toISOString().slice(0, 7)); };
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={{ flex: 1, backgroundColor: colors.overlay }} onPress={onClose} />
      <View style={{ backgroundColor: colors.surface.primary, borderTopLeftRadius: radius.panel, borderTopRightRadius: radius.panel, padding: spacing.lg, paddingBottom: insets.bottom + spacing.lg, gap: spacing.md }}>
        <Text variant="section">{title}</Text>
        <Row justify="space-between">
          <Pressable onPress={() => shift(-1)} hitSlop={10} accessibilityLabel="Önceki ay"><Icon name="back" color={colors.brand.navy} /></Pressable>
          <Text variant="cardTitle">{formatDate(first, { month: 'long', year: 'numeric' })}</Text>
          <Pressable onPress={() => shift(1)} hitSlop={10} accessibilityLabel="Sonraki ay"><Icon name="chevronRight" color={colors.brand.navy} /></Pressable>
        </Row>
        <View style={{ flexDirection: 'row' }}>{WEEK.map((w) => <Text key={w} variant="caption" muted style={{ flex: 1, textAlign: 'center' }}>{w}</Text>)}</View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {cells.map((d, i) => {
            const disabled = !d || (!!min && d < min) || (!!max && d > max);
            const on = d === value;
            return (
              <View key={i} style={{ width: `${100 / 7}%`, aspectRatio: 1, padding: 3 }}>
                {d ? (
                  <Pressable disabled={disabled} onPress={() => { onSelect(d); onClose(); }} accessibilityLabel={formatDate(d)}
                    style={{ flex: 1, borderRadius: radius.sm, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? colors.brand.orange : 'transparent' }}>
                    <Text variant="bodyStrong" color={on ? '#fff' : disabled ? colors.border.strong : colors.text.primary}>{Number(d.slice(8))}</Text>
                    {dayLabel && !disabled ? <Text style={{ fontSize: 9 }} color={on ? '#fff' : colors.text.muted}>{dayLabel(d) ?? ''}</Text> : null}
                  </Pressable>
                ) : null}
              </View>
            );
          })}
        </View>
      </View>
    </Modal>
  );
}

/** İkon + etiket + sağda küçük sayı kutusu (Günlük Kayıt Ekle satırları) */
export function InputRow({ icon, fg, bg, label, value, onChangeText, keyboardType = 'decimal-pad', error, placeholder, accessory }: {
  icon: IconName; fg: string; bg: string; label: string; value: string; onChangeText: (s: string) => void;
  keyboardType?: TextInputProps['keyboardType']; error?: string; placeholder?: string; accessory?: React.ReactNode;
}) {
  const [focus, setFocus] = useState(false);
  return (
    <View style={{ gap: 4 }}>
      <Row gap={spacing.md}>
        <IconBadge name={icon} fg={fg} bg={bg} />
        <Text variant="body" style={{ flex: 1, fontFamily: fontFamily.medium, fontSize: 14 }} numberOfLines={2}>{label}</Text>
        {accessory}
        <TextInput value={value} onChangeText={onChangeText} keyboardType={keyboardType} placeholder={placeholder ?? '—'} placeholderTextColor={colors.text.muted}
          accessibilityLabel={label} selectTextOnFocus onFocus={() => setFocus(true)} onBlur={() => setFocus(false)} maxFontSizeMultiplier={1.3}
          style={[fieldBox(focus, error), { width: 92, height: 44, paddingHorizontal: spacing.md, fontFamily: fontFamily.semibold, fontSize: 16, color: colors.text.primary }]} />
      </Row>
      {error ? <Text variant="caption" color={colors.status.danger} style={{ textAlign: 'right' }}>{error}</Text> : null}
    </View>
  );
}

export function SearchField({ value, onChangeText, placeholder }: { value: string; onChangeText: (s: string) => void; placeholder: string }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm, backgroundColor: colors.surface.tertiary, borderRadius: radius.input, borderWidth: 1, borderColor: colors.border.default, paddingHorizontal: spacing.md, height: 44 }}>
      <Icon name="search" color={colors.text.secondary} size={18} />
      <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor={colors.text.muted} accessibilityLabel={placeholder}
        style={{ flex: 1, fontFamily: fontFamily.regular, fontSize: 15, color: colors.text.primary }} />
    </View>
  );
}

/** Raporlar ekranındaki hap (pill) sekmeler */
export function PillTabs<T extends string>({ options, value, onChange }: { options: { value: T; label: string }[]; value: T; onChange: (v: T) => void }) {
  return (
    <View style={{ flexDirection: 'row', backgroundColor: colors.surface.tertiary, borderRadius: radius.pill, padding: 3 }}>
      {options.map((o) => {
        const on = o.value === value;
        return (
          <Pressable key={o.value} onPress={() => onChange(o.value)} accessibilityRole="tab" accessibilityState={{ selected: on }}
            style={{ flex: 1, height: 34, borderRadius: radius.pill, alignItems: 'center', justifyContent: 'center',
              backgroundColor: on ? colors.surface.primary : 'transparent', borderWidth: on ? 1 : 0, borderColor: colors.brand.navy }}>
            <Text variant="label" numberOfLines={2} color={on ? colors.brand.navy : colors.text.secondary} style={{ fontFamily: on ? fontFamily.bold : fontFamily.medium }}>{o.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

/** Kümes detayındaki alt çizgili sekmeler */
export function UnderlineTabs<T extends string>({ options, value, onChange }: { options: { value: T; label: string }[]; value: T; onChange: (v: T) => void }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1 }}>
      <View style={{ flexDirection: 'row', flex: 1, borderBottomWidth: 1, borderBottomColor: colors.border.default }}>
        {options.map((o) => {
          const on = o.value === value;
          return (
            <Pressable key={o.value} onPress={() => onChange(o.value)} accessibilityRole="tab" accessibilityState={{ selected: on }}
              style={{ flex: 1, paddingVertical: 10, paddingHorizontal: 8, alignItems: 'center', borderBottomWidth: 2.5, borderBottomColor: on ? colors.brand.orange : 'transparent', marginBottom: -1 }}>
              <Text variant="label" numberOfLines={2} color={on ? colors.text.primary : colors.text.secondary} style={{ fontFamily: on ? fontFamily.bold : fontFamily.medium }}>{o.label}</Text>
            </Pressable>
          );
        })}
      </View>
    </ScrollView>
  );
}

export function Segmented<T extends string>({ options, value, onChange }: { options: { value: T; label: string }[]; value: T; onChange: (v: T) => void }) {
  return <PillTabs options={options} value={value} onChange={onChange} />;
}

export function Switch({ label, hint, value, onChange }: { label: string; hint?: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <Pressable onPress={() => onChange(!value)} accessibilityRole="switch" accessibilityState={{ checked: value }} style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md, minHeight: 48 }}>
      <View style={{ flex: 1 }}><Text variant="body">{label}</Text>{hint ? <Text variant="caption" muted>{hint}</Text> : null}</View>
      <View style={{ width: 46, height: 28, borderRadius: 14, backgroundColor: value ? colors.brand.orange : colors.border.strong, padding: 3, alignItems: value ? 'flex-end' : 'flex-start' }}>
        <View style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: '#fff' }} />
      </View>
    </Pressable>
  );
}

/** ± düğmeli hızlı sayı girişi (kömür torbası vb.) */
export function Stepper({ value, onChange, step = 1, min = 0, max }: { value: number; onChange: (n: number) => void; step?: number; min?: number; max?: number }) {
  const set = (n: number) => onChange(Math.max(min, max != null ? Math.min(max, n) : n));
  const btn = (d: number, label: string) => (
    <Pressable onPress={() => set(value + d)} accessibilityLabel={label} hitSlop={6}
      style={({ pressed }) => ({ width: 34, height: 34, borderRadius: radius.sm, borderWidth: 1, borderColor: colors.border.default, alignItems: 'center', justifyContent: 'center', backgroundColor: pressed ? colors.brand.orangeSoft : colors.surface.primary })}>
      <Text variant="section" color={colors.brand.orangeDark}>{d > 0 ? '+' : '−'}</Text>
    </Pressable>
  );
  return <Row gap={6}>{btn(-step, 'Azalt')}{btn(step, 'Artır')}</Row>;
}

export { typography };
