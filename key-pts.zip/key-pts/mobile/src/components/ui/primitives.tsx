import React from 'react';
import { Pressable, StyleSheet, Text as RNText, View, type StyleProp, type TextProps, type TextStyle, type ViewStyle } from 'react-native';
import { colors, radius, shadows, spacing, typography, type TypeVariant } from '../../theme';
import { Icon, type IconName } from '../Icon';

export function Text({ variant = 'body', color, muted, style, ...rest }: TextProps & { variant?: TypeVariant; color?: string; muted?: boolean }) {
  return <RNText maxFontSizeMultiplier={1.4} {...rest} style={[typography[variant], { color: color ?? (muted ? colors.text.secondary : colors.text.primary) }, style as StyleProp<TextStyle>]} />;
}

export function Row({ children, gap = spacing.sm, style, wrap, justify, align = 'center' }: {
  children: React.ReactNode; gap?: number; style?: StyleProp<ViewStyle>; wrap?: boolean;
  justify?: ViewStyle['justifyContent']; align?: ViewStyle['alignItems'];
}) {
  return <View style={[{ flexDirection: 'row', alignItems: align, gap, flexWrap: wrap ? 'wrap' : 'nowrap', justifyContent: justify }, style]}>{children}</View>;
}

export function Card({ children, style, onPress, padded = true, accessibilityLabel }: {
  children: React.ReactNode; style?: StyleProp<ViewStyle>; onPress?: () => void; padded?: boolean; accessibilityLabel?: string;
}) {
  const base: ViewStyle = {
    backgroundColor: colors.surface.primary, borderRadius: radius.card, borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border.default, padding: padded ? spacing.lg : 0, ...shadows.card,
  };
  if (!onPress) return <View style={[base, style]}>{children}</View>;
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={accessibilityLabel} onPress={onPress}
      style={({ pressed }) => [base, style, pressed && { opacity: 0.94, transform: [{ scale: 0.995 }] }]}>{children}</Pressable>
  );
}

export function Divider({ inset = 0 }: { inset?: number }) {
  return <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: colors.border.default, marginLeft: inset }} />;
}

/** Referanstaki açık tonlu kare zemin üzerinde renkli ikon */
export function IconBadge({ name, fg, bg, size = 40, iconSize = 20 }: { name: IconName; fg: string; bg: string; size?: number; iconSize?: number }) {
  return (
    <View style={{ width: size, height: size, borderRadius: radius.input, backgroundColor: bg, alignItems: 'center', justifyContent: 'center' }}>
      <Icon name={name} color={fg} size={iconSize} />
    </View>
  );
}

export type PillTone = 'success' | 'warning' | 'danger' | 'info' | 'neutral' | 'orange';
export function Pill({ label, tone = 'neutral', dot }: { label: string; tone?: PillTone; dot?: boolean }) {
  const m = {
    success: [colors.status.success, colors.status.successSoft], warning: [colors.status.warning, colors.status.warningSoft],
    danger: [colors.status.danger, colors.status.dangerSoft], info: [colors.status.info, colors.status.infoSoft],
    neutral: [colors.text.secondary, colors.surface.tertiary], orange: [colors.brand.orangeDark, colors.brand.orangeSoft],
  }[tone];
  return (
    <View style={{ paddingHorizontal: 10, paddingVertical: 4, borderRadius: radius.pill, backgroundColor: m[1], flexDirection: 'row', alignItems: 'center', gap: 5 }}>
      {dot ? <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: m[0] }} /> : null}
      <Text variant="caption" color={m[0]} style={{ fontFamily: typography.bodyStrong.fontFamily }}>{label}</Text>
    </View>
  );
}

export function Checkbox({ checked, size = 22 }: { checked: boolean; size?: number }) {
  return (
    <View style={{ width: size, height: size, borderRadius: 5, borderWidth: checked ? 0 : 1.6, borderColor: colors.border.strong,
      backgroundColor: checked ? colors.brand.orange : colors.surface.primary, alignItems: 'center', justifyContent: 'center' }}>
      {checked ? <Icon name="check" color="#fff" size={size - 6} strokeWidth={3} /> : null}
    </View>
  );
}

export function SectionHeader({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return (
    <Row justify="space-between" style={{ marginTop: spacing.sm }}>
      <Text variant="section">{title}</Text>
      {action ? (
        <Pressable onPress={onAction} hitSlop={10} accessibilityRole="link">
          <Row gap={2}><Text variant="bodyStrong" color={colors.text.link}>{action}</Text><Icon name="chevronRight" color={colors.text.link} size={16} /></Row>
        </Pressable>
      ) : null}
    </Row>
  );
}
