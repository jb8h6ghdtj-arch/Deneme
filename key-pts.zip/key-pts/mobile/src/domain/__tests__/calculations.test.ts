import {
  addDays, aliveCount, averageWeightGrams, coalTotalKg, cumulativeMortalityPct, dailyMortalityPct, evaluateStatus,
  farmWeightedAverage, flockAgeDay, flockPhase, hasWithdrawalConflict, missingMortalityDays, weightGains, withdrawalEndDate,
} from '../calculations';

const TH = { daily_mortality_warn_pct: 0.3, daily_mortality_critical_pct: 0.6, cumulative_warn_pct: 3, cumulative_critical_pct: 5 };

describe('yaş ve dönem', () => {
  it('varsayılan standart: giriş günü 0. gün; 1 tabanlı ayar desteklenir', () => {
    expect(flockAgeDay('2026-10-13', '2026-10-13')).toBe(0);
    expect(flockAgeDay('2026-10-13', '2026-11-05')).toBe(23);
    expect(flockAgeDay('2026-10-13', '2026-11-05', 1)).toBe(24);
  });
  it('ay ve yıl geçişlerinde doğru', () => {
    expect(flockAgeDay('2026-12-20', '2027-01-03')).toBe(14);
    expect(addDays('2028-02-28', 1)).toBe('2028-02-29');
  });
  it('ilk 15 gün civciv (0–14. gün), 15. günden itibaren piliç; 1 tabanlıda 16. gün', () => {
    expect(flockPhase(14)).toBe('chick');
    expect(flockPhase(15)).toBe('broiler');
    expect(flockPhase(15, 15, 1)).toBe('chick');
    expect(flockPhase(16, 15, 1)).toBe('broiler');
    expect(flockPhase(16, 20)).toBe('chick');
  });
  it('çiftlik ortalama ağırlığı: mevcut sayıyla ağırlıklı, ölçümsüz kümes dışarıda, kapsama raporlanır', () => {
    const r = farmWeightedAverage([{ avgG: 1200, alive: 30000, date: '2026-11-05' }, { avgG: 1000, alive: 10000, date: '2026-11-03' }, { avgG: null, alive: 20000, date: null }]);
    expect(r.avgG).toBe(1150);
    expect(r.measured).toBe(2); expect(r.total).toBe(3); expect(r.oldestDate).toBe('2026-11-03');
  });
});

describe('ölüm oranları', () => {
  it('günlük oran = günlük ölüm / gün başı mevcut × 100', () => {
    expect(dailyMortalityPct(18, 25000)).toBeCloseTo(0.072);
  });
  it('kayıt yoksa oran null (sıfır değil)', () => {
    expect(dailyMortalityPct(null, 25000)).toBeNull();
    expect(dailyMortalityPct(0, 25000)).toBe(0);
  });
  it('kümülatif oran = toplam ölüm / yerleştirilen × 100', () => {
    expect(cumulativeMortalityPct(450, 25000)).toBeCloseTo(1.8);
    expect(cumulativeMortalityPct(10, 0)).toBeNull();
  });
  it('mevcut sayı ölüm ve tüm hareketlerden türetilir', () => {
    expect(aliveCount({ initial: 25000, deaths: 450, birdsIn: 0, birdsOut: 0, dispatched: 0 })).toBe(24550);
    expect(aliveCount({ initial: 30000, deaths: 690, birdsIn: 200, birdsOut: 50, dispatched: 0 })).toBe(29460);
  });
  it('kayıt girilmemiş günler eksik sayılır, sıfır girilen günler sayılmaz', () => {
    expect(missingMortalityDays([
      { day: '2026-11-01', mortality_recorded: true }, { day: '2026-11-02', mortality_recorded: false }, { day: '2026-11-03', mortality_recorded: true },
    ])).toEqual(['2026-11-02']);
  });
});

describe('durum değerlendirme (eşik tabanlı, teşhis değil)', () => {
  it('eşik altı normal', () => expect(evaluateStatus({ todayDeaths: 18, startOfDayAlive: 25000, cumulativePct: 1.8, thresholds: TH })).toBe('normal'));
  it('günlük dikkat eşiği', () => expect(evaluateStatus({ todayDeaths: 80, startOfDayAlive: 25000, cumulativePct: 1, thresholds: TH })).toBe('attention'));
  it('kümülatif kritik eşik', () => expect(evaluateStatus({ todayDeaths: 5, startOfDayAlive: 25000, cumulativePct: 5.2, thresholds: TH })).toBe('critical'));
  it('bugün kayıt yoksa "kayıt bekleniyor"', () => expect(evaluateStatus({ todayDeaths: null, startOfDayAlive: 25000, cumulativePct: 1, thresholds: TH })).toBe('unknown'));
  it('eşik tanımlı değilse durum üretilmez', () => expect(evaluateStatus({ todayDeaths: 999, startOfDayAlive: 1000, cumulativePct: 50, thresholds: null })).toBe('unknown'));
  it('bekleme süresi çakışması dikkat gerektirir', () => expect(evaluateStatus({ todayDeaths: 1, startOfDayAlive: 25000, cumulativePct: 0.1, thresholds: TH, withdrawalConflict: true })).toBe('attention'));
});

describe('tartım', () => {
  it('kg → g dönüşümü ve toplamdan ortalama', () => {
    expect(averageWeightGrams(1.15, 'kg', 'average', 50)).toBe(1150);
    expect(averageWeightGrams(46, 'kg', 'total', 40)).toBe(1150);
    expect(averageWeightGrams(5500, 'g', 'total', 10)).toBe(550);
  });
  it('kazanç yalnızca gerçek ölçümler arasında hesaplanır', () => {
    const g = weightGains([{ date: '2026-11-08', avgG: 1350, sample: 50 }, { date: '2026-11-01', avgG: 550, sample: 50 }, { date: '2026-11-05', avgG: 1000, sample: 40 }]);
    expect(g.map((x) => x.date)).toEqual(['2026-11-01', '2026-11-05', '2026-11-08']);
    expect(g[0].gainSincePrevG).toBeNull();
    expect(g[1].gainSincePrevG).toBe(450);
    expect(g[1].dailyGainG).toBeCloseTo(112.5);
    expect(g[2].dailyGainG).toBeCloseTo(116.67, 1);
  });
});

describe('kömür ve ilaç', () => {
  it('torba × kg = toplam kg (torba ve kg karışmaz)', () => {
    expect(coalTotalKg(8, 25)).toBe(200);
    expect(coalTotalKg(7.5, 30)).toBe(225);
  });
  it('bekleme süresi bitişi ve kesim çakışması', () => {
    expect(withdrawalEndDate('2026-11-05', 7)).toBe('2026-11-12');
    expect(hasWithdrawalConflict('2026-11-05', 7, '2026-11-12')).toBe(true);
    expect(hasWithdrawalConflict('2026-11-05', 7, '2026-11-13')).toBe(false);
    expect(hasWithdrawalConflict('2026-11-05', 0, '2026-11-05')).toBe(false);
    expect(hasWithdrawalConflict('2026-11-05', 30, null)).toBe(false);
  });
});
