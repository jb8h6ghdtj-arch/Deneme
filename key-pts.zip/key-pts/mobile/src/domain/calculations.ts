// Saf iş kuralları. Sunucudaki hesaplamalarla aynı tanımları kullanır;
// istemcide yalnızca gösterim, önizleme ve offline geri bildirim için çalışır.
import type { AlertSettings, FlockDay, HealthStatus, WeightInputMode, WeightUnit } from './types';

const DAY_MS = 86_400_000;

/** 'YYYY-MM-DD' → UTC gece yarısı epoch (saat dilimi kaymasından bağımsız gün aritmetiği) */
export function dateToDayNumber(iso: string): number {
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  return Math.floor(Date.UTC(y, m - 1, d) / DAY_MS);
}

export function addDays(iso: string, days: number): string {
  const n = dateToDayNumber(iso) + days;
  return new Date(n * DAY_MS).toISOString().slice(0, 10);
}

export function daysBetween(fromIso: string, toIso: string): number {
  return dateToDayNumber(toIso) - dateToDayNumber(fromIso);
}

/**
 * Yetiştirme günü — tek standart: çiftlik ayarı `age_base` (0 → giriş günü "0. Gün", 1 → "1. Gün").
 * Sunucudaki public.flock_age() ile aynıdır. Varsayılan 0 (referans tasarımdaki "0. Gün — Civciv Girişi").
 */
export function flockAgeDay(placementDate: string, onDate: string, base: 0 | 1 = 0): number {
  return daysBetween(placementDate, onDate) + base;
}

/** Yaş günü → takvim tarihi */
export function dateForAge(placementDate: string, ageDay: number, base: 0 | 1 = 0): string {
  return addDays(placementDate, ageDay - base);
}

export type FlockPhase = 'chick' | 'broiler';
/** İlk N gün civciv, sonrası piliç (N çiftlik ayarı, varsayılan 15). Yönetim sınıflandırmasıdır, teşhis değildir. */
export function flockPhase(ageDay: number, chickPhaseDays = 15, base: 0 | 1 = 0): FlockPhase {
  return ageDay - base < chickPhaseDays ? 'chick' : 'broiler';
}
/** Piliç döneminin başladığı yaş günü (0 tabanlı, 15 gün → 15. gün) */
export const broilerStartAge = (chickPhaseDays = 15, base: 0 | 1 = 0) => chickPhaseDays + base;

/**
 * Çiftlik geneli ortalama canlı ağırlık. Yöntem: her kümesin SON örneklem ortalaması,
 * o kümenin mevcut hayvan sayısıyla ağırlıklandırılır. Tartımı olmayan kümeler dahil edilmez ve
 * kapsama (kaç kümes) ile en eski ölçüm tarihi birlikte döndürülür.
 */
export function farmWeightedAverage(items: { avgG: number | null; alive: number; date: string | null }[]) {
  const m = items.filter((i) => i.avgG != null && i.alive > 0);
  const birds = m.reduce((s, i) => s + i.alive, 0);
  return {
    avgG: birds ? m.reduce((s, i) => s + (i.avgG as number) * i.alive, 0) / birds : null,
    measured: m.length, total: items.length,
    oldestDate: m.map((i) => i.date!).sort()[0] ?? null,
  };
}

/** Günlük ölüm oranı = günlük ölüm / gün başı mevcut × 100. Kayıt yoksa null. */
export function dailyMortalityPct(deaths: number | null, startOfDayAlive: number): number | null {
  if (deaths == null || startOfDayAlive <= 0) return null;
  return (deaths / startOfDayAlive) * 100;
}

/** Kümülatif ölüm oranı = toplam ölüm / (başlangıç + ek girişler) × 100 */
export function cumulativeMortalityPct(totalDeaths: number, placedTotal: number): number | null {
  if (placedTotal <= 0) return null;
  return (totalDeaths / placedTotal) * 100;
}

export interface MovementTotals {
  initial: number;
  deaths: number;
  birdsIn: number;   // ek giriş + transfer giriş
  birdsOut: number;  // ayıklama + transfer çıkış + diğer
  dispatched: number;
}
export function aliveCount(t: MovementTotals): number {
  return t.initial + t.birdsIn - t.birdsOut - t.deaths - t.dispatched;
}

// --- Tartım ---------------------------------------------------------
export function toGrams(value: number, unit: WeightUnit): number {
  return unit === 'kg' ? value * 1000 : value;
}

/** Sunucudaki tg_weight_normalize ile aynı: ortalama gram */
export function averageWeightGrams(value: number, unit: WeightUnit, mode: WeightInputMode, sampleCount: number): number {
  const g = toGrams(value, unit);
  const avg = mode === 'total' ? g / sampleCount : g;
  return Math.round(avg * 100) / 100;
}

export interface WeightPoint { date: string; avgG: number; sample: number | null }
export interface WeightGain extends WeightPoint {
  gainSincePrevG: number | null;
  dailyGainG: number | null;   // önceki ölçümden bu yana günlük ortalama kazanç
  daysSincePrev: number | null;
}
/** Yalnızca gerçek ölçümler üzerinden hesaplar; ölçümsüz günlere değer üretmez. */
export function weightGains(points: WeightPoint[]): WeightGain[] {
  const sorted = [...points].sort((a, b) => a.date.localeCompare(b.date));
  return sorted.map((p, i) => {
    if (i === 0) return { ...p, gainSincePrevG: null, dailyGainG: null, daysSincePrev: null };
    const prev = sorted[i - 1];
    const days = daysBetween(prev.date, p.date);
    const gain = p.avgG - prev.avgG;
    return { ...p, gainSincePrevG: gain, daysSincePrev: days, dailyGainG: days > 0 ? gain / days : null };
  });
}

// --- Kömür ----------------------------------------------------------
export function coalTotalKg(bags: number, bagWeightKg: number): number {
  return Math.round(bags * bagWeightKg * 100) / 100;
}

// --- İlaç bekleme süresi ----------------------------------------------
export function withdrawalEndDate(applicationDate: string, withdrawalDays: number): string {
  return addDays(applicationDate, withdrawalDays);
}
/** Bekleme süresi kesim tarihine (dahil) taşıyorsa çakışma vardır. */
export function hasWithdrawalConflict(applicationDate: string, withdrawalDays: number, slaughterDate: string | null): boolean {
  if (!slaughterDate || withdrawalDays <= 0) return false;
  return dateToDayNumber(withdrawalEndDate(applicationDate, withdrawalDays)) >= dateToDayNumber(slaughterDate);
}

// --- Durum değerlendirmesi ---------------------------------------------
/**
 * Durum yalnızca yöneticinin tanımladığı eşiklere göre belirlenir.
 * Bu bir sağlık teşhisi değildir; eşik karşılaştırmasıdır.
 * Bugün ölüm kaydı yoksa durum "unknown" döner (sıfır kabul edilmez).
 */
export function evaluateStatus(input: {
  todayDeaths: number | null;
  startOfDayAlive: number;
  cumulativePct: number | null;
  thresholds: Pick<AlertSettings, 'daily_mortality_warn_pct' | 'daily_mortality_critical_pct' | 'cumulative_warn_pct' | 'cumulative_critical_pct'> | null;
  withdrawalConflict?: boolean;
}): HealthStatus {
  const { thresholds: th } = input;
  if (!th) return 'unknown';
  const daily = dailyMortalityPct(input.todayDeaths, input.startOfDayAlive);
  const cum = input.cumulativePct;
  if ((daily != null && daily >= th.daily_mortality_critical_pct) || (cum != null && cum >= th.cumulative_critical_pct)) {
    return 'critical';
  }
  if ((daily != null && daily >= th.daily_mortality_warn_pct) || (cum != null && cum >= th.cumulative_warn_pct) || input.withdrawalConflict) {
    return 'attention';
  }
  if (input.todayDeaths == null) return 'unknown';
  return 'normal';
}

/** Kayıt girilmemiş günler (sıfır ölüm girilmiş günler dahil değildir) */
export function missingMortalityDays(days: Pick<FlockDay, 'day' | 'mortality_recorded'>[]): string[] {
  return days.filter((d) => !d.mortality_recorded).map((d) => d.day);
}

// --- Doğrulama yardımcıları -----------------------------------------
export const LIMITS = {
  weightGramsMin: 10,
  weightGramsMax: 8000,
  tempMin: -30,
  tempMax: 60,
  bagsMax: 1000,
  bagKgMax: 100,
} as const;

/** Bir KPI güvenilir mi? Örn: bugün kayıtları eksikse toplamlar "eksik veri" olarak işaretlenir. */
export function reliability(recorded: number, expected: number): 'complete' | 'partial' | 'none' {
  if (expected <= 0 || recorded >= expected) return 'complete';
  return recorded === 0 ? 'none' : 'partial';
}
