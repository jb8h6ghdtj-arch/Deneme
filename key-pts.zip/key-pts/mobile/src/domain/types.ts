// Veritabanı satır tipleri (supabase/migrations ile birebir).
// Supabase CLI ile otomatik üretilebilir: `supabase gen types typescript`.

export type AppRole = 'owner' | 'manager' | 'worker';
export type HeatingType = 'coal' | 'gas' | 'electric' | 'biomass' | 'other' | 'none';
export type FlockStatus = 'active' | 'completed' | 'cancelled';
export type MovementType = 'addition' | 'transfer_in' | 'transfer_out' | 'cull' | 'other_exit';
export type WeightUnit = 'g' | 'kg';
export type WeightInputMode = 'average' | 'total';
export type HealthStatus = 'normal' | 'attention' | 'critical' | 'unknown';

export type EntryKind = 'mortality' | 'coal' | 'medication' | 'weight' | 'temperature' | 'note';

export const ENTRY_TABLE: Record<EntryKind, string> = {
  mortality: 'mortality_entries',
  coal: 'coal_entries',
  medication: 'medication_applications',
  weight: 'weight_measurements',
  temperature: 'temperature_measurements',
  note: 'daily_notes',
};

export const MORTALITY_CAUSES = [
  'unknown', 'weak_chick', 'respiratory', 'digestive', 'leg_problem',
  'heat_stress', 'cold_stress', 'crushing', 'predator', 'other',
] as const;
export type MortalityCause = (typeof MORTALITY_CAUSES)[number];

export const MED_CATEGORIES = ['antibiotic', 'vitamin', 'electrolyte', 'probiotic', 'coccidiostat', 'respiratory_support', 'liver_support', 'vaccine', 'disinfectant', 'other'] as const;
export type MedCategory = (typeof MED_CATEGORIES)[number];

export const MED_UNITS = ['ml', 'l', 'g', 'kg', 'dose', 'tablet', 'other'] as const;
export const MED_METHODS = ['drinking_water', 'feed', 'spray', 'injection', 'eye_drop', 'other'] as const;

export interface Membership {
  org_id: string;
  user_id: string;
  role: AppRole;
  organizations: { id: string; name: string } | null;
}

export interface Farm {
  id: string;
  org_id: string;
  name: string;
  location_text: string | null;
  default_heating: HeatingType;
  default_coal_bag_kg: number;
  chick_phase_days: number;
  age_base: 0 | 1;
  timezone: string;
  contact_name?: string | null;
  contact_phone?: string | null;
  contact_email?: string | null;
}

export interface House {
  id: string;
  org_id: string;
  farm_id: string;
  name: string;
  capacity: number;
  heating_type: HeatingType;
  coal_tracking: boolean;
  sort_order: number;
  archived_at: string | null;
}

export interface FlockOverview {
  flock_id: string;
  org_id: string;
  farm_id: string;
  house_id: string;
  house_name: string;
  capacity: number;
  heating_type: HeatingType;
  coal_tracking: boolean;
  sort_order: number;
  name: string;
  cycle_no: number;
  status: FlockStatus;
  placement_date: string;
  initial_count: number;
  breed: string | null;
  expected_slaughter_date: string | null;
  responsible_user_id: string | null;
  completed_at: string | null;
  version: number;
  chick_phase_days: number;
  age_base: 0 | 1;
  today: string;
  days_to_slaughter: number | null;
  age_day: number;
  placed_total: number;
  alive_count: number;
  total_deaths: number;
  cumulative_mortality_pct: number | null;
  today_deaths: number | null;
  today_mortality_recorded: boolean;
  today_coal_bags: number | null;
  today_coal_kg: number | null;
  today_med_count: number;
  last_weight_g: number | null;
  last_weight_date: string | null;
  last_weight_sample: number | null;
  last_weight_at?: string | null;
  last_temperature_c: number | null;
  last_temperature_at: string | null;
  withdrawal_end_date: string | null;
  withdrawal_conflict: boolean;
}

export interface FlockDay {
  flock_id: string;
  house_id: string;
  day: string;
  age_day: number;
  deaths: number | null;
  mortality_recorded: boolean;
  mortality_entries: number;
  birds_in: number;
  birds_out: number;
  dispatched: number;
  start_of_day_alive: number;
  end_of_day_alive: number;
  daily_mortality_pct: number | null;
  cumulative_deaths: number;
  cumulative_mortality_pct: number | null;
  coal_bags: number | null;
  coal_kg: number | null;
  coal_entries: number;
  med_count: number;
  avg_weight_g: number | null;
  weight_sample_count: number | null;
  temp_min: number | null;
  temp_max: number | null;
  temp_avg: number | null;
  temp_count: number;
  note_count: number;
}

export interface ActivityRow {
  kind: EntryKind | 'movement';
  id: string;
  flock_id: string;
  house_id: string;
  org_id: string;
  entry_date: string;
  created_at: string;
  created_by: string;
  value: number | null;
  label: string | null;
  note: string | null;
  version: number;
  updated_at: string;
}

export interface MedicationProduct {
  id: string;
  org_id: string;
  name: string;
  category: MedCategory;
  active_ingredient: string | null;
  default_unit: string;
  default_method: string | null;
  withdrawal_days: number;
  is_active: boolean;
}

export interface AlertSettings {
  farm_id: string;
  org_id: string;
  daily_mortality_warn_pct: number;
  daily_mortality_critical_pct: number;
  cumulative_warn_pct: number;
  cumulative_critical_pct: number;
  missing_report_hour: number;
  slaughter_reminder_days: number;
}

export interface TemperatureTarget {
  id: string;
  farm_id: string;
  day_from: number;
  day_to: number;
  min_c: number;
  max_c: number;
}

export interface AppNotification {
  id: string;
  kind: string;
  severity: 'info' | 'warning' | 'critical';
  title: string;
  body: string;
  house_id: string | null;
  flock_id: string | null;
  read_at: string | null;
  created_at: string;
}

export interface WeightTarget { id: string; farm_id: string; age_day: number; target_g: number }
