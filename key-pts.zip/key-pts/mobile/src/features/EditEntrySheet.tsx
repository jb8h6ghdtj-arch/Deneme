// Kayıt düzeltme: sürüm kontrollü. Eski/yeni değer, düzelten kişi ve zaman sunucuda denetim kaydına yazılır.
import React, { useEffect, useState } from 'react';
import { Modal, Pressable, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useEditEntry } from '../api/mutations';
import { Button, Notice, Text, TextField } from '../components/ui';
import type { EntryKind } from '../domain/types';
import { parseDecimal } from '../lib/format';
import { colors, radius, spacing } from '../theme';

export interface EditTarget { kind: EntryKind; id: string; version: number; field: string; label: string; value: string; integer?: boolean }

export function EditEntrySheet({ target, onClose, canDelete }: { target: EditTarget | null; onClose: () => void; canDelete: boolean }) {
  const insets = useSafeAreaInsets();
  const edit = useEditEntry();
  const [value, setValue] = useState('');
  const [msg, setMsg] = useState<{ tone: 'danger' | 'warning'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { setValue(target?.value ?? ''); setMsg(null); }, [target]);
  if (!target) return null;
  const run = async (patch: Record<string, unknown>) => {
    setBusy(true);
    const { status } = await edit(target.kind, target.id, target.version, patch);
    setBusy(false);
    if (status === 'saved') return onClose();
    if (status === 'conflict') return setMsg({ tone: 'danger', text: 'Bu kayıt sizden önce başka bir ekranda değiştirildi. Değişikliğiniz uygulanmadı; güncel hâli görmek için ekranı yenileyin.' });
    if (status === 'failed') return setMsg({ tone: 'danger', text: 'Değişiklik kaydedilemedi. Değeri kontrol edin.' });
  };
  const save = () => {
    if (target.field === 'body') return run({ body: value.trim() });
    const n = target.integer ? parseInt(value, 10) : parseDecimal(value);
    if (n == null || Number.isNaN(n) || n < 0) return setMsg({ tone: 'danger', text: 'Geçerli bir sayı girin.' });
    return run({ [target.field]: n });
  };
  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={{ flex: 1, backgroundColor: colors.overlay }} onPress={onClose} />
      <View style={{ backgroundColor: colors.surface.primary, padding: spacing.xl, paddingBottom: insets.bottom + spacing.xl, gap: spacing.md, borderTopLeftRadius: radius.panel, borderTopRightRadius: radius.panel }}>
        <Text variant="section">Kaydı düzelt</Text>
        <Text variant="label" muted>{target.label}. Eski ve yeni değer, düzelten kişi ve zaman denetim geçmişine kaydedilir.</Text>
        <TextField label="Yeni değer" value={value} onChangeText={setValue} keyboardType={target.field === 'body' ? 'default' : 'decimal-pad'} multiline={target.field === 'body'} />
        {msg && <Notice tone={msg.tone}>{msg.text}</Notice>}
        <Button title="Kaydet" icon="check" loading={busy} onPress={save} />
        {canDelete && <Button title="Kaydı sil" variant="danger" onPress={() => run({ deleted_at: new Date().toISOString() })} />}
        <Button title="Vazgeç" variant="ghost" onPress={onClose} />
      </View>
    </Modal>
  );
}
