import type { FlockDay, FlockOverview } from '../../domain/types';
import { dailyFarmSummary, mortalityReport, weeklyCoal } from '../reportBuilders';

const day = (n: number, extra: Partial<FlockDay> = {}): FlockDay => ({
  flock_id: 'f1', house_id: 'h1', day: `2026-11-${String(n).padStart(2, '0')}`, age_day: n, deaths: null, mortality_recorded: false,
  mortality_entries: 0, birds_in: 0, birds_out: 0, dispatched: 0, start_of_day_alive: 25000, end_of_day_alive: 25000,
  daily_mortality_pct: null, cumulative_deaths: 0, cumulative_mortality_pct: 0, coal_bags: null, coal_kg: null, coal_entries: 0,
  med_count: 0, avg_weight_g: null, weight_sample_count: null, temp_min: null, temp_max: null, temp_avg: null, temp_count: 0, note_count: 0, ...extra,
});

describe('raporlar', () => {
  it('ölüm raporunda kayıt yok günler açıkça işaretlenir', () => {
    const r = mortalityReport([day(1, { deaths: 0, mortality_recorded: true }), day(2)]);
    expect(r.rows[0][7]).toBe('Kayıtlı');
    expect(r.rows[1][3]).toBeNull();
    expect(r.rows[1][7]).toBe('Kayıt yok');
  });
  it('haftalık kömür: kayıtsız gün toplamı etkilemez, ayrıca sayılır (Senaryo 4)', () => {
    const w = weeklyCoal([day(1, { coal_bags: 8, coal_kg: 200 }), day(2, { coal_bags: 11, coal_kg: 275 }), day(3), day(8, { coal_bags: 6, coal_kg: 150 })]);
    expect(w[0]).toEqual({ week: 1, bags: 19, kg: 475, daysRecorded: 2, days: 3 });
    expect(w[1].bags).toBe(6);
  });
  it('günlük çiftlik özeti eksik kümesi "tamamlanmadı" gösterir', () => {
    const flocks = [{ flock_id: 'f1', house_name: 'Kümes 1', coal_tracking: true }, { flock_id: 'f3', house_name: 'Kümes 3', coal_tracking: false }] as FlockOverview[];
    const s = dailyFarmSummary('2026-11-15', flocks, [day(15, { deaths: 18, mortality_recorded: true, coal_bags: 8, med_count: 2, avg_weight_g: 1150 })]);
    expect(s[0]).toMatchObject({ house: 'Kümes 1', complete: true, deaths: 18, coalBags: 8, meds: 2, weighings: 1 });
    expect(s[1]).toMatchObject({ house: 'Kümes 3', complete: false });
  });
});
