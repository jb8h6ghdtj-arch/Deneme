import { useQueryClient } from '@tanstack/react-query';
import { dataClient } from '../../lib/data';
import { nav } from '../../navigation/nav';

/** Çıkış: oturum kapatılır, sorgu önbelleği temizlenir, gezinme geçmişi sıfırlanır (geri tuşuyla uygulamaya dönülemez). Veriler cihazda kalır. */
export function useSignOut() {
  const qc = useQueryClient();
  return async () => {
    await dataClient.auth.signOut();
    qc.clear();
    nav.resetTo('/(auth)/sign-in');
  };
}
