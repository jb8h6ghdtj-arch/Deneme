import { useMemo } from 'react';
import { evaluateStatus, farmWeightedAverage } from '../../domain/calculations';
import type { AlertSettings, FlockOverview, HealthStatus } from '../../domain/types';

export interface HouseStatus { status: HealthStatus; reason: string | null }

/** Durum yalnızca yapılandırılmış eşiklere göre; metin nedeni de üretilir (renk tek başına anlam taşımaz). */
export function houseStatus(f: FlockOverview, th: AlertSettings | null | undefined): HouseStatus {
  const start = f.alive_count + (f.today_deaths ?? 0);
  const status = evaluateStatus({ todayDeaths: f.today_deaths, startOfDayAlive: start, cumulativePct: f.cumulative_mortality_pct, thresholds: th ?? null, withdrawalConflict: f.withdrawal_conflict });
  const daily = f.today_deaths != null && start > 0 ? (f.today_deaths / start) * 100 : null;
  const pct = (n: number) => `%${n.toLocaleString('tr-TR', { maximumFractionDigits: 3 })}`;
  let reason: string | null = null;
  if (th && status === 'critical') reason = daily != null && daily >= th.daily_mortality_critical_pct ? `Bugünkü ölüm ${pct(daily)} ≥ kritik eşik ${pct(th.daily_mortality_critical_pct)}` : `Kümülatif ölüm ${pct(f.cumulative_mortality_pct ?? 0)} ≥ kritik eşik ${pct(th.cumulative_critical_pct)}`;
  else if (th && status === 'attention') reason = f.withdrawal_conflict ? 'İlaç bekleme süresi kesim planıyla çakışıyor' : daily != null && daily >= th.daily_mortality_warn_pct ? `Bugünkü ölüm ${pct(daily)} ≥ dikkat eşiği ${pct(th.daily_mortality_warn_pct)}` : `Kümülatif ölüm ≥ dikkat eşiği ${pct(th.cumulative_warn_pct)}`;
  else if (status === 'unknown') reason = f.status === 'active' ? 'Bugün için ölüm kaydı henüz girilmedi' : null;
  return { status, reason };
}

export function useFarmSummary(flocks: FlockOverview[]) {
  return useMemo(() => {
    const recorded = flocks.filter((f) => f.today_mortality_recorded);
    const coal = flocks.filter((f) => f.coal_tracking);
    const coalRec = coal.filter((f) => f.today_coal_bags != null);
    const placed = flocks.reduce((s, f) => s + f.placed_total, 0);
    const deaths = flocks.reduce((s, f) => s + f.total_deaths, 0);
    const w = farmWeightedAverage(flocks.map((f) => ({ avgG: f.last_weight_g == null ? null : Number(f.last_weight_g), alive: f.alive_count, date: f.last_weight_date })));
    const ages = [...new Set(flocks.map((f) => f.age_day))].sort((a, b) => a - b);
    return {
      count: flocks.length, alive: flocks.reduce((s, f) => s + f.alive_count, 0), initial: flocks.reduce((s, f) => s + f.initial_count, 0),
      todayDeaths: recorded.reduce((s, f) => s + (f.today_deaths ?? 0), 0), recordedCount: recorded.length,
      totalDeaths: deaths, cumPct: placed ? (deaths / placed) * 100 : null,
      coalBags: coalRec.reduce((s, f) => s + Number(f.today_coal_bags), 0), coalKg: coalRec.reduce((s, f) => s + Number(f.today_coal_kg), 0),
      coalHouses: coal.length, coalRecorded: coalRec.length,
      weight: w, meds: flocks.reduce((s, f) => s + f.today_med_count, 0),
      ageLabel: !ages.length ? '—' : ages.length === 1 ? `${ages[0]}. gün` : `${ages[0]}–${ages[ages.length - 1]}. gün`,
    };
  }, [flocks]);
}
