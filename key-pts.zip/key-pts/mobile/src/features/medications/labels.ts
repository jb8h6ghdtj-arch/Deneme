export const CATEGORY_TR: Record<string, string> = {
  antibiotic: 'Antibiyotik', vitamin: 'Vitamin', electrolyte: 'Elektrolit', probiotic: 'Probiyotik', coccidiostat: 'Koksidiyostat',
  respiratory_support: 'Solunum desteği', liver_support: 'Karaciğer desteği', vaccine: 'Aşı', disinfectant: 'Dezenfektan', other: 'Diğer veteriner ürünü',
};
export const UNIT_TR: Record<string, string> = { ml: 'ml', l: 'litre', g: 'g', kg: 'kg', dose: 'doz', tablet: 'tablet', other: 'diğer' };
export const METHOD_TR: Record<string, string> = { drinking_water: 'İçme suyu', feed: 'Yem', spray: 'Sprey', injection: 'Enjeksiyon', eye_drop: 'Göz damlası', other: 'Diğer' };
