// Rapor tabloları — saf fonksiyonlar (CSV/PDF ve ekranlar aynı veriyi kullanır).
import { weightGains } from '../domain/calculations';
import type { ActivityRow, FlockDay, FlockOverview } from '../domain/types';
import type { Cell } from '../lib/export';

const r3 = (n: number | null | undefined) => (n == null ? null : Math.round(Number(n) * 1000) / 1000);

export function mortalityReport(days: FlockDay[]): { headers: string[]; rows: Cell[][] } {
  return {
    headers: ['Tarih', 'Gün', 'Gün başı mevcut', 'Ölüm', 'Günlük %', 'Kümülatif ölüm', 'Kümülatif %', 'Durum'],
    rows: days.map((d) => [d.day, d.age_day, d.start_of_day_alive, d.deaths, r3(d.daily_mortality_pct), d.cumulative_deaths, r3(d.cumulative_mortality_pct),
      d.mortality_recorded ? 'Kayıtlı' : 'Kayıt yok']),
  };
}

export function coalReport(days: FlockDay[]): { headers: string[]; rows: Cell[][] } {
  return {
    headers: ['Tarih', 'Gün', 'Torba', 'Kilogram', 'Kayıt sayısı'],
    rows: days.map((d) => [d.day, d.age_day, d.coal_bags == null ? null : Number(d.coal_bags), d.coal_kg == null ? null : Number(d.coal_kg), d.coal_entries]),
  };
}

/** Haftalık (yetiştirme haftası) kömür toplamı. Kayıt olmayan günler toplamı etkilemez, ayrıca sayılır. */
export function weeklyCoal(days: FlockDay[]) {
  const weeks = new Map<number, { week: number; bags: number; kg: number; daysRecorded: number; days: number }>();
  for (const d of days) {
    const w = Math.ceil(d.age_day / 7);
    const cur = weeks.get(w) ?? { week: w, bags: 0, kg: 0, daysRecorded: 0, days: 0 };
    cur.days += 1;
    if (d.coal_bags != null) { cur.bags += Number(d.coal_bags); cur.kg += Number(d.coal_kg ?? 0); cur.daysRecorded += 1; }
    weeks.set(w, cur);
  }
  return [...weeks.values()].sort((a, b) => a.week - b.week);
}

export function weightReport(days: FlockDay[]) {
  const pts = days.filter((d) => d.avg_weight_g != null).map((d) => ({ date: d.day, avgG: Number(d.avg_weight_g), sample: d.weight_sample_count }));
  const gains = weightGains(pts);
  return {
    gains,
    headers: ['Tarih', 'Gün', 'Örneklem', 'Ortalama (g)', 'Önceki ölçüme göre artış (g)', 'Günlük ort. kazanç (g/gün)'],
    rows: gains.map((g) => [g.date, days.find((d) => d.day === g.date)?.age_day ?? null, g.sample, g.avgG, g.gainSincePrevG, g.dailyGainG == null ? null : Math.round(g.dailyGainG * 10) / 10]),
  };
}

export function temperatureReport(days: FlockDay[]) {
  return {
    headers: ['Tarih', 'Gün', 'Ölçüm sayısı', 'Min °C', 'Ort °C', 'Maks °C'],
    rows: days.filter((d) => d.temp_count > 0).map((d) => [d.day, d.age_day, d.temp_count, d.temp_min, d.temp_avg, d.temp_max]),
  };
}

const KIND_LABEL: Record<string, string> = { mortality: 'Ölüm', coal: 'Kömür', medication: 'İlaç', weight: 'Tartım', temperature: 'Sıcaklık', note: 'Not', movement: 'Sürü hareketi' };

export function activityReport(rows: ActivityRow[], names: Map<string, string>, houses: Map<string, string>) {
  return {
    headers: ['Gönderim zamanı', 'Kayıt tarihi', 'Kümes', 'Tür', 'Değer', 'Detay', 'Açıklama', 'Kaydeden', 'Sürüm'],
    rows: rows.map((a) => [a.created_at, a.entry_date, houses.get(a.house_id) ?? '', KIND_LABEL[a.kind] ?? a.kind, a.value, a.label, a.note,
      names.get(a.created_by) ?? a.created_by, a.version > 1 ? `${a.version} (düzeltildi)` : 1]),
  };
}

export function comparisonReport(flocks: FlockOverview[]) {
  return {
    headers: ['Kümes', 'Gün', 'Başlangıç', 'Mevcut', 'Toplam ölüm', 'Kümülatif %', 'Son ort. ağırlık (g)', 'Son tartım'],
    rows: flocks.map((f) => [f.house_name, f.age_day, f.initial_count, f.alive_count, f.total_deaths, r3(f.cumulative_mortality_pct), f.last_weight_g, f.last_weight_date]),
  };
}

/** Günlük çiftlik özeti: her kümes için o günün kayıtları; eksikler açıkça belirtilir. */
export function dailyFarmSummary(day: string, flocks: FlockOverview[], daily: FlockDay[]) {
  return flocks.map((f) => {
    const d = daily.find((x) => x.flock_id === f.flock_id && x.day === day);
    return {
      house: f.house_name,
      flockId: f.flock_id,
      complete: !!d?.mortality_recorded,
      deaths: d?.deaths ?? null,
      coalBags: d?.coal_bags == null ? null : Number(d.coal_bags),
      coalTracking: f.coal_tracking,
      meds: d?.med_count ?? 0,
      weighings: d?.avg_weight_g != null ? 1 : 0,
      temps: d?.temp_count ?? 0,
      notes: d?.note_count ?? 0,
    };
  });
}
