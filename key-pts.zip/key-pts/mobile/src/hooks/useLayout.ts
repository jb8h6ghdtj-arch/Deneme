// Ekran genişliğine göre esnek yerleşim kararları (sabit cihaz ölçüsüne bağlı kod yok).
import { useWindowDimensions } from 'react-native';

export function useLayout() {
  const { width, height, fontScale } = useWindowDimensions();
  // Büyük yazı tipi açıkken kartlar daha erken tek sütuna geçer
  const effective = width / Math.max(1, Math.min(fontScale, 1.6));
  return {
    width, height, fontScale,
    /** 2 sütunlu KPI düzeni yerine tek sütun */
    singleColumn: effective < 330,
    /** Dar ekran (320–359 dp): daha küçük iç boşluklar */
    compact: width < 360,
    /** Geniş ekran / tablet: içerik ortalanır, maksimum genişlik uygulanır */
    wide: width >= 600,
    contentMaxWidth: 640,
  };
}
