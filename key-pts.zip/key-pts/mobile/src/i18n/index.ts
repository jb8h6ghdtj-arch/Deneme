import { getLocales } from 'expo-localization';
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { I18nManager } from 'react-native';
import en from './locales/en';
import tr from './locales/tr';

export const SUPPORTED = ['tr', 'en'] as const; // 'ar' eklendiğinde RTL desteği aşağıda hazır
const device = getLocales()[0]?.languageCode ?? 'tr';

void i18n.use(initReactI18next).init({
  resources: { tr: { translation: tr }, en: { translation: en } },
  lng: 'tr', // Birincil pazar Türkiye; kullanıcı profilden değiştirebilir
  fallbackLng: 'tr',
  interpolation: { escapeValue: false },
  returnNull: false,
});

export function setLanguage(lng: string) {
  void i18n.changeLanguage(lng);
  const rtl = lng === 'ar';
  if (I18nManager.isRTL !== rtl) { I18nManager.allowRTL(rtl); I18nManager.forceRTL(rtl); }
}
export const deviceLanguage = device;
export default i18n;
