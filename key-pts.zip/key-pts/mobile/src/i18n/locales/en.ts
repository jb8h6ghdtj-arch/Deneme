// English (partial). Missing keys fall back to Turkish.
const en = {
  app: { tagline: 'The pulse of your poultry house, in your hand.' },
  common: { save: 'Save', cancel: 'Cancel', next: 'Next', back: 'Back', done: 'Done', today: 'Today', loading: 'Loading…', retry: 'Retry' },
  roles: { owner: 'Farm Owner', manager: 'Farm Manager', worker: 'House Worker' },
  auth: { signIn: 'Sign in', signUp: 'Create account', email: 'Email', password: 'Password', fullName: 'Full name', signOut: 'Sign out' },
  tabs: { home: 'Home', houses: 'Houses', record: 'Add Record', reports: 'Reports', profile: 'Profile' },
  entry: { mortality: 'Add Mortality', coal: 'Add Coal', medication: 'Add Medication', weight: 'Add Weighing', temperature: 'Add Temperature', note: 'Add Note', saved: 'Saved' },
  status: { normal: 'Normal', attention: 'Attention', critical: 'Critical', unknown: 'Awaiting record' },
};
export default en;
