import { toCsv } from '../export';
import { parseDecimal } from '../format';
import { localDate } from '../dates';

jest.mock('expo-file-system', () => ({}));
jest.mock('expo-print', () => ({}));
jest.mock('expo-sharing', () => ({}));

describe('biçimlendirme', () => {
  it('Türkçe ondalık giriş', () => {
    expect(parseDecimal('1,25')).toBe(1.25);
    expect(parseDecimal('1.250,5')).toBe(1250.5);
    expect(parseDecimal('25')).toBe(25);
    expect(parseDecimal('abc')).toBeNull();
    expect(parseDecimal('')).toBeNull();
  });
  it('CSV: BOM, ; ayraç, kaçış ve ondalık virgül', () => {
    const csv = toCsv(['Kümes', 'Değer'], [['Kümes "A"; 1', 1.5], ['B', null]]);
    expect(csv.startsWith('﻿')).toBe(true);
    expect(csv).toContain('"Kümes ""A""; 1";1,5');
    expect(csv).toContain('B;');
  });
  it('Türkiye saat dilimine göre gün (UTC 22:30 → ertesi gün)', () => {
    expect(localDate(new Date('2026-11-05T22:30:00Z'))).toBe('2026-11-06');
    expect(localDate(new Date('2026-11-05T20:59:00Z'))).toBe('2026-11-05');
  });
});
