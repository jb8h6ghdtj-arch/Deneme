// Tek veri erişim noktası. Ekranlar ve sorgu kancaları yalnızca `dataClient` kullanır.
// Şu an: cihaz içi yerel istemci (SQLite). İleride sunucu eklenirse burada aynı arayüzü sağlayan
// bir istemci seçilir; ekranlar değişmez (bkz. docs/ARCHITECTURE.md §2).
import { localClient } from '../services/local/localClient';

export const dataClient = localClient;
export type DataClient = typeof localClient;
