// Tüm tarih gösterimleri Türkiye saat dilimine göredir (çiftlik ayarı ile değiştirilebilir).
export const DEFAULT_TZ = 'Europe/Istanbul';

/** Verilen andaki yerel takvim günü (YYYY-MM-DD) */
export function localDate(at: Date = new Date(), timeZone = DEFAULT_TZ): string {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(at);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '';
  return `${get('year')}-${get('month')}-${get('day')}`;
}

export function formatDate(iso: string | null | undefined, opts: Intl.DateTimeFormatOptions = { day: '2-digit', month: 'long', year: 'numeric' }, locale = 'tr-TR'): string {
  if (!iso) return '—';
  // Saf tarih (YYYY-MM-DD) ise UTC öğlen kullan; kayma olmasın.
  const d = iso.length === 10 ? new Date(`${iso}T12:00:00Z`) : new Date(iso);
  return new Intl.DateTimeFormat(locale, { timeZone: iso.length === 10 ? 'UTC' : DEFAULT_TZ, ...opts }).format(d);
}

export function formatShortDate(iso: string | null | undefined): string {
  return formatDate(iso, { day: '2-digit', month: 'short' });
}

export function formatTime(iso: string | null | undefined, locale = 'tr-TR'): string {
  if (!iso) return '—';
  return new Intl.DateTimeFormat(locale, { timeZone: DEFAULT_TZ, hour: '2-digit', minute: '2-digit' }).format(new Date(iso));
}

export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return '—';
  return `${formatDate(iso, { day: '2-digit', month: 'short', year: 'numeric' })} ${formatTime(iso)}`;
}

/** Yerel tarih+saatten ISO zaman damgası üretir (Türkiye UTC+3, yaz saati yok) */
export function istanbulLocalToIso(date: string, hhmm: string): string {
  return new Date(`${date}T${hhmm}:00+03:00`).toISOString();
}
