// Uygulama tamamen cihaz içinde çalışır; sunucu adresi veya gizli anahtar yoktur.
export const env = { mode: 'local' as const };
