// Veritabanı hata kodlarını kullanıcı dostu Türkçe mesajlara çevirir.
const MESSAGES: Record<string, string> = {
  EXCEEDS_ALIVE: 'Girilen sayı kümedeki mevcut hayvan sayısını aşıyor.',
  FLOCK_CLOSED: 'Bu dönem tamamlanmış. Arşivdeki kayıtlar değiştirilemez.',
  DATE_IN_FUTURE: 'İleri tarihli kayıt girilemez.',
  DATE_BEFORE_PLACEMENT: 'Kayıt tarihi civciv giriş tarihinden önce olamaz.',
  FLOCK_NOT_FOUND: 'Dönem bulunamadı veya erişim yetkiniz yok.',
  FORBIDDEN: 'Bu işlem için yetkiniz yok.',
  INVITE_INVALID: 'Davet kodu geçersiz.',
  INVITE_USED: 'Bu davet kodu daha önce kullanılmış.',
  INVITE_EXPIRED: 'Davet kodunun süresi dolmuş.',
  INVITE_EMAIL_MISMATCH: 'Bu davet başka bir e-posta adresi için oluşturulmuş.',
  ALREADY_MEMBER: 'Zaten bu çiftliğin üyesisiniz.',
  MANAGER_CAN_INVITE_WORKERS_ONLY: 'Sorumlular yalnızca kümes bakıcısı davet edebilir.',
  HOUSE_NOT_MANAGED: 'Yetkiniz olmayan bir kümes seçildi.',
  INITIAL_EXCEEDS_CAPACITY: 'Başlangıç civciv sayısı kümes kapasitesini çok aşıyor.',
  LAST_OWNER: 'Çiftliğin son sahibi kaldırılamaz.',
  flocks_one_active_per_house: 'Bu kümeste zaten aktif bir dönem var. Önce mevcut dönemi tamamlayın.',
  'row-level security': 'Bu işlem için yetkiniz yok.',
  'Invalid login credentials': 'E-posta veya şifre hatalı.',
  'Email not confirmed': 'E-posta adresinizi doğrulamanız gerekiyor. Gelen kutunuzu kontrol edin.',
  'User already registered': 'Bu e-posta ile kayıtlı bir hesap var.',
};

export function errorMessage(err: unknown): string {
  const raw = typeof err === 'string' ? err : (err as { message?: string })?.message ?? '';
  for (const key of Object.keys(MESSAGES)) if (raw.includes(key)) return MESSAGES[key];
  if (/network|fetch|Failed to fetch|timeout/i.test(raw)) return 'Sunucuya ulaşılamadı. Bağlantınızı kontrol edin.';
  return raw ? `Beklenmeyen bir hata oluştu: ${raw}` : 'Beklenmeyen bir hata oluştu.';
}

/** Ağ kaynaklı (yeniden denenebilir) hata mı? Doğrulama/yetki hataları yeniden denenmez. */
export function isTransientError(err: unknown): boolean {
  const e = err as { message?: string; code?: string; status?: number } | null;
  if (!e) return false;
  if (e.status != null && (e.status >= 500 || e.status === 408 || e.status === 429)) return true;
  if (e.code && /^(PGRST|23|22|42|P0|28)/.test(e.code)) return false;
  return /network|fetch|timeout|ECONN|offline|aborted/i.test(e.message ?? '');
}
