// CSV ve PDF dışa aktarma (cihazda üretilir, paylaşım menüsüyle gönderilir).
import { File, Paths } from 'expo-file-system';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';

export type Cell = string | number | null | undefined | boolean;

/** RFC 4180 CSV. Excel'in Türkçe karakterleri doğru açması için UTF-8 BOM eklenir; ayraç ';' (TR Excel). */
export function toCsv(headers: string[], rows: Cell[][], sep = ';'): string {
  const esc = (v: Cell) => {
    if (v == null) return '';
    const s = typeof v === 'number' ? String(v).replace('.', ',') : String(v);
    return /["\n\r]/.test(s) || s.includes(sep) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return '﻿' + [headers, ...rows].map((r) => r.map(esc).join(sep)).join('\r\n');
}

export async function shareCsv(filename: string, headers: string[], rows: Cell[][]) {
  const file = new File(Paths.cache, filename.endsWith('.csv') ? filename : `${filename}.csv`);
  if (file.exists) file.delete();
  file.create();
  file.write(toCsv(headers, rows));
  await Sharing.shareAsync(file.uri, { mimeType: 'text/csv', dialogTitle: filename, UTI: 'public.comma-separated-values-text' });
}

const escHtml = (s: Cell) => String(s ?? '').replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]!));

export function reportHtml(opts: { title: string; subtitle?: string; summary?: [string, string][]; headers: string[]; rows: Cell[][]; footnote?: string }) {
  const num = (v: Cell) => (typeof v === 'number' ? new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 2 }).format(v) : escHtml(v));
  return `<!DOCTYPE html><html lang="tr"><head><meta charset="utf-8"><style>
  body{font-family:-apple-system,Roboto,Helvetica,Arial,sans-serif;color:#172B36;margin:28px}
  header{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:3px solid #168B71;padding-bottom:10px;margin-bottom:16px}
  .brand{font-weight:800;letter-spacing:2px;color:#10243A;font-size:18px}.brand small{display:block;font-size:8px;letter-spacing:3px;color:#5B6E78}
  h1{font-size:20px;margin:0}.sub{color:#5B6E78;font-size:12px}
  .kpis{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0 18px}.kpi{border:1px solid #DCE4E1;border-radius:8px;padding:8px 12px;min-width:120px}
  .kpi b{display:block;font-size:15px}.kpi span{font-size:9px;text-transform:uppercase;letter-spacing:.6px;color:#5B6E78}
  table{width:100%;border-collapse:collapse;font-size:10.5px}th{background:#10243A;color:#fff;text-align:left;padding:6px}
  td{padding:5px 6px;border-bottom:1px solid #E4EAE8}tr:nth-child(even) td{background:#F7F9F8}
  .foot{margin-top:14px;font-size:9px;color:#5B6E78}</style></head><body>
  <header><div><h1>${escHtml(opts.title)}</h1><div class="sub">${escHtml(opts.subtitle ?? '')}</div></div>
  <div class="brand">KEY PTS<small>POULTRY TRACKING SYSTEM</small></div></header>
  ${opts.summary?.length ? `<div class="kpis">${opts.summary.map(([k, v]) => `<div class="kpi"><span>${escHtml(k)}</span><b>${escHtml(v)}</b></div>`).join('')}</div>` : ''}
  <table><thead><tr>${opts.headers.map((h) => `<th>${escHtml(h)}</th>`).join('')}</tr></thead>
  <tbody>${opts.rows.map((r) => `<tr>${r.map((v) => `<td>${num(v)}</td>`).join('')}</tr>`).join('')}</tbody></table>
  <div class="foot">${escHtml(opts.footnote ?? '')} Oluşturulma: ${new Date().toLocaleString('tr-TR', { timeZone: 'Europe/Istanbul' })}</div>
  </body></html>`;
}

export async function sharePdf(opts: Parameters<typeof reportHtml>[0]) {
  const { uri } = await Print.printToFileAsync({ html: reportHtml(opts) });
  await Sharing.shareAsync(uri, { mimeType: 'application/pdf', UTI: 'com.adobe.pdf', dialogTitle: opts.title });
}
