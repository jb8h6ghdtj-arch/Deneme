const nf = (digits = 0) => new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 0, maximumFractionDigits: digits });

export const fmtInt = (n: number | null | undefined) => (n == null ? '—' : nf(0).format(n));
export const fmtNum = (n: number | null | undefined, digits = 2) => (n == null ? '—' : nf(digits).format(n));
export const fmtPct = (n: number | null | undefined, digits = 2) => (n == null ? '—' : `%${nf(digits).format(n)}`);
export const fmtKg = (grams: number | null | undefined) => (grams == null ? '—' : `${nf(3).format(grams / 1000)} kg`);
export const fmtGram = (grams: number | null | undefined) => (grams == null ? '—' : `${nf(0).format(grams)} g`);

/** Türkçe ondalık virgül girişini sayıya çevirir: "1,25" → 1.25, "1.250" → 1250 değil! */
export function parseDecimal(input: string): number | null {
  const s = input.trim().replace(/\s/g, '');
  if (!s) return null;
  // Hem nokta hem virgül varsa: noktayı binlik ayıracı say
  const normalized = s.includes(',') ? s.replace(/\./g, '').replace(',', '.') : s;
  const n = Number(normalized);
  return Number.isFinite(n) ? n : null;
}
