// Kritik teknik hataların izlenebilir kaydı (cihazda; son 200 kayıt). Kullanıcıya teknik kod gösterilmez.
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'keypts:errorlog';
export function logError(where: string, err: unknown) {
  const entry = { at: new Date().toISOString(), where, message: String((err as Error)?.message ?? err), stack: String((err as Error)?.stack ?? '').slice(0, 800) };
  console.error(`[KEY PTS] ${where}:`, entry.message);
  void AsyncStorage.getItem(KEY).then((raw) => {
    const list = raw ? JSON.parse(raw) : [];
    list.push(entry);
    return AsyncStorage.setItem(KEY, JSON.stringify(list.slice(-200)));
  }).catch(() => {});
}
export async function readErrorLog(): Promise<{ at: string; where: string; message: string }[]> {
  try { return JSON.parse((await AsyncStorage.getItem(KEY)) ?? '[]'); } catch { return []; }
}
