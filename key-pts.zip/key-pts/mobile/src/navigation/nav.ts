// Merkezi, tip güvenli navigasyon. Bütün ekran geçişleri buradan yapılır.
// - routes.*: parametreleri doğru tipte üreten rota oluşturucular (yanlış kümese gitmeyi önler)
// - nav.push: aynı hedefe kısa sürede ikinci kez basılırsa yok sayar (aynı ekranın üst üste açılması engellenir)
// - nav.back: geri gidilebiliyorsa geri, yoksa güvenli varsayılan ekrana (Ana Sayfa) döner
import { router, type Href } from 'expo-router';

export type ModuleKind = 'mortality' | 'coal' | 'medication' | 'weight' | 'temperature' | 'note';
export type SingleEntryKind = 'mortality' | 'coal' | 'weight' | 'temperature' | 'note';

export const routes = {
  home: () => '/(tabs)' as Href,
  houses: () => '/(tabs)/houses' as Href,
  recordTab: () => '/(tabs)/record' as Href,
  reports: () => '/(tabs)/reports' as Href,
  profile: () => '/(tabs)/profile' as Href,
  house: (id: string) => ({ pathname: '/house/[id]', params: { id } }) as Href,
  newHouse: () => '/house/new' as Href,
  dailyRecord: (houseId: string) => ({ pathname: '/record/[houseId]', params: { houseId } }) as Href,
  medicationPicker: (p: { houseId: string; flockId: string; date: string }) => ({ pathname: '/record/medications', params: p }) as Href,
  module: (kind: ModuleKind, flockId: string) => ({ pathname: '/module/[kind]', params: { kind, flockId } }) as Href,
  entry: (kind: SingleEntryKind, houseId: string) => ({ pathname: '/entry/[kind]', params: { kind, houseId } }) as Href,
  newFlock: (houseId?: string) => ({ pathname: '/flock/new', params: houseId ? { houseId } : {} }) as Href,
  completeFlock: (flockId: string) => ({ pathname: '/flock/complete', params: { flockId } }) as Href,
  timeline: (flockId?: string) => ({ pathname: '/flock/timeline', params: flockId ? { flockId } : {} }) as Href,
  flockHistory: () => '/flock/history' as Href,
  activity: (flockId?: string) => ({ pathname: '/activity', params: flockId ? { flockId } : {} }) as Href,
  notifications: () => '/notifications' as Href,
  settings: (page: 'farm' | 'alerts' | 'medications' | 'backup' | 'security') => `/settings/${page}` as Href,
};

let last = { key: '', at: 0 };
function guard(href: Href) {
  const key = JSON.stringify(href);
  const t = Date.now();
  // Aynı hedefe 800 ms içinde ikinci basış veya herhangi bir geçişten 250 ms içinde yeni geçiş yok sayılır
  if ((key === last.key && t - last.at < 800) || t - last.at < 250) return false;
  last = { key, at: t };
  return true;
}

export const nav = {
  push(href: Href) { if (guard(href)) router.push(href); },
  /** Sekmelere geçiş: yığına yeni kopya eklemez */
  tab(href: Href) { if (guard(href)) router.navigate(href); },
  replace(href: Href) { last = { key: JSON.stringify(href), at: Date.now() }; router.replace(href); },
  back(fallback: Href = routes.home()) { if (router.canGoBack()) router.back(); else router.replace(fallback); },
  /** Oturum kapatma / sıfırlama: korumalı ekran geçmişini temizler */
  resetTo(href: Href) { try { if (router.canDismiss()) router.dismissAll(); } catch { /* yığın yok */ } router.replace(href); },
  __reset() { last = { key: '', at: 0 }; },
};
