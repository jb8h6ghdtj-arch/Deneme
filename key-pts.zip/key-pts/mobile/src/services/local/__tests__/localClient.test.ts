// Yerel veri katmanı iş kuralları: kalıcılık, atomik günlük kayıt, mükerrer kayıt, yanlış kümese yazmama, kimlik doğrulama.
jest.mock('@react-native-async-storage/async-storage', () => ({ getItem: jest.fn(async () => null), setItem: jest.fn(), removeItem: jest.fn() }));
let mockN = 0;
jest.mock('expo-crypto', () => ({ randomUUID: () => `id-${++mockN}`, digestStringAsync: async (_a: string, s: string) => `h${s.length}:${s.slice(-12)}`, CryptoDigestAlgorithm: { SHA256: 'SHA-256' } }));
const mockDisk: Record<string, Record<string, unknown>> = {}; const mockMeta: Record<string, string> = {};
jest.mock('../storage', () => ({
  storageKind: 'memory',
  loadAll: async () => Object.fromEntries(Object.entries(mockDisk).map(([t, m]) => [t, Object.values(m).map((r) => JSON.parse(JSON.stringify(r)))])),
  putRows: async (t: string, rows: { id: string }[]) => { mockDisk[t] ??= {}; for (const r of rows) mockDisk[t][r.id] = JSON.parse(JSON.stringify(r)); },
  deleteRows: async (t: string, ids: string[]) => { for (const i of ids) delete mockDisk[t]?.[i]; },
  clearAll: async () => { for (const k of Object.keys(mockDisk)) delete mockDisk[k]; for (const k of Object.keys(mockMeta)) delete mockMeta[k]; },
  getMeta: async (k: string) => mockMeta[k] ?? null, setMeta: async (k: string, v: string | null) => { if (v == null) delete mockMeta[k]; else mockMeta[k] = v; },
}));
import { __test, initLocalData, localClient as c } from '../localClient';

const today = new Date().toISOString().slice(0, 10);
const daysAgo = (d: number) => new Date(Date.now() - d * 864e5).toISOString().slice(0, 10);

async function setup() {
  await c.auth.signUp({ email: 'ahmet', password: 'gizli1234', options: { data: { full_name: 'Ahmet' } } });
  await c.auth.signInWithPassword({ email: 'ahmet', password: 'gizli1234' });
  await c.rpc('create_organization_with_farm', { p_org_name: 'Test', p_farm: { name: 'Test Çiftliği' }, p_houses: [{ name: 'Kümes 1', capacity: 10000 }, { name: 'Kümes 2', capacity: 10000 }] });
  const h = (await c.from('houses').select('*').order('sort_order')).data as { id: string; org_id: string; farm_id: string }[];
  const mk = async (house: { id: string; org_id: string; farm_id: string }) => { const r = await c.from('flocks').insert({ org_id: house.org_id, farm_id: house.farm_id, house_id: house.id, name: 'D1', placement_date: daysAgo(10), initial_count: 10000, status: 'active' }).select().single(); if (r.error) throw new Error(JSON.stringify(r.error)); return r.data as { id: string }; };
  const f1 = await mk(h[0]); return { h, f1, f2: await mk(h[1]) };
}
const mort = (flock: string, count: number, cid: string, date = today) => ({ table: 'mortality_entries', row: { client_id: cid, flock_id: flock, entry_date: date, count } });

beforeEach(() => { __test.reset(); for (const k of Object.keys(mockDisk)) delete mockDisk[k]; for (const k of Object.keys(mockMeta)) delete mockMeta[k]; });

describe('yerel veri katmanı', () => {
  it('kayıt diske yazılır ve uygulama yeniden açıldığında geri yüklenir', async () => {
    const { f1 } = await setup();
    expect((await c.rpc('save_daily_record', { parts: [mort(f1.id, 12, 'a1')] })).error).toBeNull();
    __test.coldStart(); await initLocalData();
    const { data } = await c.from('mortality_entries').select('*').eq('flock_id', f1.id);
    expect((data as { count: number }[]).map((r) => r.count)).toEqual([12]);
  });
  it('atomik kayıt: bir parça hatalıysa hiçbiri yazılmaz', async () => {
    const { f1 } = await setup();
    const r = await c.rpc('save_daily_record', { parts: [mort(f1.id, 5, 'b1'), { table: 'temperature_measurements', row: { client_id: 'b2', flock_id: f1.id, entry_date: today, temperature_c: 99, measured_at: new Date().toISOString() } }] });
    expect(r.error).not.toBeNull();
    expect((await c.from('mortality_entries').select('*')).data).toHaveLength(0);
  });
  it('aynı client_id ile tekrar gönderim mükerrer kayıt oluşturmaz (çift dokunma)', async () => {
    const { f1 } = await setup();
    await c.rpc('save_daily_record', { parts: [mort(f1.id, 3, 'c1')] });
    const r = await c.rpc('save_daily_record', { parts: [mort(f1.id, 3, 'c1')] });
    expect((r.data as { duplicate: boolean }[])[0].duplicate).toBe(true);
    expect((await c.from('mortality_entries').select('*')).data).toHaveLength(1);
  });
  it('tek formda iki farklı döneme kayıt reddedilir (yanlış kümese yazma yok)', async () => {
    const { f1, f2 } = await setup();
    const r = await c.rpc('save_daily_record', { parts: [mort(f1.id, 1, 'd1'), mort(f2.id, 1, 'd2')] });
    expect(r.error?.message).toContain('MIXED_FLOCKS');
    expect((await c.from('mortality_entries').select('*')).data).toHaveLength(0);
  });
  it('gelecek tarih, girişten önceki tarih ve mevcut hayvandan fazla ölüm reddedilir', async () => {
    const { f1 } = await setup();
    expect((await c.rpc('save_daily_record', { parts: [mort(f1.id, 1, 'e1', '2999-01-01')] })).error?.message).toContain('DATE_IN_FUTURE');
    expect((await c.rpc('save_daily_record', { parts: [mort(f1.id, 1, 'e2', daysAgo(30))] })).error?.message).toContain('DATE_BEFORE_PLACEMENT');
    expect((await c.rpc('save_daily_record', { parts: [mort(f1.id, 10001, 'e3')] })).error?.message).toContain('EXCEEDS_ALIVE');
  });
  it('bir kümede ikinci aktif dönem açılamaz', async () => {
    const { h } = await setup();
    const r = await c.from('flocks').insert({ org_id: h[0].org_id, farm_id: h[0].farm_id, house_id: h[0].id, name: 'D2', placement_date: today, initial_count: 100, status: 'active' });
    expect(r.error).not.toBeNull();
  });
  it('yanlış şifreyle giriş reddedilir; çıkışta oturum kapanır, veri kalır', async () => {
    const { f1 } = await setup();
    await c.rpc('save_daily_record', { parts: [mort(f1.id, 2, 'g1')] });
    await c.auth.signOut();
    expect((await c.auth.getSession()).data.session).toBeNull();
    expect((await c.auth.signInWithPassword({ email: 'ahmet', password: 'yanlis' })).error).not.toBeNull();
    await c.auth.signInWithPassword({ email: 'ahmet', password: 'gizli1234' });
    expect((await c.from('mortality_entries').select('*')).data).toHaveLength(1);
  });
  it('tüm verileri sıfırla diski temizler', async () => {
    await setup(); await c.resetAll(); __test.coldStart(); await initLocalData();
    expect(Object.values(mockDisk).every((m) => Object.keys(m).length === 0)).toBe(true);
  });
});
