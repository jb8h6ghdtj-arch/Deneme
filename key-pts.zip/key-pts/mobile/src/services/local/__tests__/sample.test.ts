// Demo verisi gerçek veri modeliyle üretilir; ekranlar arası tutarlılık burada doğrulanır.
import { buildDemoDb } from '../sampleData';
import { flockDaily, flockOverview } from '../views';

jest.mock('@react-native-async-storage/async-storage', () => ({ getItem: jest.fn(), setItem: jest.fn(), removeItem: jest.fn() }));

describe('demo veri tutarlılığı', () => {
  const db = buildDemoDb();
  const ov = flockOverview(db);
  const active = ov.filter((f) => f.status === 'active');

  it('3 aktif kümes × 40.000 = 120.000 başlangıç, giriş günü 0 → 23. gün', () => {
    expect(active).toHaveLength(3);
    expect(active.reduce((s, f) => s + f.initial_count, 0)).toBe(120000);
    expect(active.every((f) => f.age_day === 23)).toBe(true);
  });
  it('mevcut = başlangıç − toplam ölüm; toplam ölüm = günlük kayıtların toplamı', () => {
    for (const f of active) {
      const days = flockDaily(db, f.flock_id);
      const sum = days.reduce((s, d) => s + (d.deaths ?? 0), 0);
      expect(f.total_deaths).toBe(sum);
      expect(f.alive_count).toBe(f.initial_count - sum);
      expect(days).toHaveLength(24); // 0..23. gün
    }
  });
  it('Kümes 3: bugün ve 9. gün kayıt yok (sıfır değil), bugünkü ölüm null', () => {
    const k3 = active.find((f) => f.house_name === 'Kümes 3')!;
    const days = flockDaily(db, k3.flock_id);
    expect(days.filter((d) => !d.mortality_recorded).map((d) => d.age_day)).toEqual([9, 23]);
    expect(k3.today_deaths).toBeNull();
  });
  it('kümülatif oran ve günlük oran sunucu formülüyle aynı', () => {
    const f = active[0]; const days = flockDaily(db, f.flock_id);
    const d5 = days[5];
    expect(d5.daily_mortality_pct).toBeCloseTo((d5.deaths! * 100) / d5.start_of_day_alive, 3);
    expect(f.cumulative_mortality_pct).toBe(Math.round(((f.total_deaths * 100) / f.placed_total) * 1000) / 1000); // SQL round(…, 3)
  });
  it('arşivlenmiş dönem yeni dönemle karışmaz', () => {
    const k1 = ov.filter((f) => f.house_name === 'Kümes 1');
    expect(k1.map((f) => f.status).sort()).toEqual(['active', 'completed']);
    const old = k1.find((f) => f.status === 'completed')!, cur = k1.find((f) => f.status === 'active')!;
    expect(cur.total_deaths).toBeLessThan(old.total_deaths);
    expect(db.mortality_entries.filter((e) => e.flock_id === cur.flock_id).every((e) => e.entry_date >= cur.placement_date)).toBe(true);
  });
  it('farklı torba ağırlığı (Kümes 3: 30 kg) kilograma doğru yansır', () => {
    const e = db.coal_entries.find((x) => x.house_id === 'h3-demo')!;
    expect(e.total_kg).toBe(e.bag_count * 30);
  });
});
