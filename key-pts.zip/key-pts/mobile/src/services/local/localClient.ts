// KEY PTS yerel veri istemcisi — tek cihaz, sunucusuz.
//
// Ekranlar ve sorgu kancaları (src/api) bu istemciyi `data` adıyla, Supabase/PostgREST ile aynı sorgu
// biçiminde (from().select().eq()… / rpc / auth) kullanır. İleride sunucu eklendiğinde yalnızca
// src/lib/data.ts içindeki istemci değişir; ekranlar yeniden yazılmaz.
//
// Kalıcılık: her yazma storage.(native.)ts üzerinden diske işlenir ve işlem ancak disk yazımı bittikten
// sonra "başarılı" döner. İş kuralları burada uygulanır (eski sunucu tetikleyicilerinin karşılığı).
import * as Crypto from 'expo-crypto';
import { addDays, averageWeightGrams } from '../../domain/calculations';
import { localDate } from '../../lib/dates';
import { buildSampleDb, type DemoDb } from './sampleData';
import * as store from './storage';
import { activity, computeAlerts, flockDaily, flockOverview } from './views';

type Row = Record<string, any>;
export interface Res<T = any> { data: T; error: { message: string; code?: string } | null; status: number; count?: number }
export interface Session { access_token: string; user: { id: string; email: string; user_metadata: { full_name: string; phone?: string | null } } }

const ENTRY_TABLES = ['mortality_entries', 'coal_entries', 'medication_applications', 'weight_measurements', 'temperature_measurements', 'daily_notes', 'flock_movements', 'dispatch_records'];
const AUDITED = new Set([...ENTRY_TABLES, 'flocks', 'houses', 'farms', 'alert_settings', 'medication_products']);

let db: DemoDb = {};
let session: Session | null = null;
let readIds = new Set<string>();
let sample = false;
let ready: Promise<void> | null = null;
const authListeners = new Set<(e: string, s: Session | null) => void>();
const changeListeners = new Set<() => void>();
let seq = 0;
const nid = (p: string) => `${p}-${Date.now().toString(36)}-${(++seq).toString(36)}${Math.random().toString(36).slice(2, 6)}`;
const now = () => new Date().toISOString();
const ok = <T>(data: T, status = 200): Res<T> => ({ data, error: null, status });
const fail = (message: string, status = 400): Res<null> => ({ data: null, error: { message }, status });
const T = (name: string) => (db[name] ??= []);

/** Uygulama açılışında bir kez çağrılır: diskten bütün kayıtları yükler. */
export function initLocalData(): Promise<void> {
  ready ??= (async () => {
    db = (await store.loadAll()) as DemoDb;
    const s = await store.getMeta('session');
    session = s ? JSON.parse(s) : null;
    readIds = new Set(JSON.parse((await store.getMeta('read_alerts')) ?? '[]'));
    sample = (await store.getMeta('sample_data')) === '1';
  })();
  return ready;
}
export const isSampleData = () => sample;
export const hasAccount = () => T('local_accounts').length > 0;
/** Veri değiştiğinde (sorguları yenilemek için) haber verir */
export const onDataChange = (fn: () => void) => { changeListeners.add(fn); return () => { changeListeners.delete(fn); }; };

async function commit(put: Record<string, Row[]> = {}, del: Record<string, string[]> = {}) {
  for (const [t, rows] of Object.entries(put)) await store.putRows(t, rows as Row[] & { id: string }[]);
  for (const [t, ids] of Object.entries(del)) await store.deleteRows(t, ids);
  changeListeners.forEach((l) => l());
}

function audit(table: string, action: 'INSERT' | 'UPDATE', oldRow: Row | null, newRow: Row): Row | null {
  if (!AUDITED.has(table)) return null;
  const changed = oldRow ? Object.keys(newRow).filter((k) => !['updated_at', 'version', 'updated_by'].includes(k) && JSON.stringify(newRow[k]) !== JSON.stringify(oldRow[k])) : null;
  if (action === 'UPDATE' && !changed?.length) return null;
  return { id: nid('au'), org_id: newRow.org_id ?? null, house_id: table === 'houses' ? newRow.id : newRow.house_id ?? null, flock_id: table === 'flocks' ? newRow.id : newRow.flock_id ?? null,
    table_name: table, record_id: newRow.id, action, actor_id: session?.user.id ?? null, old_data: oldRow, new_data: newRow, changed_fields: changed, created_at: now() };
}

const aliveOf = (flockId: string) => flockOverview(db).find((x) => x.flock_id === flockId)?.alive_count ?? 0;

/** Operasyon kaydı türetme ve doğrulama (eski tg_entry_context / tg_check_alive / normalize tetikleyicileri) */
function prepareEntry(table: string, row: Row): Row | string {
  const f = T('flocks').find((x) => x.id === row.flock_id);
  if (!f) return 'FLOCK_NOT_FOUND';
  if (f.status !== 'active' && table !== 'dispatch_records') return 'FLOCK_CLOSED';
  const entryDate = table === 'temperature_measurements' && row.measured_at ? localDate(new Date(row.measured_at)) : row.entry_date;
  if (!entryDate) return 'DATE_REQUIRED';
  if (entryDate > localDate()) return 'DATE_IN_FUTURE';
  if (entryDate < f.placement_date) return 'DATE_BEFORE_PLACEMENT';
  const out: Row = { id: nid(table.slice(0, 3)), version: 1, deleted_at: null, note: null, created_at: now(), updated_at: now(), ...row,
    entry_date: entryDate, org_id: f.org_id, farm_id: f.farm_id, house_id: f.house_id, created_by: session?.user.id };
  const num = (v: unknown) => (v == null || v === '' ? NaN : Number(v));
  switch (table) {
    case 'mortality_entries': {
      const c = num(row.count);
      if (!Number.isInteger(c) || c < 0) return 'INVALID_COUNT';
      const alive = aliveOf(f.id);
      if (c > alive) return `EXCEEDS_ALIVE: girilen sayı (${c}) mevcut hayvan sayısını (${alive}) aşıyor`;
      out.count = c; break;
    }
    case 'coal_entries': {
      const b = num(row.bag_count), kg = num(row.bag_weight_kg);
      if (!(b >= 0 && b <= 1000) || !(kg > 0 && kg <= 100)) return 'INVALID_COAL';
      out.bag_count = b; out.bag_weight_kg = kg; out.total_kg = Math.round(b * kg * 100) / 100; break;
    }
    case 'weight_measurements': {
      const s = num(row.sample_count), v = num(row.input_value);
      if (!(s >= 1 && s <= 10000) || !(v > 0)) return 'INVALID_WEIGHT';
      out.avg_weight_g = averageWeightGrams(v, row.input_unit, row.input_mode, s);
      if (out.avg_weight_g < 10 || out.avg_weight_g > 8000) return 'INVALID_WEIGHT';
      break;
    }
    case 'medication_applications': {
      const p = T('medication_products').find((x) => x.id === row.product_id);
      if (!p) return 'PRODUCT_NOT_FOUND';
      if (!(num(row.amount) > 0)) return 'INVALID_AMOUNT';
      out.product_name = p.name; out.withdrawal_days = Number(row.withdrawal_days ?? 0) || p.withdrawal_days || 0;
      out.withdrawal_end_date = addDays(entryDate, out.withdrawal_days); break;
    }
    case 'temperature_measurements': {
      const t = num(row.temperature_c);
      if (!(t >= -30 && t <= 60)) return 'INVALID_TEMPERATURE';
      if (row.humidity_pct != null && !(num(row.humidity_pct) >= 0 && num(row.humidity_pct) <= 100)) return 'INVALID_HUMIDITY';
      break;
    }
    case 'daily_notes': if (!String(row.body ?? '').trim()) return 'NOTE_REQUIRED'; break;
    case 'dispatch_records': {
      const n = num(row.bird_count); const alive = aliveOf(f.id);
      if (!(n > 0)) return 'INVALID_COUNT';
      if (n > alive) return `EXCEEDS_ALIVE: sevk sayısı (${n}) mevcut hayvan sayısını (${alive}) aşıyor`;
      out.avg_weight_kg = row.total_live_weight_kg ? Math.round((Number(row.total_live_weight_kg) / n) * 1000) / 1000 : null; break;
    }
  }
  return out;
}

class Query implements PromiseLike<Res> {
  private filters: ((r: Row) => boolean)[] = [];
  private orders: [string, boolean][] = [];
  private lim?: number;
  private mode: 'select' | 'insert' | 'update' | 'delete' = 'select';
  private payload: any;
  private opts: any;
  private singleMode: 'single' | 'maybe' | null = null;
  constructor(private table: string) {}
  select(_c?: string) { return this; }
  eq(c: string, v: unknown) { this.filters.push((r) => r[c] === v); return this; }
  neq(c: string, v: unknown) { this.filters.push((r) => r[c] !== v); return this; }
  in(c: string, v: unknown[]) { this.filters.push((r) => v.includes(r[c])); return this; }
  is(c: string, v: unknown) { this.filters.push((r) => (v === null ? r[c] == null : r[c] === v)); return this; }
  gte(c: string, v: any) { this.filters.push((r) => r[c] >= v); return this; }
  lte(c: string, v: any) { this.filters.push((r) => r[c] <= v); return this; }
  order(c: string, o?: { ascending?: boolean }) { this.orders.push([c, o?.ascending !== false]); return this; }
  limit(n: number) { this.lim = n; return this; }
  single() { this.singleMode = 'single'; return this; }
  maybeSingle() { this.singleMode = 'maybe'; return this; }
  insert(p: Row | Row[]) { this.mode = 'insert'; this.payload = p; return this; }
  upsert(p: Row | Row[], o?: { onConflict?: string; ignoreDuplicates?: boolean }) { this.mode = 'insert'; this.payload = p; this.opts = o; return this; }
  update(p: Row) { this.mode = 'update'; this.payload = p; return this; }
  delete() { this.mode = 'delete'; return this; }
  then<A = Res, B = never>(onOk?: ((v: Res) => A | PromiseLike<A>) | null, onErr?: ((e: unknown) => B | PromiseLike<B>) | null): PromiseLike<A | B> {
    return initLocalData().then(() => this.exec()).catch((e) => fail(String(e?.message ?? e), 500)).then(onOk, onErr);
  }

  private source(): Row[] {
    switch (this.table) {
      case 'v_flock_overview': return flockOverview(db);
      case 'v_flock_daily': return T('flocks').flatMap((f) => flockDaily(db, f.id));
      case 'v_activity': return activity(db);
      case 'notifications': return computeAlerts(db).map((n) => ({ ...n, user_id: session?.user.id, read_at: readIds.has(n.id) ? 'read' : null }));
      case 'organization_members': return T('organization_members').map((m) => ({ ...m, organizations: T('organizations').find((o) => o.id === m.org_id) }));
      default: return T(this.table);
    }
  }

  private async exec(): Promise<Res> {
    if (!session && this.table !== 'local_accounts') return fail('NOT_AUTHENTICATED', 401);
    const t = this.table;
    if (this.mode === 'insert') return this.shape(await this.doInsert());
    let rows = this.source().filter((r) => this.filters.every((f) => f(r)));
    if (this.mode === 'update') return this.shape(await this.doUpdate(rows));
    if (this.mode === 'delete') {
      const ids = rows.map((r) => r.id); db[t] = T(t).filter((r) => !ids.includes(r.id));
      await commit({}, { [t]: ids }); return ok(null, 204);
    }
    for (const [c, asc] of [...this.orders].reverse()) rows = [...rows].sort((a, b) => (a[c] === b[c] ? 0 : (a[c] ?? '') > (b[c] ?? '') ? (asc ? 1 : -1) : asc ? -1 : 1));
    if (this.lim) rows = rows.slice(0, this.lim);
    const copy = (r: Row) => JSON.parse(JSON.stringify(r));
    if (this.singleMode) {
      if (!rows.length && this.singleMode === 'single') return { data: null, error: { message: 'NOT_FOUND', code: 'PGRST116' }, status: 406 };
      return ok(rows[0] ? copy(rows[0]) : null);
    }
    return ok(rows.map(copy));
  }

  /** insert/update sonrası .single()/.maybeSingle() istendiyse dizi yerine tek satır döndür */
  private shape(r: Res): Res {
    if (!this.singleMode || r.error || !Array.isArray(r.data)) return r;
    const rows = r.data as Row[];
    if (!rows.length && this.singleMode === 'single') return { data: null, error: { message: 'NOT_FOUND', code: 'PGRST116' }, status: 406 };
    return { ...r, data: rows[0] ?? null };
  }

  private async doInsert(): Promise<Res> {
    const t = this.table;
    const input = (Array.isArray(this.payload) ? this.payload : [this.payload]) as Row[];
    const created: Row[] = []; const put: Row[] = [];
    for (const row of input) {
      // İdempotent: aynı işlem kimliği (client_id) ikinci kez gelirse yeni kayıt oluşmaz
      if (row.client_id) { const ex = T(t).find((x) => x.client_id === row.client_id); if (ex) { created.push(ex); continue; } }
      if (this.opts?.onConflict && this.opts.onConflict !== 'client_id') {
        const keys = String(this.opts.onConflict).split(',');
        const ex = T(t).find((x) => keys.every((k) => x[k] === row[k]));
        if (ex) { Object.assign(ex, row, { updated_at: now() }); put.push(ex); created.push(ex); continue; }
      }
      let out: Row;
      if (ENTRY_TABLES.includes(t)) {
        const r = prepareEntry(t, row); if (typeof r === 'string') return fail(r);
        out = r;
      } else if (t === 'flocks') {
        const h = T('houses').find((x) => x.id === row.house_id);
        if (!h) return fail('HOUSE_NOT_FOUND');
        if (h.archived_at) return fail('HOUSE_ARCHIVED');
        if (T('flocks').some((x) => x.house_id === h.id && x.status === 'active')) return fail('flocks_one_active_per_house');
        if (!(Number(row.initial_count) > 0)) return fail('INVALID_COUNT');
        if (Number(row.initial_count) > h.capacity * 1.2) return fail('INITIAL_EXCEEDS_CAPACITY');
        if (row.placement_date > localDate()) return fail('DATE_IN_FUTURE');
        if (row.expected_slaughter_date && row.expected_slaughter_date < row.placement_date) return fail('SLAUGHTER_BEFORE_PLACEMENT');
        const cyc = Math.max(0, ...T('flocks').filter((x) => x.house_id === h.id).map((x) => x.cycle_no)) + 1;
        out = { id: nid('fl'), version: 1, breed: null, description: null, responsible_user_id: null, expected_slaughter_date: null, ...row,
          org_id: h.org_id, farm_id: h.farm_id, cycle_no: cyc, name: row.name || `${h.name} — ${cyc}. Dönem`, status: 'active', completed_at: null, created_by: session?.user.id, created_at: now() };
      } else if (t === 'houses') {
        const farm = T('farms').find((x) => x.id === row.farm_id);
        if (!farm) return fail('FARM_NOT_FOUND');
        if (!String(row.name ?? '').trim()) return fail('NAME_REQUIRED');
        if (T('houses').some((x) => x.farm_id === row.farm_id && x.name.trim().toLocaleLowerCase('tr') === String(row.name).trim().toLocaleLowerCase('tr'))) return fail('houses_farm_id_name_key');
        if (!(Number(row.capacity) > 0 && Number(row.capacity) <= 1_000_000)) return fail('INVALID_CAPACITY');
        out = { id: nid('h'), archived_at: null, heating_type: 'coal', sort_order: T('houses').length + 1, ...row, org_id: farm.org_id, coal_tracking: (row.heating_type ?? 'coal') === 'coal', created_at: now() };
      } else if (t === 'medication_products') {
        if (T(t).some((x) => x.name.toLocaleLowerCase('tr') === String(row.name).trim().toLocaleLowerCase('tr'))) return fail('medication_products_org_name');
        out = { id: nid('p'), is_active: true, category: 'other', default_method: null, active_ingredient: null, withdrawal_days: 0, ...row, created_at: now() };
      } else {
        out = { id: nid(t.slice(0, 2)), created_at: now(), ...row };
      }
      T(t).push(out); put.push(out); created.push(out);
    }
    await commit({ [t]: put });
    return ok(created.map((r) => ({ ...r })), 201);
  }

  private async doUpdate(rows: Row[]): Promise<Res> {
    const t = this.table;
    if (t === 'notifications') {
      rows.forEach((r) => readIds.add(r.id));
      await store.setMeta('read_alerts', JSON.stringify([...readIds].slice(-2000)));
      changeListeners.forEach((l) => l());
      return ok(rows);
    }
    const changed: Row[] = []; const audits: Row[] = [];
    for (const r of rows) {
      const real = T(t).find((x) => x.id === r.id || (t === 'alert_settings' && x.farm_id === r.farm_id));
      if (!real) continue;
      const old = JSON.parse(JSON.stringify(real));
      if (ENTRY_TABLES.includes(t)) {
        if (T('flocks').find((x) => x.id === real.flock_id)?.status !== 'active') return fail('FLOCK_CLOSED');
        if ('flock_id' in this.payload && this.payload.flock_id !== real.flock_id) return fail('FLOCK_IMMUTABLE');
        if (t === 'mortality_entries' && this.payload.count != null) {
          const c = Number(this.payload.count); const alive = aliveOf(real.flock_id) + (real.deleted_at ? 0 : real.count);
          if (!Number.isInteger(c) || c < 0) return fail('INVALID_COUNT');
          if (c > alive) return fail(`EXCEEDS_ALIVE: girilen sayı (${c}) mevcut hayvan sayısını (${alive}) aşıyor`);
        }
      }
      if (t === 'flocks') {
        if (real.status !== 'active' && ['status', 'initial_count', 'placement_date'].some((k) => k in this.payload && this.payload[k] !== real[k])) return fail('FLOCK_CLOSED');
        if (this.payload.placement_date && this.payload.placement_date > real.placement_date
          && ENTRY_TABLES.some((et) => T(et).some((e) => e.flock_id === real.id && !e.deleted_at && e.entry_date < this.payload.placement_date))) return fail('PLACEMENT_AFTER_ENTRIES');
        if (this.payload.expected_slaughter_date && this.payload.expected_slaughter_date < (this.payload.placement_date ?? real.placement_date)) return fail('SLAUGHTER_BEFORE_PLACEMENT');
      }
      Object.assign(real, this.payload, { updated_at: now(), updated_by: session?.user.id, version: (real.version ?? 0) + 1 });
      if (t === 'coal_entries') real.total_kg = Math.round(real.bag_count * real.bag_weight_kg * 100) / 100;
      changed.push(real);
      const a = audit(t, 'UPDATE', old, real); if (a) { T('audit_logs').push(a); audits.push(a); }
    }
    await commit({ [t]: changed, audit_logs: audits });
    return ok(changed.map((r) => ({ ...r })));
  }
}

async function hash(password: string, salt: string) {
  let h = `${salt}:${password}`;
  for (let i = 0; i < 300; i++) h = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, `${salt}${h}`);
  return h;
}
async function setSession(s: Session | null, event: string) {
  session = s;
  await store.setMeta('session', s ? JSON.stringify(s) : null);
  authListeners.forEach((l) => l(event, s));
}
const toSession = (a: Row): Session => ({ access_token: 'local', user: { id: a.id, email: a.username, user_metadata: { full_name: a.full_name, phone: a.phone } } });

function closingSummary(flockId: string) {
  const f = T('flocks').find((x) => x.id === flockId); if (!f) return null;
  const days = flockDaily(db, f.id); const ov = flockOverview(db).find((x) => x.flock_id === f.id)!;
  const live = (t: string) => T(t).filter((m) => m.flock_id === f.id && !m.deleted_at);
  const grouped = Object.values(live('medication_applications').reduce((acc: Row, m) => {
    const k = m.product_name + m.unit; acc[k] ??= { product: m.product_name, unit: m.unit, applications: 0, total: 0 }; acc[k].applications++; acc[k].total += Number(m.amount); return acc; }, {}));
  const mov = live('flock_movements');
  return { flock_id: f.id, initial_count: f.initial_count, placed_total: ov.placed_total, total_deaths: ov.total_deaths,
    birds_in: mov.filter((m) => ['addition', 'transfer_in'].includes(m.movement_type)).reduce((s, m) => s + m.count, 0),
    birds_out: mov.filter((m) => !['addition', 'transfer_in'].includes(m.movement_type)).reduce((s, m) => s + m.count, 0),
    dispatched: live('dispatch_records').reduce((s, d) => s + d.bird_count, 0), alive_unaccounted: ov.alive_count,
    coal_bags: live('coal_entries').reduce((s, c) => s + Number(c.bag_count), 0), coal_kg: live('coal_entries').reduce((s, c) => s + Number(c.total_kg), 0),
    medications: grouped, mortality_days_missing: days.filter((d) => !d.mortality_recorded).length, days: days.length };
}

async function rpc(name: string, a: Row = {}): Promise<Res> {
  await initLocalData();
  if (!session) return fail('NOT_AUTHENTICATED', 401);
  switch (name) {
    case 'create_organization_with_farm': {
      if (T('organizations').length) return fail('FARM_ALREADY_EXISTS');
      const org = { id: nid('org'), name: a.p_org_name, created_at: now() };
      const farm = { id: nid('farm'), org_id: org.id, name: a.p_farm.name, location_text: a.p_farm.location_text ?? null, contact_name: a.p_farm.contact_name ?? null,
        contact_phone: a.p_farm.contact_phone ?? null, contact_email: null, default_heating: a.p_farm.default_heating ?? 'coal', default_coal_bag_kg: a.p_farm.default_coal_bag_kg ?? 25,
        chick_phase_days: 15, age_base: a.p_farm.age_base ?? 0, timezone: 'Europe/Istanbul', created_at: now() };
      const houses = (a.p_houses as Row[]).map((h, i) => ({ id: nid('h'), org_id: org.id, farm_id: farm.id, name: h.name, capacity: h.capacity, heating_type: h.heating_type ?? 'coal',
        coal_tracking: (h.heating_type ?? 'coal') === 'coal', sort_order: i + 1, archived_at: null, created_at: now() }));
      const member = { id: nid('m'), org_id: org.id, user_id: session.user.id, role: 'owner' };
      const profile = { id: session.user.id, full_name: session.user.user_metadata.full_name, phone: session.user.user_metadata.phone ?? null, locale: 'tr' };
      const alerts = { id: farm.id, farm_id: farm.id, org_id: org.id, daily_mortality_warn_pct: 0.3, daily_mortality_critical_pct: 0.6, cumulative_warn_pct: 3, cumulative_critical_pct: 5, missing_report_hour: 20, slaughter_reminder_days: 3 };
      T('organizations').push(org); T('farms').push(farm); T('houses').push(...houses); T('organization_members').push(member); T('profiles').push(profile); T('alert_settings').push(alerts);
      await commit({ organizations: [org], farms: [farm], houses, organization_members: [member], profiles: [profile], alert_settings: [alerts] });
      return ok({ org_id: org.id, farm_id: farm.id });
    }
    case 'load_sample_data': {
      if (T('organizations').length) return fail('FARM_ALREADY_EXISTS');
      const s = buildSampleDb({ id: session.user.id, full_name: session.user.user_metadata.full_name });
      for (const [t, rows] of Object.entries(s)) {
        const withIds = rows.map((r) => ({ id: r.id ?? (t === 'alert_settings' ? r.farm_id : nid(t.slice(0, 2))), ...r }));
        db[t] = withIds; await store.putRows(t, withIds as never);
      }
      sample = true; await store.setMeta('sample_data', '1'); changeListeners.forEach((l) => l());
      return ok({ org_id: 'org-demo', farm_id: 'farm-demo' });
    }
    case 'save_daily_record': {
      // Günlük kayıt formu: bütün parçalar önce doğrulanır; biri hatalıysa hiçbiri yazılmaz (ya hepsi ya hiçbiri).
      const parts = a.parts as { table: string; row: Row }[];
      const flockIds = new Set(parts.map((p) => p.row.flock_id));
      if (flockIds.size !== 1) return fail('MIXED_FLOCKS'); // bir formdaki bütün kayıtlar aynı döneme ait olmalı
      const prepared: { table: string; row: Row; duplicate: boolean }[] = [];
      let pendingDeaths = 0;
      for (const p of parts) {
        if (!ENTRY_TABLES.includes(p.table)) return fail('INVALID_TABLE');
        const ex = T(p.table).find((x) => x.client_id === p.row.client_id);
        if (ex) { prepared.push({ table: p.table, row: ex, duplicate: true }); continue; }
        const r = prepareEntry(p.table, p.row);
        if (typeof r === 'string') return fail(r);
        if (p.table === 'mortality_entries') pendingDeaths += r.count;
        prepared.push({ table: p.table, row: r, duplicate: false });
      }
      if (pendingDeaths > aliveOf([...flockIds][0])) return fail('EXCEEDS_ALIVE');
      const put: Record<string, Row[]> = {};
      for (const p of prepared) if (!p.duplicate) { T(p.table).push(p.row); (put[p.table] ??= []).push(p.row); }
      await commit(put);
      return ok(prepared.map((p) => ({ table: p.table, id: p.row.id, client_id: p.row.client_id, duplicate: p.duplicate })));
    }
    case 'flock_closing_summary': { const s = closingSummary(a.p_flock); return s ? ok(s) : fail('FLOCK_NOT_FOUND'); }
    case 'complete_flock': {
      const f = T('flocks').find((x) => x.id === a.p_flock); if (!f) return fail('FLOCK_NOT_FOUND');
      if (T('dispatch_records').some((d) => d.client_id === a.p_client_id)) return ok(closingSummary(f.id)); // tekrar gönderim
      if (f.status !== 'active') return fail('FLOCK_CLOSED');
      const d = prepareEntry('dispatch_records', { client_id: a.p_client_id, flock_id: f.id, entry_date: a.p_dispatch_date, bird_count: a.p_bird_count,
        total_live_weight_kg: a.p_total_live_weight_kg ?? null, destination: a.p_destination ?? null, note: a.p_notes ?? null });
      if (typeof d === 'string') return fail(d);
      const old = JSON.parse(JSON.stringify(f));
      T('dispatch_records').push(d);
      Object.assign(f, { status: 'completed', completed_at: now(), closing_notes: a.p_notes ?? null, version: f.version + 1 });
      const au = audit('flocks', 'UPDATE', old, f)!; T('audit_logs').push(au);
      await commit({ dispatch_records: [d], flocks: [f], audit_logs: [au] });
      const s = closingSummary(f.id)!;
      return ok({ ...s, discrepancy: s.alive_unaccounted, discrepancy_message: s.alive_unaccounted ? `Kayıtlara göre ${s.alive_unaccounted} hayvan ölüm/çıkış/sevk ile açıklanamıyor.` : null });
    }
    default: return fail(`UNSUPPORTED_RPC: ${name}`);
  }
}

export const localClient = {
  from: (t: string) => new Query(t),
  rpc,
  auth: {
    async getSession() { await initLocalData(); return { data: { session }, error: null }; },
    onAuthStateChange(fn: (e: string, s: Session | null) => void) { authListeners.add(fn); return { data: { subscription: { unsubscribe: () => { authListeners.delete(fn); } } } }; },
    /** Yerel hesap oluşturma (tek cihaz). Şifre tuzlu SHA-256 özetiyle saklanır, düz metin tutulmaz. */
    async signUp({ email, password, options }: { email: string; password: string; options?: { data?: { full_name?: string; phone?: string } } }) {
      await initLocalData();
      if (hasAccount()) return { data: { session: null }, error: { message: 'ACCOUNT_EXISTS' } };
      const salt = Crypto.randomUUID();
      const acc = { id: `u-${Crypto.randomUUID()}`, username: email.trim().toLocaleLowerCase('tr'), full_name: options?.data?.full_name ?? 'Çiftlik Sahibi', phone: options?.data?.phone ?? null,
        salt, password_hash: await hash(password, salt), created_at: now() };
      T('local_accounts').push(acc); await store.putRows('local_accounts', [acc as any]);
      await setSession(toSession(acc), 'SIGNED_IN');
      return { data: { session }, error: null };
    },
    async signInWithPassword({ email, password }: { email: string; password: string }) {
      await initLocalData();
      const acc = T('local_accounts').find((x) => x.username === email.trim().toLocaleLowerCase('tr'));
      if (!acc || (await hash(password, acc.salt)) !== acc.password_hash) return { data: { session: null }, error: { message: 'Invalid login credentials' } };
      await setSession(toSession(acc), 'SIGNED_IN');
      return { data: { session }, error: null };
    },
    async signOut() { await setSession(null, 'SIGNED_OUT'); return { error: null }; },
    async updateUser({ password }: { password?: string }) {
      const acc = T('local_accounts').find((x) => x.id === session?.user.id);
      if (!acc || !password) return { data: null, error: { message: 'NOT_AUTHENTICATED' } };
      acc.salt = Crypto.randomUUID(); acc.password_hash = await hash(password, acc.salt);
      await store.putRows('local_accounts', [acc as any]); return { data: {}, error: null };
    },
    /** Yerel şifre sıfırlama: kullanıcı adı + kurulumda girilen çiftlik adı doğrulanır (sunucu yok). */
    async resetPasswordLocal({ username, farmName, newPassword }: { username: string; farmName: string; newPassword: string }) {
      await initLocalData();
      const acc = T('local_accounts').find((x) => x.username === username.trim().toLocaleLowerCase('tr'));
      const farm = T('farms')[0];
      if (!acc || !farm || farm.name.trim().toLocaleLowerCase('tr') !== farmName.trim().toLocaleLowerCase('tr')) return { error: { message: 'RECOVERY_MISMATCH' } };
      acc.salt = Crypto.randomUUID(); acc.password_hash = await hash(newPassword, acc.salt);
      await store.putRows('local_accounts', [acc as any]); return { error: null };
    },
    startAutoRefresh() {}, stopAutoRefresh() {},
  },
  /** Bütün yerel verileri siler (Ayarlar → Veri Yönetimi). */
  async resetAll() { await store.clearAll(); db = {}; readIds = new Set(); sample = false; await setSession(null, 'SIGNED_OUT'); changeListeners.forEach((l) => l()); },
  /** Yalnız örnek verileri siler; hesap korunur, kullanıcı sıfırdan kurulum yapar. */
  async clearSampleData() {
    const keep = T('local_accounts'); await store.clearAll(); db = { local_accounts: keep }; await store.putRows('local_accounts', keep as never);
    await store.setMeta('session', session ? JSON.stringify(session) : null); sample = false; readIds = new Set(); changeListeners.forEach((l) => l());
  },
  /** Yedek dışa aktarma: bütün tablolar (şifre özetleri hariç) */
  exportAll() { const { local_accounts: _a, ...rest } = db; return JSON.parse(JSON.stringify(rest)) as DemoDb; },
  storageKind: () => store.storageKind,
};

export type LocalClient = typeof localClient;
/** Test yardımcıları */
export const __test = { coldStart: () => { db = {}; session = null; ready = null; readIds = new Set(); sample = false; }, reset: () => { db = {}; session = null; ready = Promise.resolve(); readIds = new Set(); sample = false; }, db: () => db };
