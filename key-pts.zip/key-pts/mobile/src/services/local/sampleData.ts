// ÖRNEK VERİ üreticisi. Yalnızca kullanıcı ilk açılışta "Örnek verilerle incele" seçerse yüklenir;
// yüklendiğinde her ekranda ÖRNEK etiketi görünür ve Ayarlar'dan tamamen silinebilir.
// Bütün kayıtlar gerçek veri modelinin tablolarıyla aynı şekildedir; görünümler (v_*) bu tablolardan
// demoViews.ts içinde sunucudaki SQL tanımlarıyla aynı formüllerle hesaplanır → ekranlar arası tutarlılık.
import { addDays } from '../../domain/calculations';
import { istanbulLocalToIso, localDate } from '../../lib/dates';

type Row = Record<string, any>;
export interface DemoDb { [table: string]: Row[] }

function rng(seed: number) {
  return () => { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
let seq = 0;
const id = (p: string) => `${p}-${(++seq).toString(16).padStart(8, '0')}-demo`;

export const DEMO_USERS = {
  owner: { id: 'u-owner-demo', email: 'sahip@demo.keypts', full_name: 'Kemal Yılmaz', role: 'owner' },
  manager: { id: 'u-manager-demo', email: 'sorumlu@demo.keypts', full_name: 'Murat Demir', role: 'manager' },
  worker1: { id: 'u-worker1-demo', email: 'bakici@demo.keypts', full_name: 'Ali Kaya', role: 'worker' },
  worker2: { id: 'u-worker2-demo', email: 'bakici2@demo.keypts', full_name: 'Veli Şahin', role: 'worker' },
} as const;

/** Ross tipi örnek büyüme eğrisi (yalnız demo verisi için; hedef/öneri değildir) */
const curve = (d: number) => Math.round(42 + 9.5 * d + 1.75 * d * d - 0.012 * d * d * d);

export function buildDemoDb(): DemoDb {
  seq = 0;
  const r = rng(20261105);
  const today = localDate();
  const ORG = 'org-demo', FARM = 'farm-demo';
  const at = (date: string, hhmm: string) => istanbulLocalToIso(date, hhmm);
  const db: DemoDb = {
    organizations: [{ id: ORG, name: 'KEY Tarım', created_at: at(addDays(today, -120), '09:00') }],
    profiles: Object.values(DEMO_USERS).map((u) => ({ id: u.id, full_name: u.full_name, phone: '0 5xx xxx xx xx', locale: 'tr' })),
    organization_members: Object.values(DEMO_USERS).map((u) => ({ id: id('m'), org_id: ORG, user_id: u.id, role: u.role })),
    farms: [{ id: FARM, org_id: ORG, name: 'KEY Broiler Çiftliği', location_text: 'Bolu / Mengen', default_heating: 'coal', default_coal_bag_kg: 25,
      chick_phase_days: 15, age_base: 0, timezone: 'Europe/Istanbul', contact_name: 'Kemal Yılmaz', contact_phone: '0 5xx xxx xx xx', contact_email: 'sahip@demo.keypts', created_at: at(addDays(today, -120), '09:00') }],
    houses: [], house_assignments: [], flocks: [], mortality_entries: [], coal_entries: [], medication_products: [], medication_applications: [],
    weight_measurements: [], temperature_measurements: [], daily_notes: [], flock_movements: [], dispatch_records: [], notifications: [],
    alert_settings: [{ farm_id: FARM, org_id: ORG, daily_mortality_warn_pct: 0.05, daily_mortality_critical_pct: 0.1, cumulative_warn_pct: 3, cumulative_critical_pct: 5, missing_report_hour: 11, slaughter_reminder_days: 3 }],
    temperature_targets: [[0, 3, 31, 34], [4, 7, 29, 32], [8, 14, 27, 30], [15, 21, 24, 28], [22, 35, 22, 26], [36, 60, 20, 24]].map(([a, b, mn, mx]) => ({ id: id('tt'), org_id: ORG, farm_id: FARM, day_from: a, day_to: b, min_c: mn, max_c: mx })),
    weight_targets: [0, 7, 14, 21, 28, 35, 42].map((d) => ({ id: id('wt'), org_id: ORG, farm_id: FARM, age_day: d, target_g: Math.round(curve(d) * 1.04) })),
    notification_preferences: Object.values(DEMO_USERS).map((u) => ({ user_id: u.id, org_id: ORG, push_enabled: true, on_new_entry: false, on_mortality: true, on_missing_report: true, on_temperature: true, on_slaughter: true, on_withdrawal: true })),
    invitations: [], audit_logs: [], push_tokens: [],
  };

  const houseDefs = [
    { name: 'Kümes 1', capacity: 40000, bag: 25, worker: DEMO_USERS.worker1.id },
    { name: 'Kümes 2', capacity: 40000, bag: 25, worker: DEMO_USERS.worker1.id },
    { name: 'Kümes 3', capacity: 40000, bag: 30, worker: DEMO_USERS.worker2.id }, // farklı torba ağırlığı
    { name: 'Kümes 4', capacity: 30000, bag: 25, worker: DEMO_USERS.worker2.id }, // pasif: aktif dönem yok
  ];
  const products = [
    ['Ürün A', 'antibiotic', 'ml', 'drinking_water', 28], ['Ürün B', 'vitamin', 'ml', 'drinking_water', 0], ['Ürün C', 'electrolyte', 'g', 'drinking_water', 0],
    ['Ürün D', 'probiotic', 'g', 'feed', 0], ['Ürün E', 'coccidiostat', 'g', 'feed', 5], ['Ürün F', 'respiratory_support', 'ml', 'spray', 0], ['Ürün G', 'liver_support', 'ml', 'drinking_water', 0],
  ].map(([name, category, unit, method, wd]) => ({ id: id('p'), org_id: ORG, name, category, default_unit: unit, default_method: method, withdrawal_days: Number(wd), active_ingredient: null, is_active: true }));
  db.medication_products = products;

  const mkEntry = (t: string, f: Row, date: string, hhmm: string, by: string, fields: Row) => {
    const created = at(date, hhmm);
    db[t].push({ id: id(t.slice(0, 3)), client_id: id('c'), org_id: ORG, farm_id: FARM, house_id: f.house_id, flock_id: f.id, entry_date: date,
      created_by: by, created_at: created, updated_at: created, recorded_at: created, version: 1, deleted_at: null, note: null, ...fields });
  };

  houseDefs.forEach((h, hi) => {
    const house = { id: `h${hi + 1}-demo`, org_id: ORG, farm_id: FARM, name: h.name, capacity: h.capacity, heating_type: 'coal', coal_tracking: true, sort_order: hi + 1, archived_at: null };
    db.houses.push(house);
    db.house_assignments.push({ id: id('a'), org_id: ORG, house_id: house.id, user_id: h.worker, permissions: ['record'] });
    if (hi < 3) db.house_assignments.push({ id: id('a'), org_id: ORG, house_id: house.id, user_id: DEMO_USERS.manager.id, permissions: ['record', 'manage'] });

    // Geçmiş (tamamlanmış) dönem — arşiv örneği
    if (hi === 0 || hi === 3) {
      const pl = addDays(today, hi === 0 ? -104 : -82), end = addDays(pl, 44);
      const pf: Row = { id: `f${hi + 1}-old-demo`, org_id: ORG, farm_id: FARM, house_id: house.id, cycle_no: 1, name: `Sürü #${pl.slice(0, 4)}-${pl.slice(5, 7)}`, placement_date: pl,
        initial_count: h.capacity - 1000, breed: 'Ross 308', expected_slaughter_date: end, status: 'completed', completed_at: at(end, '16:00'), responsible_user_id: h.worker, version: 3, created_at: at(pl, '08:00') };
      db.flocks.push(pf);
      let alive = pf.initial_count;
      for (let d = 0; d <= 44; d++) {
        const date = addDays(pl, d);
        const deaths = Math.round((d < 4 ? 16 : d < 8 ? 10 : 6) * (0.7 + r() * 0.6)); alive -= deaths;
        mkEntry('mortality_entries', { ...pf, house_id: house.id }, date, '08:30', h.worker, { count: deaths, cause: null });
        if (d < 30) mkEntry('coal_entries', { ...pf, house_id: house.id }, date, '08:45', h.worker, { bag_count: d < 8 ? 10 : d < 16 ? 7 : 4, bag_weight_kg: h.bag, total_kg: (d < 8 ? 10 : d < 16 ? 7 : 4) * h.bag, coal_type: null });
        if (d % 7 === 0) mkEntry('weight_measurements', { ...pf, house_id: house.id }, date, '09:30', h.worker, { sample_count: 50, input_mode: 'average', input_value: curve(d), input_unit: 'g', avg_weight_g: curve(d) });
      }
      db.dispatch_records.push({ id: id('d'), client_id: id('c'), org_id: ORG, farm_id: FARM, house_id: house.id, flock_id: pf.id, entry_date: end, bird_count: alive,
        total_live_weight_kg: Math.round(alive * 2.62), avg_weight_kg: 2.62, destination: 'Entegre kesimhane', created_by: DEMO_USERS.owner.id, created_at: at(end, '16:00'), deleted_at: null, version: 1 });
    }
    if (hi === 3) return; // Kümes 4: şu an pasif

    // Aktif dönem: 23. gün (giriş günü = 0. gün)
    const pl = addDays(today, -23);
    const f: Row = { id: `f${hi + 1}-demo`, org_id: ORG, farm_id: FARM, house_id: house.id, cycle_no: hi === 0 ? 2 : 1, name: `Sürü #${pl.slice(0, 4)}-${pl.slice(5, 7)}`,
      placement_date: pl, initial_count: 40000, breed: 'Ross 308', expected_slaughter_date: addDays(pl, 45), status: 'active', completed_at: null,
      responsible_user_id: h.worker, description: null, version: 1, created_at: at(pl, '07:30') };
    db.flocks.push(f);
    for (let d = 0; d <= 23; d++) {
      const date = addDays(pl, d);
      const isToday = d === 23;
      if (!(hi === 2 && (d === 9 || isToday))) { // Kümes 3: 9. gün ve bugün ölüm kaydı yok (eksik kayıt örneği)
        const base = d < 4 ? 16 : d < 8 ? 10 : 7;
        const deaths = hi === 1 && d === 19 ? 46 : Math.round(base * (0.75 + r() * 0.5)); // Kümes 2, 19. gün eşik aşımı
        mkEntry('mortality_entries', f, date, isToday ? (hi === 0 ? '08:12' : '08:40') : '08:20', h.worker, { count: deaths, cause: hi === 1 && d === 19 ? 'heat_stress' : null });
      }
      if (!(hi === 2 && isToday)) {
        const bags = d < 8 ? 10 + Math.round(r()) : d < 16 ? 7 + Math.round(r()) : 5 + Math.round(r() * 2);
        mkEntry('coal_entries', f, date, isToday ? '08:55' : '08:35', h.worker, { bag_count: bags, bag_weight_kg: h.bag, total_kg: bags * h.bag, coal_type: 'Fındık kömürü' });
      }
      if ([0, 3, 7, 10, 14, 17, 21, 23].includes(d) && !(hi === 2 && isToday)) {
        const g = Math.round(curve(d) * (0.97 + r() * 0.06) * (hi === 2 ? 0.97 : 1));
        mkEntry('weight_measurements', f, date, isToday ? '09:40' : '09:30', h.worker, { sample_count: 50, input_mode: 'average', input_value: g, input_unit: 'g', avg_weight_g: g });
      }
      if (d >= 19) {
        const tgt = db.temperature_targets.find((x) => d >= x.day_from && d <= x.day_to)!;
        ['07:15', '10:25', '17:30'].forEach((hm, k) => {
          if (isToday && k === 2) return;
          if (hi === 2 && isToday) return;
          const out = hi === 1 && d === 22 && k === 1; // bir hedef dışı ölçüm
          const v = out ? tgt.max_c + 2.4 : Math.round((tgt.min_c + 0.8 + r() * (tgt.max_c - tgt.min_c - 1.4)) * 10) / 10;
          mkEntry('temperature_measurements', f, date, hm, h.worker, { measured_at: at(date, hm), temperature_c: v, humidity_pct: Math.round(55 + r() * 12), source: 'manual' });
        });
      }
    }
    // İlaç uygulamaları (veteriner talimatıyla kaydedilmiş varsayımı — demo)
    if (hi === 0) {
      [21, 22, 23].forEach((d) => {
        const date = addDays(pl, d);
        [products[0], products[2]].forEach((p, k) => mkEntry('medication_applications', f, date, k ? '09:12' : '09:05', h.worker, {
          product_id: p.id, product_name: p.name, amount: k ? 400 : 250, unit: p.default_unit, method: p.default_method, vet_instruction_ref: 'Vet. talimatı #118',
          withdrawal_days: p.withdrawal_days, withdrawal_end_date: addDays(date, p.withdrawal_days) }));
      });
    }
    if (hi === 1) [14, 15].forEach((d) => mkEntry('medication_applications', f, addDays(pl, d), '09:00', h.worker, {
      product_id: products[1].id, product_name: products[1].name, amount: 300, unit: 'ml', method: 'drinking_water', vet_instruction_ref: null, withdrawal_days: 0, withdrawal_end_date: addDays(pl, d) }));
    mkEntry('daily_notes', f, addDays(pl, 22), '17:40', h.worker, { body: hi === 1 ? 'Öğleden sonra sıcaklık yükseldi, havalandırma artırıldı.' : 'Özel bir durum yok.', photo_path: null });
  });

  const n = (kind: string, severity: string, title: string, body: string, house: string, hoursAgo: number, read = false) =>
    [DEMO_USERS.owner.id, DEMO_USERS.manager.id].forEach((u) => db.notifications.push({ id: id('n'), org_id: ORG, user_id: u, kind, severity, title, body, house_id: house, flock_id: house.replace('h', 'f'),
      created_at: new Date(Date.now() - hoursAgo * 3600_000).toISOString(), read_at: read ? new Date().toISOString() : null }));
  n('missing_report', 'warning', 'Kümes 3: günlük kayıt eksik', 'Bugün için henüz ölüm kaydı girilmedi. Ölüm yoksa "0" olarak kaydedin.', 'h3-demo', 1);
  n('withdrawal_conflict', 'critical', 'Kümes 1: ilaç bekleme süresi kesim planıyla çakışıyor', 'Ürün A bekleme süresi planlanan kesim tarihinden sonra bitiyor. Veterinerinize danışın.', 'h1-demo', 2);
  n('temperature_out_of_range', 'warning', 'Kümes 2: sıcaklık hedef aralık dışında', '22. gün hedef aralık dışında bir ölçüm girildi.', 'h2-demo', 26, true);
  n('mortality_threshold', 'critical', 'Kümes 2: günlük ölüm eşiği aşıldı', '19. gün ölüm oranı tanımlı kritik eşiğin üzerinde.', 'h2-demo', 98, true);
  return db;
}

/** Tek cihaz / tek kullanıcı için örnek veri: bütün kayıtlar yerel hesabın sahibine bağlanır. */
export function buildSampleDb(owner: { id: string; full_name: string }): DemoDb {
  const db = buildDemoDb();
  const ids = new Set<string>(Object.values(DEMO_USERS).map((u) => u.id));
  for (const t of Object.keys(db)) for (const r of db[t]) {
    for (const k of ['created_by', 'responsible_user_id', 'user_id']) if (ids.has(r[k])) r[k] = owner.id;
  }
  db.profiles = [{ id: owner.id, full_name: owner.full_name, phone: null, locale: 'tr' }];
  db.organization_members = [{ id: 'm-owner', org_id: 'org-demo', user_id: owner.id, role: 'owner' }];
  db.house_assignments = [];
  db.notification_preferences = [];
  db.notifications = [];
  db.organizations[0].name = 'KEY Örnek Çiftlik';
  db.farms[0].name = 'KEY Örnek Broiler Çiftliği';
  db.farms[0].contact_name = owner.full_name;
  return db;
}
