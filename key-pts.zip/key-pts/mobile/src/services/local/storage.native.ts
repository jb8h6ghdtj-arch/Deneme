// Cihaz içi kalıcı depolama: expo-sqlite. Her varlık satırı `records` tablosunda (tablo, id) anahtarıyla tutulur.
// Yazmalar işlem (transaction) içinde yapılır; uygulama kapansa da veri korunur.
import * as SQLite from 'expo-sqlite';

type Row = Record<string, unknown> & { id: string };
let dbp: Promise<SQLite.SQLiteDatabase> | null = null;

function db() {
  if (!dbp) {
    dbp = SQLite.openDatabaseAsync('keypts-local.db').then(async (d) => {
      await d.execAsync(`
        PRAGMA journal_mode = WAL;
        CREATE TABLE IF NOT EXISTS records (tbl TEXT NOT NULL, id TEXT NOT NULL, body TEXT NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY (tbl, id));
        CREATE INDEX IF NOT EXISTS records_tbl ON records (tbl);
        CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL);
      `);
      return d;
    });
  }
  return dbp;
}

export async function loadAll(): Promise<Record<string, Row[]>> {
  const rows = await (await db()).getAllAsync<{ tbl: string; body: string }>('SELECT tbl, body FROM records');
  const out: Record<string, Row[]> = {};
  for (const r of rows) (out[r.tbl] ??= []).push(JSON.parse(r.body));
  return out;
}

export async function putRows(tbl: string, rows: Row[]): Promise<void> {
  if (!rows.length) return;
  const d = await db();
  const now = new Date().toISOString();
  await d.withExclusiveTransactionAsync(async (tx) => {
    for (const r of rows) {
      await tx.runAsync('INSERT INTO records (tbl, id, body, updated_at) VALUES (?, ?, ?, ?) ON CONFLICT(tbl, id) DO UPDATE SET body = excluded.body, updated_at = excluded.updated_at',
        tbl, r.id, JSON.stringify(r), now);
    }
  });
}

export async function deleteRows(tbl: string, ids: string[]): Promise<void> {
  if (!ids.length) return;
  const d = await db();
  await d.withExclusiveTransactionAsync(async (tx) => { for (const id of ids) await tx.runAsync('DELETE FROM records WHERE tbl = ? AND id = ?', tbl, id); });
}

export async function clearAll(): Promise<void> { await (await db()).execAsync('DELETE FROM records; DELETE FROM meta;'); }
export async function getMeta(key: string): Promise<string | null> {
  return (await (await db()).getFirstAsync<{ value: string }>('SELECT value FROM meta WHERE key = ?', key))?.value ?? null;
}
export async function setMeta(key: string, value: string | null): Promise<void> {
  const d = await db();
  if (value == null) await d.runAsync('DELETE FROM meta WHERE key = ?', key);
  else await d.runAsync('INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', key, value);
}
export const storageKind = 'sqlite' as 'sqlite' | 'web' | 'memory';
