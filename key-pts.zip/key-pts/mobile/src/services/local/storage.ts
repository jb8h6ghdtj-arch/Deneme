// Web önizleme ve test yedeği: AsyncStorage (tarayıcıda localStorage). Mobilde storage.native.ts (SQLite) kullanılır.
import AsyncStorage from '@react-native-async-storage/async-storage';

type Row = Record<string, unknown> & { id: string };
const K = (t: string) => `keypts:tbl:${t}`;
const M = (k: string) => `keypts:meta:${k}`;
const TABLES = 'keypts:tables';
let cache: Record<string, Row[]> | null = null;

export async function loadAll(): Promise<Record<string, Row[]>> {
  const names: string[] = JSON.parse((await AsyncStorage.getItem(TABLES)) ?? '[]');
  const out: Record<string, Row[]> = {};
  for (const n of names) out[n] = JSON.parse((await AsyncStorage.getItem(K(n))) ?? '[]');
  cache = out;
  return JSON.parse(JSON.stringify(out));
}
async function write(t: string) {
  const names: string[] = JSON.parse((await AsyncStorage.getItem(TABLES)) ?? '[]');
  if (!names.includes(t)) await AsyncStorage.setItem(TABLES, JSON.stringify([...names, t]));
  await AsyncStorage.setItem(K(t), JSON.stringify(cache![t] ?? []));
}
export async function putRows(t: string, rows: Row[]) {
  if (!cache) await loadAll();
  const map = new Map((cache![t] ?? []).map((r) => [r.id, r]));
  rows.forEach((r) => map.set(r.id, JSON.parse(JSON.stringify(r))));
  cache![t] = [...map.values()];
  await write(t);
}
export async function deleteRows(t: string, ids: string[]) {
  if (!cache) await loadAll();
  cache![t] = (cache![t] ?? []).filter((r) => !ids.includes(r.id));
  await write(t);
}
export async function clearAll() {
  const keys = (await AsyncStorage.getAllKeys()).filter((k) => k.startsWith('keypts:'));
  await AsyncStorage.multiRemove(keys); cache = {};
}
export async function getMeta(k: string) { return AsyncStorage.getItem(M(k)); }
export async function setMeta(k: string, v: string | null) { if (v == null) await AsyncStorage.removeItem(M(k)); else await AsyncStorage.setItem(M(k), v); }
export const storageKind = 'web' as 'sqlite' | 'web' | 'memory';
