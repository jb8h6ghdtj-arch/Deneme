// supabase/migrations/…0003 görünümlerinin (v_flock_daily, v_flock_overview, v_activity) demo karşılığı.
// Formüller SQL ile aynıdır; birim testleri (demo.test.ts) tutarlılığı doğrular.
import { addDays, daysBetween } from '../../domain/calculations';
import type { ActivityRow, AppNotification, FlockDay, FlockOverview } from '../../domain/types';
import { istanbulLocalToIso, localDate } from '../../lib/dates';
import type { DemoDb } from './sampleData';

const live = <T extends { deleted_at?: string | null }>(rows: T[] | undefined) => (rows ?? []).filter((r) => !r.deleted_at);
const sum = (a: number[]) => a.reduce((s, v) => s + v, 0);

export function flockDaily(db: DemoDb, flockId: string): FlockDay[] {
  const f = (db.flocks ?? []).find((x) => x.id === flockId); if (!f) return [];
  const farm = (db.farms ?? []).find((x) => x.id === f.farm_id)!;
  const end = f.status === 'active' ? localDate()
    : live(db.dispatch_records).filter((d) => d.flock_id === f.id).map((d) => d.entry_date).sort().pop() ?? f.completed_at.slice(0, 10);
  const by = (t: string) => live(db[t]).filter((x) => x.flock_id === f.id);
  const mort = by('mortality_entries'), mov = by('flock_movements'), disp = by('dispatch_records'), coal = by('coal_entries');
  const med = by('medication_applications'), wt = by('weight_measurements'), tmp = by('temperature_measurements'), notes = by('daily_notes');
  const out: FlockDay[] = [];
  let alive = f.initial_count, cum = 0, placed = f.initial_count;
  for (let i = 0; i <= Math.max(0, daysBetween(f.placement_date, end)); i++) {
    const day = addDays(f.placement_date, i);
    const m = mort.filter((x) => x.entry_date === day);
    const deaths = m.length ? sum(m.map((x) => x.count)) : null;
    const birdsIn = sum(mov.filter((x) => x.entry_date === day && ['addition', 'transfer_in'].includes(x.movement_type)).map((x) => x.count));
    const birdsOut = sum(mov.filter((x) => x.entry_date === day && !['addition', 'transfer_in'].includes(x.movement_type)).map((x) => x.count));
    const dispatched = sum(disp.filter((x) => x.entry_date === day).map((x) => x.bird_count));
    const c = coal.filter((x) => x.entry_date === day);
    const w = wt.filter((x) => x.entry_date === day).sort((a, b) => b.created_at.localeCompare(a.created_at))[0];
    const t = tmp.filter((x) => x.entry_date === day).map((x) => Number(x.temperature_c));
    const start = alive;
    cum += deaths ?? 0; placed += birdsIn;
    alive = start + birdsIn - birdsOut - (deaths ?? 0) - dispatched;
    out.push({
      flock_id: f.id, house_id: f.house_id, day, age_day: i + farm.age_base, deaths, mortality_recorded: deaths != null, mortality_entries: m.length,
      birds_in: birdsIn, birds_out: birdsOut, dispatched, start_of_day_alive: start, end_of_day_alive: alive,
      daily_mortality_pct: deaths == null || start <= 0 ? null : Math.round((deaths * 100 / start) * 1000) / 1000,
      cumulative_deaths: cum, cumulative_mortality_pct: Math.round((cum * 100 / placed) * 1000) / 1000,
      coal_bags: c.length ? sum(c.map((x) => Number(x.bag_count))) : null, coal_kg: c.length ? sum(c.map((x) => Number(x.total_kg))) : null, coal_entries: c.length,
      med_count: med.filter((x) => x.entry_date === day).length, avg_weight_g: w ? Number(w.avg_weight_g) : null, weight_sample_count: w ? w.sample_count : null,
      temp_min: t.length ? Math.min(...t) : null, temp_max: t.length ? Math.max(...t) : null, temp_avg: t.length ? Math.round((sum(t) / t.length) * 10) / 10 : null,
      temp_count: t.length, note_count: notes.filter((x) => x.entry_date === day).length,
    });
  }
  return out;
}

export function flockOverview(db: DemoDb): FlockOverview[] {
  const today = localDate();
  return (db.flocks ?? []).map((f) => {
    const h = (db.houses ?? []).find((x) => x.id === f.house_id)!;
    const farm = (db.farms ?? []).find((x) => x.id === f.farm_id)!;
    const days = flockDaily(db, f.id);
    const last = days[days.length - 1];
    const todayRow = days.find((d) => d.day === today);
    const placed = f.initial_count + sum(days.map((d) => d.birds_in));
    const totalDeaths = last?.cumulative_deaths ?? 0;
    const lw = live(db.weight_measurements).filter((x) => x.flock_id === f.id).sort((a, b) => (b.entry_date + b.created_at).localeCompare(a.entry_date + a.created_at))[0];
    const lt = live(db.temperature_measurements).filter((x) => x.flock_id === f.id).sort((a, b) => b.measured_at.localeCompare(a.measured_at))[0];
    const wd = live(db.medication_applications).filter((x) => x.flock_id === f.id && x.withdrawal_days > 0).map((x) => x.withdrawal_end_date).sort().pop() ?? null;
    const endDate = f.status === 'active' ? today : f.completed_at.slice(0, 10);
    return {
      flock_id: f.id, org_id: f.org_id, farm_id: f.farm_id, house_id: f.house_id, house_name: h.name, capacity: h.capacity, heating_type: h.heating_type,
      coal_tracking: h.coal_tracking, sort_order: h.sort_order, name: f.name, cycle_no: f.cycle_no, status: f.status, placement_date: f.placement_date,
      initial_count: f.initial_count, breed: f.breed, expected_slaughter_date: f.expected_slaughter_date, responsible_user_id: f.responsible_user_id,
      completed_at: f.completed_at, version: f.version, chick_phase_days: farm.chick_phase_days, age_base: farm.age_base, today,
      age_day: daysBetween(f.placement_date, endDate) + farm.age_base,
      days_to_slaughter: f.status === 'active' && f.expected_slaughter_date ? daysBetween(today, f.expected_slaughter_date) : null,
      placed_total: placed, alive_count: last ? last.end_of_day_alive : f.initial_count, total_deaths: totalDeaths,
      cumulative_mortality_pct: Math.round((totalDeaths * 100 / placed) * 1000) / 1000,
      today_deaths: f.status === 'active' ? todayRow?.deaths ?? null : null, today_mortality_recorded: !!todayRow?.mortality_recorded,
      today_coal_bags: todayRow?.coal_bags ?? null, today_coal_kg: todayRow?.coal_kg ?? null, today_med_count: todayRow?.med_count ?? 0,
      last_weight_g: lw ? Number(lw.avg_weight_g) : null, last_weight_date: lw?.entry_date ?? null, last_weight_sample: lw?.sample_count ?? null,
      last_weight_at: lw?.created_at ?? null,
      last_temperature_c: lt ? Number(lt.temperature_c) : null, last_temperature_at: lt?.measured_at ?? null,
      withdrawal_end_date: wd, withdrawal_conflict: !!(wd && f.expected_slaughter_date && wd >= f.expected_slaughter_date),
    } as FlockOverview;
  });
}

export function activity(db: DemoDb): ActivityRow[] {
  const map: [string, string, (r: any) => [number | null, string | null, string | null]][] = [
    ['mortality', 'mortality_entries', (r) => [r.count, null, r.note]],
    ['coal', 'coal_entries', (r) => [r.bag_count, r.coal_type, r.note]],
    ['medication', 'medication_applications', (r) => [r.amount, `${r.product_name} (${r.unit})`, r.note]],
    ['weight', 'weight_measurements', (r) => [r.avg_weight_g, `${r.sample_count} örnek`, r.note]],
    ['temperature', 'temperature_measurements', (r) => [r.temperature_c, r.humidity_pct == null ? null : `${r.humidity_pct}% nem`, r.note]],
    ['note', 'daily_notes', (r) => [null, null, r.body]],
    ['movement', 'flock_movements', (r) => [r.count, r.movement_type, r.note]],
  ];
  return map.flatMap(([kind, t, f]) => live(db[t]).map((r) => {
    const [value, label, note] = f(r);
    return { kind, id: r.id, flock_id: r.flock_id, house_id: r.house_id, org_id: r.org_id, entry_date: r.entry_date, created_at: r.created_at, created_by: r.created_by, value, label, note, version: r.version, updated_at: r.updated_at } as ActivityRow;
  }));
}

/**
 * Uygulama içi uyarılar — cihazda, kayıtlardan hesaplanır (sunucu yok).
 * Aynı olay için tek uyarı: kimlikler olaya göre sabittir (ör. mort:<dönem>:<tarih>).
 */
export function computeAlerts(db: DemoDb, now = new Date()): Omit<AppNotification, 'read_at'>[] {
  const today = localDate(now);
  const hour = Number(new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/Istanbul', hour: '2-digit', hourCycle: 'h23' }).format(now));
  const out: Omit<AppNotification, 'read_at'>[] = [];
  const pct = (n: number) => `%${n.toLocaleString('tr-TR', { maximumFractionDigits: 3 })}`;
  for (const f of flockOverview(db).filter((x) => x.status === 'active')) {
    const s = db.alert_settings?.find((a) => a.farm_id === f.farm_id);
    const days = flockDaily(db, f.flock_id);
    const base = { house_id: f.house_id, flock_id: f.flock_id };
    if (s) {
      days.filter((d) => d.day >= addDays(today, -6) && d.daily_mortality_pct != null).forEach((d) => {
        const p = Number(d.daily_mortality_pct);
        const sev = p >= s.daily_mortality_critical_pct ? 'critical' : p >= s.daily_mortality_warn_pct ? 'warning' : null;
        if (sev) out.push({ ...base, id: `mort:${f.flock_id}:${d.day}`, kind: 'mortality_threshold', severity: sev, title: `${f.house_name}: günlük ölüm eşiği aşıldı`,
          body: `${d.age_day}. gün ${d.deaths} ölüm (${pct(p)}). ${sev === 'critical' ? 'Kritik' : 'Dikkat'} eşiği: ${pct(sev === 'critical' ? s.daily_mortality_critical_pct : s.daily_mortality_warn_pct)}.`,
          created_at: istanbulLocalToIso(d.day, '12:00') });
      });
      if (!f.today_mortality_recorded && hour >= s.missing_report_hour) out.push({ ...base, id: `missing:${f.flock_id}:${today}`, kind: 'missing_report', severity: 'warning',
        title: `${f.house_name}: günlük kayıt tamamlanmadı`, body: 'Bugün için ölüm kaydı girilmedi. Ölüm yoksa "0" olarak kaydedin.', created_at: istanbulLocalToIso(today, `${String(s.missing_report_hour).padStart(2, '0')}:00`) });
      if (f.days_to_slaughter != null && f.days_to_slaughter >= 0 && f.days_to_slaughter <= s.slaughter_reminder_days) out.push({ ...base, id: `slaughter:${f.flock_id}:${f.expected_slaughter_date}`,
        kind: 'slaughter_approaching', severity: 'info', title: `${f.house_name}: kesim yaklaşıyor`, body: f.days_to_slaughter === 0 ? 'Planlanan kesim tarihi bugün.' : `Planlanan kesime ${f.days_to_slaughter} gün kaldı.`, created_at: istanbulLocalToIso(today, '08:00') });
    }
    for (const t of (db.temperature_measurements ?? []).filter((x) => x.flock_id === f.flock_id && !x.deleted_at && x.entry_date >= addDays(today, -2))) {
      const age = days.find((d) => d.day === t.entry_date)?.age_day ?? 0;
      const tg = db.temperature_targets?.find((x) => x.farm_id === f.farm_id && age >= x.day_from && age <= x.day_to);
      if (tg && (t.temperature_c < tg.min_c || t.temperature_c > tg.max_c)) out.push({ ...base, id: `temp:${t.id}`, kind: 'temperature_out_of_range', severity: 'warning',
        title: `${f.house_name}: sıcaklık hedef aralık dışında`, body: `${String(t.temperature_c).replace('.', ',')} °C ölçüldü (${age}. gün hedef ${tg.min_c}–${tg.max_c} °C).`, created_at: t.measured_at });
    }
    if (f.withdrawal_conflict) out.push({ ...base, id: `wd:${f.flock_id}:${f.withdrawal_end_date}:${f.expected_slaughter_date}`, kind: 'withdrawal_conflict', severity: 'critical',
      title: `${f.house_name}: ilaç bekleme süresi kesim planıyla çakışıyor`, body: 'Bekleme süresi planlanan kesim tarihinden sonra bitiyor. Veterinerinize danışın.', created_at: istanbulLocalToIso(today, '07:00') });
  }
  return out.sort((a, b) => b.created_at.localeCompare(a.created_at));
}
