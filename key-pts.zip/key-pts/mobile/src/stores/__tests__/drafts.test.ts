// Taslaklar kullanıcı/çiftlik/kümes/dönem/tarih ile ayrışır: bir kümenin taslağı diğerine taşınmaz.
jest.mock('@react-native-async-storage/async-storage', () => { const m: Record<string, string> = {}; return { getItem: jest.fn(async (k: string) => m[k] ?? null), setItem: jest.fn(async (k: string, v: string) => { m[k] = v; }), removeItem: jest.fn(async (k: string) => { delete m[k]; }) }; });
import { draftKey, emptyDraft, isDirty, useDrafts } from '../drafts';

const base = { userId: 'u1', farmId: 'f1', flockId: 'fl1', date: '2026-11-06' };
describe('günlük kayıt taslakları', () => {
  it('farklı kümelerin anahtarları ayrıdır ve değerler karışmaz', () => {
    const k1 = draftKey({ ...base, houseId: 'h1' }), k2 = draftKey({ ...base, houseId: 'h2', flockId: 'fl2' });
    expect(k1).not.toBe(k2);
    const s = useDrafts.getState();
    s.put(k1, emptyDraft({ ...base, houseId: 'h1' }, '08:00')); s.patch(k1, { deaths: '17' });
    s.put(k2, emptyDraft({ ...base, houseId: 'h2', flockId: 'fl2' }, '08:00'));
    expect(useDrafts.getState().get(k1)?.deaths).toBe('17');
    expect(useDrafts.getState().get(k2)?.deaths).toBe('');
  });
  it('ilaç seçimi aynı taslağa eklenir, diğer değerler korunur', () => {
    const k = draftKey({ ...base, houseId: 'h3' }); const s = useDrafts.getState();
    s.put(k, emptyDraft({ ...base, houseId: 'h3' }, '08:00')); s.patch(k, { deaths: '4', temp: '31,5' });
    s.patch(k, { meds: [{ productId: 'p1', name: 'Vitamin', dose: '1', unit: 'ml/L' } as never] });
    const d = useDrafts.getState().get(k)!;
    expect(d.deaths).toBe('4'); expect(d.temp).toBe('31,5'); expect(d.meds).toHaveLength(1);
    expect(isDirty(d)).toBe(true);
  });
  it('boş taslak değişmemiş sayılır; kayıttan sonra silinir', () => {
    const k = draftKey({ ...base, houseId: 'h4' }); const s = useDrafts.getState();
    s.put(k, emptyDraft({ ...base, houseId: 'h4' }, '08:00'));
    expect(isDirty(useDrafts.getState().get(k)!)).toBe(false);
    s.remove(k); expect(useDrafts.getState().get(k)).toBeUndefined();
  });
});
