import { create } from 'zustand';
/** Uygulama genel durumu: yerel veri yüklendi mi, örnek veri mi, hesap var mı */
export const useAppStatus = create<{ ready: boolean; sample: boolean; hasAccount: boolean; set: (p: Partial<{ ready: boolean; sample: boolean; hasAccount: boolean }>) => void }>()((set) => ({
  ready: false, sample: false, hasAccount: false, set: (p) => set(p),
}));
