// Form taslakları — kalıcı (uygulama kapanınca da korunur) ve bağlama göre ayrık:
// anahtar = kullanıcı + çiftlik + kümes + üretim dönemi + kayıt tarihi.
// Başka kümenin / dönemin / kullanıcının taslağı asla yanlış formda görünmez.
import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

export interface DraftMedication { productId: string; name: string; category: string; amount: string; unit: string; method: string | null; vetRef: string; withdrawalDays: number }
export interface DailyDraft {
  houseId: string; flockId: string; date: string;
  deaths: string; bags: string; bagKg: string | null; weight: string; wUnit: 'kg' | 'g'; sample: string; temp: string; time: string; note: string;
  meds: DraftMedication[];
  /** Kaydet'e basıldığında kullanılacak sabit işlem kimlikleri (çift gönderim koruması) */
  ids: Record<string, string>;
  updatedAt: string;
}
export interface DraftKey { userId: string; farmId: string; houseId: string; flockId: string; date: string }
export const draftKey = (k: DraftKey) => `${k.userId}|${k.farmId}|${k.houseId}|${k.flockId}|${k.date}`;

export const emptyDraft = (k: DraftKey, time: string): DailyDraft => ({
  houseId: k.houseId, flockId: k.flockId, date: k.date, deaths: '', bags: '', bagKg: null, weight: '', wUnit: 'kg', sample: '', temp: '', time, note: '', meds: [], ids: {}, updatedAt: new Date().toISOString(),
});
/** Kullanıcının girdiği bir değer var mı? (kaydedilmemiş değişiklik uyarısı için) */
export const isDirty = (d: DailyDraft | undefined) => !!d && !!(d.deaths || d.bags || d.weight || d.sample || d.temp || d.note.trim() || d.meds.length);

interface DraftState {
  drafts: Record<string, DailyDraft>;
  get: (key: string) => DailyDraft | undefined;
  put: (key: string, d: DailyDraft) => void;
  patch: (key: string, p: Partial<DailyDraft>) => void;
  remove: (key: string) => void;
  /** 14 günden eski taslakları temizler */
  prune: () => void;
}

export const useDrafts = create<DraftState>()(persist((set, get) => ({
  drafts: {},
  get: (key) => get().drafts[key],
  put: (key, d) => set((s) => ({ drafts: { ...s.drafts, [key]: d } })),
  patch: (key, p) => set((s) => (s.drafts[key] ? { drafts: { ...s.drafts, [key]: { ...s.drafts[key], ...p, updatedAt: new Date().toISOString() } } } : s)),
  remove: (key) => set((s) => { const { [key]: _x, ...rest } = s.drafts; return { drafts: rest }; }),
  prune: () => set((s) => ({ drafts: Object.fromEntries(Object.entries(s.drafts).filter(([, d]) => Date.now() - Date.parse(d.updatedAt) < 14 * 86400_000)) })),
}), { name: 'keypts-drafts-v1', storage: createJSONStorage(() => AsyncStorage) }));
