import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Session } from '../services/local/localClient';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

interface SessionState {
  session: Session | null;
  ready: boolean;
  activeOrgId: string | null;
  setSession: (s: Session | null) => void;
  setReady: () => void;
  setActiveOrg: (id: string | null) => void;
}

export const useSession = create<SessionState>()(
  persist(
    (set) => ({
      session: null,
      ready: false,
      activeOrgId: null,
      setSession: (session) => set({ session }),
      setReady: () => set({ ready: true }),
      setActiveOrg: (activeOrgId) => set({ activeOrgId }),
    }),
    {
      name: 'keypts-session-prefs',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (s) => ({ activeOrgId: s.activeOrgId }), // oturum belirteci SecureStore'da
    },
  ),
);

export const useUserId = () => useSession((s) => s.session?.user.id ?? null);
