// Referans tasarım açık temalıdır; tüm bileşenler bu tek paleti kullanır.
import React from 'react';
import { colors } from './colors';
export function ThemeProvider({ children }: { children: React.ReactNode }) { return <>{children}</>; }
export const useTheme = () => ({ c: colors });
