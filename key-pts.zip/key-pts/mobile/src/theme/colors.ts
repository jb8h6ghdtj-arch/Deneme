// KEY PTS renk sistemi — referans görselden örneklenmiş tonlar (docs/DESIGN_REFERENCE.md §2)
export const colors = {
  brand: {
    navy: '#10243A',      // başlık alanları (örnek: #10233B)
    navyDeep: '#0B1D33',  // giriş ekranı gradyan alt tonu
    navySoft: '#19334E',
    orange: '#EB7615',    // birincil eylem (örnek: #EB7615 / #E36A0C)
    orangeLight: '#F58A2A', // gradyan üst tonu
    orangeDark: '#E2680B',
    orangeSoft: '#FCEFE6', // aktif zaman çizelgesi satırı (örnek: #FCEFE6)
    red: '#E4471B',        // logo ibik/sakal
    gold: '#F6A21C',       // logo gaga
  },
  surface: {
    primary: '#FFFFFF',
    secondary: '#F5F7FA',  // sayfa zemini (örnek: #F6F7F8)
    tertiary: '#EEF2F6',   // seçim kutusu / sekme zemini (örnek: #EEEFF2)
    sheet: '#F9FAFB',
  },
  text: { primary: '#172536', secondary: '#667587', muted: '#94A0AD', inverse: '#FFFFFF', link: '#1F4E8C' },
  border: { default: '#E3E8EF', subtle: '#EDF0F4', strong: '#C9D5E8' },
  status: {
    success: '#27956A', successSoft: '#E3F4EA', // "Normal" etiketi (örnek zemin: #D3F0DA)
    warning: '#D98A1C', warningSoft: '#FFF4DD',
    danger: '#D94B55', dangerSoft: '#FDEBEA',   // ölüm KPI zemini (örnek: #FDEBEA)
    info: '#3178BB', infoSoft: '#E3ECF8',       // seçilen ilaçlar paneli (örnek: #DFE9F6)
  },
  // Modül ikon renkleri — aynı işlev her ekranda aynı renk
  module: {
    mortality: { fg: '#D94B55', bg: '#FDEBEA' },
    coal: { fg: '#EB7615', bg: '#FCEFE6' },
    medication: { fg: '#3178BB', bg: '#E3ECF8' },
    weight: { fg: '#7B4FC9', bg: '#EFE9FA' },
    temperature: { fg: '#D94B55', bg: '#FDEBEA' },
    note: { fg: '#667587', bg: '#EEF2F6' },
    birds: { fg: '#3C9A3F', bg: '#E3F4EA' },
    timeline: { fg: '#EB7615', bg: '#FCEFE6' },
  },
  input: { onNavy: 'rgba(255,255,255,0.16)', onNavyBorder: 'rgba(255,255,255,0.10)' },
  overlay: 'rgba(11,29,51,0.45)',
} as const;

export type Colors = typeof colors;
