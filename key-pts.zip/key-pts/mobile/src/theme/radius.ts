export const radius = { sm: 8, input: 10, card: 14, panel: 18, button: 12, pill: 999 } as const;
