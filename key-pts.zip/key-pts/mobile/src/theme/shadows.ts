import { Platform, type ViewStyle } from 'react-native';
// Çok hafif gölge + ince kenarlık (iOS ve Android'de benzer görünüm)
const make = (opacity: number, radius: number, y: number, elevation: number): ViewStyle =>
  Platform.select<ViewStyle>({
    ios: { shadowColor: '#10243A', shadowOpacity: opacity, shadowRadius: radius, shadowOffset: { width: 0, height: y } },
    android: { elevation },
    default: { shadowColor: '#10243A', shadowOpacity: opacity, shadowRadius: radius, shadowOffset: { width: 0, height: y } },
  })!;
export const shadows = { card: make(0.06, 10, 3, 1.5), raised: make(0.1, 16, 6, 4), button: make(0.22, 10, 4, 3) } as const;
