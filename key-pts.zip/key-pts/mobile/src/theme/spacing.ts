// 4 px tabanlı boşluk sistemi
export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 20, '2xl': 24, '3xl': 32 } as const;
export const layout = { screenX: 16, headerBottom: 26, sheetOverlap: 18, touch: 48, button: 52 } as const;
