import type { TextStyle } from 'react-native';

// Inter (SIL Open Font License 1.1 — ticari kullanım serbest). Yüklenemezse sistem fontu.
export const fontFamily = {
  regular: 'Inter_400Regular',
  medium: 'Inter_500Medium',
  semibold: 'Inter_600SemiBold',
  bold: 'Inter_700Bold',
  extrabold: 'Inter_800ExtraBold',
  brandItalic: 'Inter_800ExtraBold_Italic',
} as const;

const t = (fontSize: number, family: keyof typeof fontFamily, extra: TextStyle = {}): TextStyle => ({
  fontSize, fontFamily: fontFamily[family], ...extra,
});

export const typography = {
  display: t(24, 'bold', { lineHeight: 30, letterSpacing: -0.3 }),   // ana ekran başlığı
  title: t(21, 'bold', { lineHeight: 27 }),                           // sayfa başlığı (lacivert başlık)
  section: t(18, 'bold', { lineHeight: 24 }),                         // bölüm başlığı ("Kümes Özeti")
  kpi: t(23, 'bold', { lineHeight: 29, fontVariant: ['tabular-nums'] }),
  kpiLarge: t(26, 'bold', { lineHeight: 32, fontVariant: ['tabular-nums'] }),
  cardTitle: t(16, 'bold', { lineHeight: 21 }),
  body: t(15, 'regular', { lineHeight: 21 }),
  bodyStrong: t(15, 'semibold', { lineHeight: 21 }),
  label: t(13.5, 'medium', { lineHeight: 18 }),
  caption: t(12, 'medium', { lineHeight: 16 }),
  button: t(16, 'semibold', { lineHeight: 22 }),
} as const;

export type TypeVariant = keyof typeof typography;
