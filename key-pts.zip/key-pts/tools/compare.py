"""Referans kolajdaki telefon ekranı ile uygulama ekran görüntüsünü yan yana koyar."""
import sys
from PIL import Image, ImageDraw
REF = '/mnt/user-data/uploads/d89adcce-image.png'
BOXES = {  # referans kolajda telefon ekranı kırpma alanları (piksel)
  'giris': (276, 18, 514, 548), 'dashboard': (530, 18, 790, 548), 'kumes-detay': (803, 18, 1048, 548), 'gunluk-kayit': (1063, 18, 1298, 548),
  'ilac-sec': (1312, 18, 1532, 548), 'raporlar': (393, 576, 678, 1012), 'suru-takvimi': (697, 576, 972, 1012), 'kumesler': (990, 576, 1250, 1012), 'ayarlar': (1266, 576, 1528, 1012),
}
def pair(key, shot, out, H=760):
    ref = Image.open(REF).convert('RGB').crop(BOXES[key]); r = ref.resize((int(ref.width * H / ref.height), H), Image.LANCZOS)
    s = Image.open(shot).convert('RGB'); s = s.resize((int(s.width * H / s.height), H), Image.LANCZOS)
    c = Image.new('RGB', (r.width + s.width + 24, H + 26), 'white'); c.paste(r, (0, 26)); c.paste(s, (r.width + 24, 26))
    d = ImageDraw.Draw(c); d.text((4, 6), f'REFERANS — {key}', fill=(90, 90, 90)); d.text((r.width + 28, 6), 'UYGULAMA (web derlemesi, demo)', fill=(90, 90, 90))
    c.save(out)
if __name__ == '__main__':
    pair(sys.argv[1], sys.argv[2], sys.argv[3])
