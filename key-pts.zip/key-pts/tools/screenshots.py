"""Demo web derlemesinden referans ekranların görüntülerini alır (390×844, @2x).
Kullanım: python3 tools/screenshots.py <cikti_klasoru> [http://127.0.0.1:8090]"""
import asyncio, sys, os
from playwright.async_api import async_playwright

OUT = sys.argv[1]; BASE = sys.argv[2] if len(sys.argv) > 2 else 'http://127.0.0.1:8090'
os.makedirs(OUT, exist_ok=True)
SHOTS = [
  ('02-dashboard', '/'), ('03-kumes-detay', '/house/h1-demo'), ('04-gunluk-kayit', '/record?houseId=h1-demo'),
  ('05-ilac-sec', '/record/medications?houseId=h1-demo'), ('06-raporlar', '/reports'), ('07-suru-takvimi', '/flock/timeline?flockId=f1-demo'),
  ('08-kumesler', '/houses'), ('09-ayarlar', '/profile'), ('10-olum-takvimi', '/module/mortality?flockId=f2-demo'),
  ('11-kumes-grafik', '/house/h2-demo#chart'), ('12-tartim', '/module/weight?flockId=f1-demo'), ('13-bildirimler', '/notifications'),
  ('14-bekleyen', '/sync'), ('15-kumes3-eksik', '/house/h3-demo'),
]

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        ctx = await b.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2, locale='tr-TR', timezone_id='Europe/Istanbul')
        page = await ctx.new_page()
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        await page.goto(BASE + '/'); await page.wait_for_timeout(2500)
        await page.screenshot(path=f'{OUT}/01-giris.png')
        await page.get_by_text('Giriş Yap', exact=True).click(); await page.wait_for_timeout(2500)
        for name, path in SHOTS:
            await page.goto(BASE + path.split('#')[0]); await page.wait_for_timeout(2200)
            if path.endswith('#chart'):
                await page.get_by_text('Sürü Grafiği', exact=True).first.click(); await page.wait_for_timeout(900)
            await page.screenshot(path=f'{OUT}/{name}.png')
            if name == '02-dashboard':
                await page.screenshot(path=f'{OUT}/02b-dashboard-full.png', full_page=True)
        # Bakıcı görünümü
        await page.goto(BASE + '/profile'); await page.wait_for_timeout(1500)
        await page.evaluate("localStorage.clear()"); await page.goto(BASE + '/'); await page.wait_for_timeout(2200)
        await page.fill('input[aria-label="E-posta"]', 'bakici@demo.keypts'); await page.get_by_text('Giriş Yap', exact=True).click(); await page.wait_for_timeout(2500)
        await page.screenshot(path=f'{OUT}/16-bakici-ana.png')
        await page.goto(BASE + '/houses'); await page.wait_for_timeout(1800); await page.screenshot(path=f'{OUT}/17-bakici-kumesler.png')
        await b.close()
        print('page errors:', errors[:5])

asyncio.run(main())
