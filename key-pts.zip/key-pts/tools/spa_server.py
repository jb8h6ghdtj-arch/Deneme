# Basit SPA sunucusu: bilinmeyen yolları index.html'e yönlendirir (expo-router derin bağlantıları için)
import http.server, os, sys
root = sys.argv[1]; port = int(sys.argv[2])
class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k): super().__init__(*a, directory=root, **k)
    def log_message(self, *a): pass
    def do_GET(self):
        path = self.path.split('?')[0]
        if not os.path.exists(os.path.join(root, path.lstrip('/'))) or path == '/':
            self.path = '/index.html'
        return super().do_GET()
http.server.ThreadingHTTPServer(('127.0.0.1', port), H).serve_forever()
